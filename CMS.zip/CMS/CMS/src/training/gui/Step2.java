package training.gui;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import settings.UI_Settings;
import utilities.JTextFieldLimit;

public class Step2 extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JFrame controllingFrame;
	private JLabel previousStepTextButton = new JLabel("previous step");
	private JLabel nextStepTextButton = new JLabel("next step");
	private int screenWidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
	
	private JTextArea topicOneTextArea = new JTextArea(2, 20);
	
	private JTextArea topicOneWhatDoEmployeesLearn = new JTextArea(2, 20);
	private JTextArea topicOneWhyIsItImportant = new JTextArea(2, 20);
	private JTextField topicOneSubTopicTXT = new JTextField();
	private JTextField topicOneTimeTXT = new JTextField();
	
	private JTextArea topicTwoWhatDoEmployeesLearn = new JTextArea(2, 20);
	private JTextArea topicTwoWhyIsItImportant = new JTextArea(2, 20);
	private JTextField topicTwoSubTopicTXT = new JTextField();
	private JTextField topicTwoTimeTXT = new JTextField();
	private JTextField totalTimeTXT = new JTextField();

	
	
	private JCheckBox topicOneCHK_Lecture = new JCheckBox("Lecture");
	private JCheckBox topicOneCHK_Demonst = new JCheckBox("Demonstration");
	private JCheckBox topicOneCHK_Discuss = new JCheckBox("Discussion");
	private JCheckBox topicOneCHK_Online = new JCheckBox("Online Learning");
	private JCheckBox topicOneCHK_RolePlay = new JCheckBox("Role Play");
	private JCheckBox topicOneCHK_Other = new JCheckBox("Other");
	private JCheckBox topicOneCHK_CaseStudy = new JCheckBox("Case Studies");
	private JCheckBox topicOneCHK_SmallGroup = new JCheckBox("Small Group Teaching");
	
	private JCheckBox topicTwoCHK_Lecture = new JCheckBox("Lecture");
	private JCheckBox topicTwoCHK_Demonst = new JCheckBox("Demonstration");
	private JCheckBox topicTwoCHK_Discuss = new JCheckBox("Discussion");
	private JCheckBox topicTwoCHK_Online = new JCheckBox("Online Learning");
	private JCheckBox topicTwoCHK_RolePlay = new JCheckBox("Role Play");
	private JCheckBox topicTwoCHK_Other = new JCheckBox("Other");
	private JCheckBox topicTwoCHK_CaseStudy = new JCheckBox("Case Studies");
	private JCheckBox topicTwoCHK_SmallGroup = new JCheckBox("Small Group Teaching");
	
	private List<JCheckBox> topicOneCheckBoxArray = new ArrayList<JCheckBox>();
	private List<JCheckBox> topicTwoCheckBoxArray = new ArrayList<JCheckBox>();

	
	private JLabel tipOneHeader;
	private JTextPane tipOneContent = new JTextPane();
	private JPanel tipsContainer;


	private List<JTextField> textboxes = new ArrayList<JTextField>();
	private JPanel rootpanel;
	private CreateTrainingSessionPanel sessionObject;
	
	public Step2(){
	}
	
	public JPanel run(CreateTrainingSessionPanel sessionObject){
		
		this.sessionObject = sessionObject;
		
		rootpanel = new JPanel();
		rootpanel.setLayout(new BoxLayout(rootpanel, BoxLayout.Y_AXIS));
		rootpanel.setBackground(Color.WHITE);
		setPanelSize(rootpanel, new Dimension(new Dimension(screenWidth, 1000)));

		initialize();
		
		return rootpanel;
	}
	
	private void initialize(){
		initializeTextArea(topicOneTextArea);
		initializeTextArea(topicOneWhatDoEmployeesLearn);
		initializeTextArea(topicOneWhyIsItImportant);
		initializeTextFields(topicOneSubTopicTXT);
		intializeTextPanes(tipOneContent);
		
		initializeTextArea(topicTwoWhatDoEmployeesLearn);
		initializeTextArea(topicTwoWhyIsItImportant);
		initializeTextFields(topicTwoSubTopicTXT);
		initializeTextFields(totalTimeTXT);

		initializeCheckBoxes();

		
		
		addNextStepRow();
		addHeadingAndSubText();
		addTopicContainer();
		addSubTopicOneContainer();
		
		rootpanel.add(Box.createVerticalStrut(5));
		
		addSubTopicTwoContainer();
		addTotalTimeContainer();
		
		initializeListeners();
	}
	
	private void addTotalTimeContainer() {
		
		GridBagConstraints gc = new GridBagConstraints();
		
		Dimension dimension = new Dimension(screenWidth, 50);
		
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, dimension);
		container.setBackground(Color.WHITE);
			
				JPanel northPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 2));
				setPanelSize(northPanel, new Dimension(dimension));
				northPanel.setBackground(Color.WHITE);
				northPanel.add(new JLabel("Topic 1 Total Time Needed:"));
				
				JPanel southPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 2));
				setPanelSize(southPanel, new Dimension(dimension));
				southPanel.setBackground(Color.WHITE);
				
					totalTimeTXT = new JTextField(5);
					totalTimeTXT.setMinimumSize(totalTimeTXT.getPreferredSize());
					totalTimeTXT.setHorizontalAlignment(JTextField.CENTER);
					textboxes.add(totalTimeTXT);
					
					southPanel.add(totalTimeTXT);
					southPanel.add(new JLabel("minute/s"));
				
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridwidth = 1;
					gc.gridheight = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.NORTHWEST;
					container.add(northPanel, gc);
					
					gc.gridy = 1;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(0,0,0,0);
					container.add(southPanel, gc);

			gc.gridx = 0;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,0,0,0);
		
		rootpanel.add(container);
	}

	private void initializeCheckBoxes() {
		topicOneCheckBoxArray.add(topicOneCHK_Lecture);
		topicOneCheckBoxArray.add(topicOneCHK_Demonst);
		topicOneCheckBoxArray.add(topicOneCHK_Discuss);
		topicOneCheckBoxArray.add(topicOneCHK_Online);
		topicOneCheckBoxArray.add(topicOneCHK_RolePlay);
		topicOneCheckBoxArray.add(topicOneCHK_Other);
		topicOneCheckBoxArray.add(topicOneCHK_CaseStudy);
		topicOneCheckBoxArray.add(topicOneCHK_SmallGroup);
		
		topicTwoCheckBoxArray.add(topicTwoCHK_Lecture);
		topicTwoCheckBoxArray.add(topicTwoCHK_Demonst);
		topicTwoCheckBoxArray.add(topicTwoCHK_Discuss);
		topicTwoCheckBoxArray.add(topicTwoCHK_Online);
		topicTwoCheckBoxArray.add(topicTwoCHK_RolePlay);
		topicTwoCheckBoxArray.add(topicTwoCHK_Other);
		topicTwoCheckBoxArray.add(topicTwoCHK_CaseStudy);
		topicTwoCheckBoxArray.add(topicTwoCHK_SmallGroup);
		
		for(int i = 0; i < topicOneCheckBoxArray.size(); i++){
			topicOneCheckBoxArray.get(i).setForeground(UI_Settings.getComponentsFontColorLight());
			topicTwoCheckBoxArray.get(i).setForeground(UI_Settings.getComponentsFontColorLight());
			
			topicOneCheckBoxArray.get(i).setFont(UI_Settings.getComponentInputFontSize());
			topicTwoCheckBoxArray.get(i).setFont(UI_Settings.getComponentInputFontSize());

		}
	}

	private void addSubTopicOneContainer() {
		
		Dimension dimension = new Dimension(screenWidth, 300);
		Dimension dimensionThirdWidth = new Dimension(screenWidth/3, 300);
		Dimension dimensionTwoThirdWidth = new Dimension((screenWidth/3)*2, 300);

		GridBagConstraints gc = new GridBagConstraints();


		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, dimension);
		container.setBackground(Color.PINK);
		
			JPanel containerWest = new JPanel(new GridBagLayout());
			setPanelSize(containerWest, dimensionThirdWidth);
			containerWest.setBackground(Color.WHITE);
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.1;
			gc.weighty = 0.1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(5,50,10,0);
			
			JLabel subHeading1 = new JLabel("Sub-topic 1.");
			subHeading1.setFont(subHeading1.getFont().deriveFont(13.0f));
			
			containerWest.add(subHeading1, gc);
			
			gc.gridx = 1;
			gc.insets = new Insets(0,-120,0,20);
			containerWest.add(topicOneSubTopicTXT, gc);
			
			JPanel panel = (JPanel) addTipContainer();
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridwidth = 2;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.insets = new Insets(10,10,0,20);
			containerWest.add(panel, gc);
			
		
			JPanel containerEast = new JPanel(new GridBagLayout());
			setPanelSize(containerEast, dimensionTwoThirdWidth);
			
			JPanel containerEastNorth = new JPanel(new GridBagLayout());
			setPanelSize(containerEastNorth, new Dimension(dimensionTwoThirdWidth.width, dimensionThirdWidth.height/2));
			containerEastNorth.setBackground(Color.WHITE);
			
				JPanel panel1 = new JPanel(new GridBagLayout());
				setPanelSize(panel1, new Dimension((dimensionTwoThirdWidth.width/3)*2, dimensionThirdWidth.height/2));
				panel1.setBackground(Color.WHITE);
				
				int count = 0;
				
				gc.gridx = 0;
				gc.gridy = count;
				gc.gridwidth = 2;
				gc.gridheight = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(5,10,5,20);
				panel1.add(new JLabel("What do employees need to learn by the of the session?"), gc);
				
				gc.gridx = 0;
				gc.gridy = ++count;
				gc.insets = new Insets(5,10,0,20);
				panel1.add(topicOneWhatDoEmployeesLearn, gc);
				
				gc.gridx = 0;
				gc.gridy = ++count;
				panel1.add(new JLabel("Why is this important to learn?"), gc);
				
				gc.gridx = 0;
				gc.gridy = ++count;
				gc.insets = new Insets(5,10,5,20);
				panel1.add(topicOneWhyIsItImportant, gc);

				
				
				
				JPanel panel2 = new JPanel();
				panel2.setLayout(new BoxLayout(panel2, BoxLayout.Y_AXIS));
				setPanelSize(panel2, new Dimension(dimensionTwoThirdWidth.width/3, dimensionThirdWidth.height/2));
				panel2.setBackground(Color.WHITE);
				
					JPanel time1 = new JPanel(new GridBagLayout());
					setPanelSize(time1, new Dimension(dimensionTwoThirdWidth.width/3, 30));
					time1.setBackground(Color.WHITE);
					gc.gridx = 1;
					gc.gridy = 0;
					gc.gridwidth = 1;
					gc.gridheight = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.NORTHEAST;
					gc.insets = new Insets(10,0,0,20);
					
					time1.add(new JLabel("Sub-topic 1 Time Needed:"), gc);
					
					JPanel time2 = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 2));
					setPanelSize(time2, new Dimension(dimensionTwoThirdWidth.width/3, 30));
					time2.setBackground(Color.WHITE);
					
						topicOneTimeTXT = new JTextField(5);
						topicOneTimeTXT.setMinimumSize(topicOneTimeTXT.getPreferredSize());
						topicOneTimeTXT.setHorizontalAlignment(JTextField.CENTER);
						textboxes.add(topicOneTimeTXT);
						
						time2.add(topicOneTimeTXT);
						time2.add(new JLabel("minute/s"));
					
					panel2.add(time1);
					panel2.add(time2);

				gc.gridx = 0;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,0,0,0);
				containerEastNorth.add(panel1, gc);
			
				gc.gridx = 1;
				containerEastNorth.add(panel2, gc);
			
			
			JPanel containerEastSouth = new JPanel(new GridBagLayout());
			setPanelSize(containerEastSouth, new Dimension(dimensionTwoThirdWidth.width, dimensionThirdWidth.height/2));
			containerEastSouth.setBackground(Color.WHITE);
			
			int y = 0;
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridwidth = 1;
			gc.gridheight = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(10,20,0,0);
			containerEastSouth.add(new JLabel("Training Tools/Aids Needed:"), gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.insets = new Insets(10,15,0,0);
			containerEastSouth.add(topicOneCHK_Lecture, gc);
			
			gc.gridx = ++y;
			gc.gridy = 1;
			gc.insets = new Insets(10,-80,0,0);
			containerEastSouth.add(topicOneCHK_Demonst, gc);
			
			gc.gridx = ++y;
			gc.gridy = 1;
			gc.insets = new Insets(10,0,0,0);
			containerEastSouth.add(topicOneCHK_Discuss, gc);
			
			gc.gridx = ++y;
			gc.gridy = 1;
			gc.insets = new Insets(10,0,0,0);
			containerEastSouth.add(topicOneCHK_Online, gc);
			
			int x = 0;
			
			gc.gridx = 0;
			gc.gridy = 2;
			gc.insets = new Insets(10,15,30,0);
			containerEastSouth.add(topicOneCHK_RolePlay, gc);
			
			gc.gridx = ++x;
			gc.gridy = 2;
			gc.insets = new Insets(10,-80,30,0);
			containerEastSouth.add(topicOneCHK_Other, gc);
			
			gc.gridx = ++x;
			gc.gridy = 2;
			gc.insets = new Insets(10,0,30,0);
			containerEastSouth.add(topicOneCHK_CaseStudy, gc);
			
			gc.gridx = ++x;
			gc.gridy = 2;
			containerEastSouth.add(topicOneCHK_SmallGroup, gc);
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridwidth = 1;
			gc.gridheight = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,0,0,0);
			containerEast.add(containerEastNorth, gc);
			
			gc.gridy = 1;
			containerEast.add(containerEastSouth, gc);
			
		gc.gridy = 0;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		container.add(containerWest, gc);
		
		gc.gridx = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		container.add(containerEast, gc);
		
		rootpanel.add(container);
	}
	
	private void addSubTopicTwoContainer() {
		Dimension dimension = new Dimension(screenWidth, 300);
		Dimension dimensionThirdWidth = new Dimension(screenWidth/3, 300);
		Dimension dimensionTwoThirdWidth = new Dimension((screenWidth/3)*2, 300);

		GridBagConstraints gc = new GridBagConstraints();


		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, dimension);
		container.setBackground(Color.PINK);
		
			JPanel containerWest = new JPanel(new GridBagLayout());
			setPanelSize(containerWest, dimensionThirdWidth);
			containerWest.setBackground(Color.WHITE);
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.1;
			gc.weighty = 0.1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(5,50,10,0);
			
			JLabel subHeading2 = new JLabel("Sub-topic 2.");
			subHeading2.setFont(subHeading2.getFont().deriveFont(13.0f));
			
			containerWest.add(subHeading2, gc);
			
			gc.gridx = 1;
			gc.insets = new Insets(0,-120,0,20);
			containerWest.add(topicTwoSubTopicTXT, gc);
			
		
			JPanel containerEast = new JPanel(new GridBagLayout());
			setPanelSize(containerEast, dimensionTwoThirdWidth);
			
			JPanel containerEastNorth = new JPanel(new GridBagLayout());
			setPanelSize(containerEastNorth, new Dimension(dimensionTwoThirdWidth.width, dimensionThirdWidth.height/2));
			containerEastNorth.setBackground(Color.WHITE);
			
				JPanel panel1 = new JPanel(new GridBagLayout());
				setPanelSize(panel1, new Dimension((dimensionTwoThirdWidth.width/3)*2, dimensionThirdWidth.height/2));
				panel1.setBackground(Color.WHITE);
				
				int count = 0;
				
				gc.gridx = 0;
				gc.gridy = count;
				gc.gridwidth = 2;
				gc.gridheight = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(5,10,5,20);
				panel1.add(new JLabel("What do employees need to learn by the of the session?"), gc);
				
				gc.gridx = 0;
				gc.gridy = ++count;
				gc.insets = new Insets(5,10,0,20);
				panel1.add(topicTwoWhatDoEmployeesLearn, gc);
				
				gc.gridx = 0;
				gc.gridy = ++count;
				panel1.add(new JLabel("Why is this important to learn?"), gc);
				
				gc.gridx = 0;
				gc.gridy = ++count;
				gc.insets = new Insets(5,10,5,20);
				panel1.add(topicTwoWhyIsItImportant, gc);

				
				
				
				JPanel panel2 = new JPanel();
				panel2.setLayout(new BoxLayout(panel2, BoxLayout.Y_AXIS));
				setPanelSize(panel2, new Dimension(dimensionTwoThirdWidth.width/3, dimensionThirdWidth.height/2));
				panel2.setBackground(Color.WHITE);
				
					JPanel time1 = new JPanel(new GridBagLayout());
					setPanelSize(time1, new Dimension(dimensionTwoThirdWidth.width/3, 30));
					time1.setBackground(Color.WHITE);
					gc.gridx = 1;
					gc.gridy = 0;
					gc.gridwidth = 1;
					gc.gridheight = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.NORTHEAST;
					gc.insets = new Insets(10,0,0,20);
					time1.add(new JLabel("Sub-topic 2 Time Needed:"), gc);
					
					JPanel time2 = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 2));
					setPanelSize(time2, new Dimension(dimensionTwoThirdWidth.width/3, 30));
					time2.setBackground(Color.WHITE);
					
						topicTwoTimeTXT = new JTextField(5);
						topicTwoTimeTXT.setMinimumSize(topicTwoTimeTXT.getPreferredSize());
						topicTwoTimeTXT.setHorizontalAlignment(JTextField.CENTER);
						textboxes.add(topicTwoTimeTXT);
						
						time2.add(topicTwoTimeTXT);
						time2.add(new JLabel("minute/s"));
					
					panel2.add(time1);
					panel2.add(time2);

				gc.gridx = 0;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,0,0,0);
				containerEastNorth.add(panel1, gc);
			
				gc.gridx = 1;
				containerEastNorth.add(panel2, gc);
			
			
			JPanel containerEastSouth = new JPanel(new GridBagLayout());
			setPanelSize(containerEastSouth, new Dimension(dimensionTwoThirdWidth.width, dimensionThirdWidth.height/2));
			containerEastSouth.setBackground(Color.WHITE);
			
			int y = 0;
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridwidth = 1;
			gc.gridheight = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(10,20,0,0);
			containerEastSouth.add(new JLabel("Training Tools/Aids Needed:"), gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.insets = new Insets(10,15,0,0);
			containerEastSouth.add(topicTwoCHK_Lecture, gc);
			
			gc.gridx = ++y;
			gc.gridy = 1;
			gc.insets = new Insets(10,-80,0,0);
			containerEastSouth.add(topicTwoCHK_Demonst, gc);
			
			gc.gridx = ++y;
			gc.gridy = 1;
			gc.insets = new Insets(10,0,0,0);
			containerEastSouth.add(topicTwoCHK_Discuss, gc);
			
			gc.gridx = ++y;
			gc.gridy = 1;
			gc.insets = new Insets(10,0,0,0);
			containerEastSouth.add(topicTwoCHK_Online, gc);
			
			int x = 0;
			
			gc.gridx = 0;
			gc.gridy = 2;
			gc.insets = new Insets(10,15,30,0);
			containerEastSouth.add(topicTwoCHK_RolePlay, gc);
			
			gc.gridx = ++x;
			gc.gridy = 2;
			gc.insets = new Insets(10,-80,30,0);
			containerEastSouth.add(topicTwoCHK_Other, gc);
			
			gc.gridx = ++x;
			gc.gridy = 2;
			gc.insets = new Insets(10,0,30,0);
			containerEastSouth.add(topicTwoCHK_CaseStudy, gc);
			
			gc.gridx = ++x;
			gc.gridy = 2;
			containerEastSouth.add(topicTwoCHK_SmallGroup, gc);
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridwidth = 1;
			gc.gridheight = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,0,0,0);
			containerEast.add(containerEastNorth, gc);
			
			gc.gridy = 1;
			containerEast.add(containerEastSouth, gc);
			
		gc.gridy = 0;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		container.add(containerWest, gc);
		
		gc.gridx = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		container.add(containerEast, gc);
		
		rootpanel.add(container);		
	}

	private void addTopicContainer() {
		
		GridBagConstraints gc = new GridBagConstraints();
		Dimension dimension = new Dimension(screenWidth, 70);
		
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, dimension);
		container.setBackground(Color.WHITE);
		
			//Add two halves to the container//
			JPanel containerWest = new JPanel(new GridBagLayout());
			setPanelSize(containerWest, new Dimension(dimension.width/2, dimension.height));
			containerWest.setBackground(Color.WHITE);
			
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(10,20,0,20);
				
				JLabel heading = new JLabel("Topic 1:");
				heading.setFont(heading.getFont().deriveFont(14.0f));
				
				
				containerWest.add(heading, gc);
				
				gc.gridx = 1;
				gc.weightx = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(10,-100,10,20);
				containerWest.add(topicOneTextArea, gc);
				
			JPanel containerEast = new JPanel(new GridBagLayout());
			setPanelSize(containerEast, new Dimension(dimension.width/2, dimension.height));
			containerEast.setBackground(Color.WHITE);
		
			gc.gridx = 0;
			gc.gridy = 0;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,0,0,0);
			container.add(containerWest, gc);
			
			gc.gridx = 1;
			container.add(containerEast, gc);
		
		rootpanel.add(container);
	}


	
	private void initializeListeners() {
		
		nextStepTextButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		nextStepTextButton.addMouseListener(new MouseAdapter(){
			@SuppressWarnings("static-access")
			public void mousePressed(MouseEvent e){
				
				FormEventStep2 ev = getFormEvent();
				
				JScrollPane scroller = sessionObject.getScroller();
				if(scroller != null)scroller.getViewport().setViewPosition(new Point(0,0));
				 
				
				 sessionObject.resetLocatorColors();
				 sessionObject.locator3.setBackground(CreateTrainingSessionPanel.LOCATOR_ACTIVE_COLOR);
				 CardLayout cl = (CardLayout)(sessionObject.cards.getLayout());
				 cl.show(sessionObject.cards, CreateTrainingSessionPanel.STEP3);
			}

			private FormEventStep2 getFormEvent() {
				///////////////////////////////////////////////////////////////////
				String subTopic1Title = !topicOneSubTopicTXT.getText().isEmpty() ? topicOneSubTopicTXT.getText() : "<no data entered>";
				String subTopic1WhatDoEmployeesNeedToLearn = !topicOneWhatDoEmployeesLearn.getText().isEmpty() ? topicOneWhatDoEmployeesLearn.getText() : "<no data entered>";
				String subTopic1WhyImportant = !topicOneWhyIsItImportant.getText().isEmpty() ? topicOneWhyIsItImportant.getText() : "<no data entered>";
				
				List<String> subTopic1TrainingToolsArray = new ArrayList<String>();
				if(!subTopic1TrainingToolsArray.isEmpty()) subTopic1TrainingToolsArray.clear();
				
				for(int i = 0; i < topicOneCheckBoxArray.size(); i++){
					
					if(topicOneCheckBoxArray.get(i).getModel().isSelected()){
						//System.out.println("Checkbox name is: " + topicOneCheckBoxArray.get(i).getText());
						subTopic1TrainingToolsArray.add(topicOneCheckBoxArray.get(i).getText());
					}
				}
				///////////////////////////////////////////////////////////////////
				String subTopic2Title = !topicTwoSubTopicTXT.getText().isEmpty() ? topicTwoSubTopicTXT.getText() : "<no data entered>";
				String subTopic2WhatDoEmployeesNeedToLearn = !topicTwoWhatDoEmployeesLearn.getText().isEmpty() ? topicTwoWhatDoEmployeesLearn.getText() : "<no data entered>";
				String subTopic2WhyImportant = !topicTwoWhyIsItImportant.getText().isEmpty() ? topicTwoWhyIsItImportant.getText() : "<no data entered>";

				
				List<String> subTopic2TrainingToolsArray = new ArrayList<String>();
				if(!subTopic2TrainingToolsArray.isEmpty()) subTopic2TrainingToolsArray.clear();
				
				for(int i = 0; i < topicTwoCheckBoxArray.size(); i++){
					
					if(topicTwoCheckBoxArray.get(i).isSelected()){
						subTopic2TrainingToolsArray.add(topicTwoCheckBoxArray.get(i).getText());
					}
					
				}
				//////////////////////////Add Time Fields//////////////////////////
				
				int subTopic1Time = runIsANumberTest(topicOneTimeTXT);
				int subTopic2Time = runIsANumberTest(topicTwoTimeTXT);
				int totalTime = subTopic1Time + subTopic2Time;

				
				///////////////////////////////////////////////////////////////////
				FormEventStep2 ev = new FormEventStep2(this,
						subTopic1Title,
						subTopic1WhatDoEmployeesNeedToLearn,
						subTopic1WhyImportant,
						subTopic1TrainingToolsArray,
						
						subTopic2Title,
						subTopic2WhatDoEmployeesNeedToLearn,
						subTopic2WhyImportant,
						subTopic2TrainingToolsArray,
						subTopic1Time,
						subTopic2Time,
						totalTime);
				
				
				return ev;
			}

			private int runIsANumberTest(JTextField textfield) {
				
				if(textfield.getText().isEmpty())return 0;
				
				try {
				     int number = Integer.parseInt(textfield.getText());
				     return number;
				}
				catch (NumberFormatException e) {
					JOptionPane.showMessageDialog(controllingFrame, "Not a number entered for time. Inserted 0!", "NAN Entered!", JOptionPane.ERROR_MESSAGE);
					textfield.setText("0");
					return 0;
				}
			}
		});
		
		
		previousStepTextButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		previousStepTextButton.addMouseListener(new MouseAdapter(){
			@SuppressWarnings("static-access")
			public void mousePressed(MouseEvent e){
				
				JScrollPane scroller = sessionObject.getScroller();

				if(scroller != null){
					 scroller.getViewport().setViewPosition(new Point(0,0));
				 }
				
				 sessionObject.resetLocatorColors();
				 sessionObject.locator1.setBackground(CreateTrainingSessionPanel.LOCATOR_ACTIVE_COLOR);
				 CardLayout cl = (CardLayout)(sessionObject.cards.getLayout());
				 cl.show(sessionObject.cards, CreateTrainingSessionPanel.STEP1);
			}
			
		});
	}
	
	private void addNextStepRow() {
		
		nextStepTextButton.setFont(nextStepTextButton.getFont().deriveFont(12.0f));
		previousStepTextButton.setFont(previousStepTextButton.getFont().deriveFont(12.0f));

		nextStepTextButton.setForeground(UI_Settings.getComponentsFontColorLight());
		previousStepTextButton.setForeground(UI_Settings.getComponentsFontColorLight());


		JPanel container = new JPanel();
		container.setBackground(Color.WHITE);
		container.setLayout(new BoxLayout(container, BoxLayout.X_AXIS));
		container.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		container.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		container.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(previousStepTextButton);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(nextStepTextButton);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		container.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		container.add(rightPanel);
		
		this.rootpanel.add(container);
	}
	
	private void addHeadingAndSubText() {
	
		GridBagConstraints gc = new GridBagConstraints();
		
		JPanel content = new JPanel(new GridBagLayout());
		setPanelSize(content, new Dimension(screenWidth, 100));
		content.setBackground(Color.WHITE);
		
		JLabel pageTitle = new JLabel("Step 2: Clarify Topic 2, Related Concepts, and Training Aids/Tools");
		pageTitle.setFont(pageTitle.getFont().deriveFont(16.0f));
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(15,20,0,0);
		content.add(pageTitle, gc);
		
		
		JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 0));
		setPanelSize(row1, new Dimension(screenWidth, 20));
		row1.setBackground(Color.WHITE);
		
		JTextPane row1Text = new JTextPane();
		row1Text.setFont(row1Text.getFont().deriveFont(11.0f));
		row1Text.setForeground(UI_Settings.getComponentsFontColorDark());
		row1Text.setEditable(false);
		
		MutableAttributeSet set = new SimpleAttributeSet(row1Text.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0);
		
		row1Text.setParagraphAttributes(set, true);

		row1Text.setText("Your class will focus on a few central ideas or skills, but you'll need to explain "
				+ "related concepts to reach your learning objectives.");
		

		row1.add(row1Text);
		row1.setAlignmentY(Component.LEFT_ALIGNMENT);
		gc.gridx = 0;
		gc.gridy = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(0,0,0,0);
		content.add(row1, gc);
		content.setAlignmentY(Component.LEFT_ALIGNMENT);
		this.rootpanel.add(content);
	}
	
	private JComponent addTipContainer() {

		GridBagConstraints gc = new GridBagConstraints();
		
		int height = 120;
		Dimension dimension = new Dimension(screenWidth/3, height);

		tipOneHeader = new JLabel("Tip 3:");
		tipOneHeader.setFont(tipOneHeader.getFont().deriveFont(14.0f));
		
		tipOneContent.setText("You should only have one or two learning objectives for each class. If you have "
				+ "more, you are likely to have too much information to cover, and trainees may feel overwhelmed "
				+ "with information.");
		
		tipsContainer = new JPanel(new GridBagLayout());
		setPanelSize(tipsContainer, dimension);
		tipsContainer.setBackground(Color.WHITE);
		
	
		JPanel containerOne = new JPanel(new GridBagLayout());
		setPanelSize(containerOne, dimension);
		containerOne.setBackground(new Color(242,242,242));
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(5,20,0,0);
			containerOne.add(tipOneHeader, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.insets = new Insets(0,20,0,0);
			containerOne.add(tipOneContent,gc);
			
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(0,0,0,0);
		tipsContainer.add(containerOne,gc);
		
		tipsContainer.setAlignmentY(Component.LEFT_ALIGNMENT);
		
		return tipsContainer;
	}
	
	private void initializeTextArea(JTextArea textarea) {
		textarea.setEditable(true);
		textarea.setWrapStyleWord(true);
		textarea.setLineWrap(true);
		textarea.setDocument(new JTextFieldLimit(150));
		textarea.setBorder(UI_Settings.getBorderoutline());
		textarea.setPreferredSize(textarea.getPreferredSize());
	}
	
	private void initializeTextFields(JTextField textfield) {
		textfield = new JTextField(40);
		textfield.setMinimumSize(textfield.getPreferredSize());
		textfield.setHorizontalAlignment(JTextField.CENTER);
		textboxes.add(textfield);
	}
	
	private void intializeTextPanes(JTextPane textpane) {
		textpane.setFont(textpane.getFont().deriveFont(11.0f));
		textpane.setForeground(UI_Settings.getComponentsFontColorDark());
		textpane.setEditable(false);	
		textpane.setBackground(new Color(242,242,242));
		
		MutableAttributeSet set = new SimpleAttributeSet(textpane.getParagraphAttributes());
		StyleConstants.setLineSpacing(set, (float) 0.3);
		
		textpane.setParagraphAttributes(set, true);
	}
	
	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}

}
