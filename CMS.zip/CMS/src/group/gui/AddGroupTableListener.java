package group.gui;

public interface AddGroupTableListener {
	public void rowDeleted(int row);
}
