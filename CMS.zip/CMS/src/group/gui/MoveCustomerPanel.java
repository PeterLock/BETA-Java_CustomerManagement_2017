package group.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableColumn;

import control.build.PasswordListener;
import customer.gui.CustomerTableListener;
import customer.gui.FormEvent;
import customer.gui.TablePanel;
import group.controller.Controller;
import group.model.Group;
import settings.UI_Settings;
import utilities.JTextFieldLimit;
import utilities.SentryModule;
import utilities.TextPrompt;

public class MoveCustomerPanel extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Calendar c = Calendar.getInstance();
	private JLabel lblDate = new JLabel(c.getTime().toString());
	
	private static Controller controller;
	private PasswordListener passwordListener;
	private JPanel pnlInformation;
	private static JComboBox<String> cmbMoveFromGroupName;
	private static JComboBox<String> cmbMoveToGroupName;
	private GridBagConstraints gc = new GridBagConstraints();
	
	private JPanel canvas;
	private JPanel heading;
	private JPanel header;
	private JPanel detailsPanel;
	private JPanel centerPanel;
	
	
    private static DefaultComboBoxModel<String> model;
    private static DefaultComboBoxModel<String> model2;	
	private JButton btnMoveStudent;
	
    private TablePanel movefrom_tablePanel = new TablePanel();
    private TablePanel moveto_tablePanel = new TablePanel();

	
	private int screenwidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;

    
    private JTextArea txtMoveFromNameContainer;
    private JTextArea txtMoveToNameContainer;
	
	public Component run(){
		JScrollPane scroller = initialize();
		return scroller;
	}

	private JScrollPane initialize() {
		
		controller = new Controller();
		
		
		intializeMoveFromTable();
		intializeMoveToTable();

		/***************************************************Create labels***********************************************************************/
		final JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());
		failedMessage.setVisible(false);
		
		JLabel labels[] = new JLabel[8];
		labels[0] = new JLabel("reset move data");
		labels[1] = new JLabel("undo move");
		labels[2] = new JLabel("help");
		labels[3] = new JLabel("help");
		labels[4] = new JLabel("move");
		labels[5] = new JLabel("view interests");
		labels[6] = new JLabel("view comments");
		labels[7] = new JLabel("reset move data");
		
		labels[1].addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				JOptionPane.showMessageDialog(MoveCustomerPanel.this, "The undo move comment for group member button has been pressed.", "", JOptionPane.PLAIN_MESSAGE);
			}
		});
		
		for(int i = 0; i < 8; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());	
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}

		txtMoveFromNameContainer = new JTextArea(7, 20);
		txtMoveFromNameContainer.setEditable(true);
		txtMoveFromNameContainer.setBorder(UI_Settings.getBorderoutline());
		txtMoveFromNameContainer.setWrapStyleWord(true);
		txtMoveFromNameContainer.setLineWrap(true);
		txtMoveFromNameContainer.setDocument(new JTextFieldLimit(150));
		
		txtMoveFromNameContainer.setPreferredSize(txtMoveFromNameContainer.getPreferredSize());
		TextPrompt textPrompt = new TextPrompt("<no customer names found>", txtMoveFromNameContainer);
		
		Border line = BorderFactory.createLineBorder(new Color(224,224,224));
		Border empty = new EmptyBorder(5, 5, 5, 5);
		CompoundBorder border = new CompoundBorder(line, empty);
		txtMoveFromNameContainer.setBorder(border);

		txtMoveToNameContainer = new JTextArea(6, 20);
		txtMoveToNameContainer.setEditable(true);
		txtMoveToNameContainer.setBorder(UI_Settings.getBorderoutline());
		txtMoveToNameContainer.setWrapStyleWord(true);
		txtMoveToNameContainer.setLineWrap(true);
		txtMoveToNameContainer.setDocument(new JTextFieldLimit(150));
		txtMoveToNameContainer.setBorder(border);
		
		txtMoveToNameContainer.setPreferredSize(txtMoveToNameContainer.getPreferredSize());
		textPrompt = new TextPrompt("<no customer names found>", txtMoveToNameContainer);
		/*************************************Listeners*****************************************/
		btnMoveStudent = new JButton("Commit Changes");
		btnMoveStudent.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnMoveStudent.setFont(UI_Settings.getComponentInputFontSize());
		btnMoveStudent.setPreferredSize(new Dimension(180,UI_Settings.getJbuttonSize().height));
		btnMoveStudent.setMinimumSize(new Dimension(180,UI_Settings.getJbuttonSize().height));

		/*********************************************************Create Combo Boxes*********************************************************/
		cmbMoveFromGroupName = new JComboBox<String>();
		cmbMoveFromGroupName.setPreferredSize(new Dimension(180, UI_Settings.getComboBoxHeight()));
		cmbMoveFromGroupName.setFont(UI_Settings.getComponentInputFontSize());
		cmbMoveFromGroupName.setMinimumSize(cmbMoveFromGroupName.getPreferredSize());
		//AutoCompletion.enable(cmbMoveFromGroupName, 180, UI_Settings.getComboBoxHeight());

		cmbMoveToGroupName = new JComboBox<String>();
		cmbMoveToGroupName.setPreferredSize(new Dimension(180, UI_Settings.getComboBoxHeight()));
		cmbMoveToGroupName.setFont(UI_Settings.getComponentInputFontSize());
		cmbMoveToGroupName.setMinimumSize(cmbMoveToGroupName.getPreferredSize());
		//AutoCompletion.enable(cmbMoveToGroupName, 180, UI_Settings.getComboBoxHeight());
		
		
		try {
			populateComboBoxes();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
				cmbMoveFromGroupName.setSelectedIndex(0);
			}
		});
		
		//Reset move to button//
		labels[7].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				cmbMoveToGroupName.setSelectedIndex(0);
			}
		});
		/****************************Create the canvas**************************/
		
		
		initializeDetailsPanel();
		
		
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) );

	
		/******************************************************Add the Buttons Panel************************************************/
		JPanel moveFromComboPanel = new JPanel();
		moveFromComboPanel.setBackground(UI_Settings.getButtonPanelColor());
		moveFromComboPanel.setLayout(new BoxLayout(moveFromComboPanel, BoxLayout.X_AXIS));
		moveFromComboPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		moveFromComboPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 25));
		moveFromComboPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 25));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 25));
		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 7));
		rightPanel.setBackground(Color.WHITE);
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 25));
		rightPanel.add(labels[0]);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		moveFromComboPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		moveFromComboPanel.add(rightPanel);
		
		
		/*************************************************Add Student to Group Buttons Panel***********************************************/
		JPanel middleComponents = new JPanel(new GridBagLayout());
		middleComponents.setBackground(Color.WHITE);

		middleComponents.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 80));
		middleComponents.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 80));
		
		
		/******************************************************Add the Buttons Panel************************************************/

		int size2 = 80;
		JPanel moveToComboPanel = new JPanel();
		moveToComboPanel.setBackground(UI_Settings.getButtonPanelColor());
		moveToComboPanel.setLayout(new BoxLayout(moveToComboPanel, BoxLayout.X_AXIS));
		moveToComboPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, size2));
		moveToComboPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, size2));
		moveToComboPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, size2));

		
		JPanel leftPanel2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 20,10));
		leftPanel2.setBackground(Color.WHITE);
		leftPanel2.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, size2));
		leftPanel2.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, size2));
		leftPanel2.add(new JLabel("Select the group you want to move the customer to:"));
		leftPanel2.add(cmbMoveToGroupName);
		
		
		JPanel rightPanel2 = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 7));
		rightPanel2.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel2.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, size2));
		rightPanel2.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, size2));
		rightPanel2.add(labels[7]);//Reset Move To data
		
		leftPanel2.setAlignmentX(Component.LEFT_ALIGNMENT);
		moveToComboPanel.add(leftPanel2);
		
		rightPanel2.setAlignmentX(Component.RIGHT_ALIGNMENT);
		moveToComboPanel.add(rightPanel2);
		///////////////////////////////////////////////////////////////////////////////////////
		
		addSouthPanel();
				
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        
        moveFromComboPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(moveFromComboPanel);
        
        
        JPanel tablepanel = new JPanel();
        tablepanel.setLayout(new BoxLayout(tablepanel, BoxLayout.Y_AXIS));
        tablepanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
        setPanelSize(tablepanel, new Dimension(screenwidth, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
        tablepanel.add(new JScrollPane(movefrom_tablePanel));
        tablepanel.setBackground(Color.WHITE);
        
        tablepanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(tablepanel, gc);
        
        moveToComboPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(moveToComboPanel);

        
        JPanel tablepanel2 = new JPanel();
        tablepanel2.setLayout(new BoxLayout(tablepanel2, BoxLayout.Y_AXIS));
        tablepanel2.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
        setPanelSize(tablepanel2, new Dimension(screenwidth, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
        tablepanel2.add(new JScrollPane(moveto_tablePanel));
        tablepanel2.setBackground(Color.WHITE);
        
        tablepanel2.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(tablepanel2, gc);
        
        centerPanel.add(Box.createVerticalStrut(5));

        pnlInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlInformation);

		/*********************************************************************************************************************************/
		///////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly///////////////////
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 800));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 800));
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(canvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());		
		//Add the details section and table sections to the canvas.
		canvas.add(header, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());

		return scroller;
	}
	
	

	private void intializeMoveToTable() {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		final int tableRowNumber = 6;
		
		controller.setRowNumber(6);
		JTable table = moveto_tablePanel.getTable();
		table.setCellSelectionEnabled(false);
		moveto_tablePanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*tableRowNumber)));
		moveto_tablePanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*tableRowNumber)));
		moveto_tablePanel.setData(Controller.getMoveToCustomer(GET_VIEWALL_TABLE_CUSTOMER_LIST));
		moveto_tablePanel.setCustomerTableListener(new CustomerTableListener() {
			
			@Override
			public void rowDeleted(int row) {
				controller.removeCustomer(row, 1);
			}
		});
		
    	for(int i = 0; i < 6; i++){
    		//Add 7 empty rows to the table for its initial load//
    		FormEvent ev = new FormEvent(this, "", "", 13, "", "", 0);
    		
    		if(controller != null){
        		controller.addEmptyCustomerMoveToTables(ev);
        		refresh();
    		}
    	}
    	
    	setJTableColumnsWidth(moveto_tablePanel.getTable(), screenwidth, 15,15,15,40,15);

		
	}

	private void intializeMoveFromTable() {
		// TODO Auto-generated method stub
		final int tableRowNumber = 6;
		
		controller.setRowNumber(6);
		movefrom_tablePanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*tableRowNumber)));
		movefrom_tablePanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*tableRowNumber)));
		movefrom_tablePanel.setData(Controller.getMoveFromCustomer(GET_VIEWALL_TABLE_CUSTOMER_LIST));
		movefrom_tablePanel.setCustomerTableListener(new CustomerTableListener() {
			
			@Override
			public void rowDeleted(int row) {
				controller.removeCustomer(row, 1);
			}
		});
		
    	for(int i = 0; i < 6; i++){
    		//Add 7 empty rows to the table for its initial load//
    		FormEvent ev = new FormEvent(this, "", "", 13, "", "", 0);
    		
    		if(controller != null){
        		controller.addEmptyCustomerMoveTables(ev);
        		refresh();
    		}
    	}
    	
    	setJTableColumnsWidth(movefrom_tablePanel.getTable(), screenwidth, 15,15,15,40,15);

	}
	
	public void refresh() {
		movefrom_tablePanel.refresh();
	}

	private void initializeDetailsPanel() {
		// TODO Auto-generated method stub
		heading = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		JLabel lblHeading = new JLabel("Swapping out customers");
		heading.setBackground(Color.WHITE);
		lblHeading.setFont(lblHeading.getFont().deriveFont(16.0f));
		heading.add(lblHeading);
		
		JPanel headingMessage = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		headingMessage.setBackground(Color.WHITE);
		JLabel lblHeadingMessage = new JLabel("Swapping out customers is simple. Choose the group to swap from, select the customer and\n"
				+ "choose which group to add the customer to.");
		
		headingMessage.add(lblHeadingMessage);

		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-30));
		detailsPanel.setLayout(new GridBagLayout());
		
		header = new JPanel(new GridBagLayout());
		setPanelSize(header, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 100));
		header.setBackground(Color.WHITE);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		header.add(heading,gc);
		
		gc.gridy = 1;
		gc.insets = new Insets(-15,0,0,0);
		header.add(headingMessage, gc);
	
		gc.gridy = 2;
		gc.insets = new Insets(-30,0,0,0);
		header.add(detailsPanel, gc);
		
		JPanel firstRow = new JPanel();
		firstRow.setBackground(UI_Settings.getButtonPanelColor());
		firstRow.setLayout(new BoxLayout(firstRow, BoxLayout.X_AXIS));
		
		JPanel container = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		container.setBackground(Color.WHITE);
		container.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 50));
		container.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 50));
		container.add(new JLabel("Select the group you want to move the customer from:"));
		container.add(cmbMoveFromGroupName);
		
		container.setAlignmentX(Component.LEFT_ALIGNMENT);
		firstRow.add(container);
		
		firstRow.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,30));
		firstRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 30));

		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(17,0,0,0);
		detailsPanel.add(firstRow, gc);
	}

	private void addSouthPanel() {
		//Begin Nested Details Panels (lowest panel on screen)
		pnlInformation = new JPanel();
		pnlInformation.setBackground(Color.WHITE);
		pnlInformation.setLayout(new GridBagLayout());
		pnlInformation.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlInformation.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlInformation.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		
		//Begin Nested Details Panels (lowest panel on screen)
		JPanel pnlSaveRow = new JPanel();
		pnlSaveRow.setBackground(Color.WHITE);
		pnlSaveRow.setLayout(new GridBagLayout());
		pnlSaveRow.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));

			//Create the far left container for the group details information
			JPanel pnlSaveLeftPane = new JPanel(new GridBagLayout());
			pnlSaveLeftPane.setBackground(Color.WHITE);
			pnlSaveLeftPane.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			
			//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,0,0,0);
			
				//Add the nested panels to the container panel (information panel)
			
				JPanel panel3 = new JPanel(new GridBagLayout());
				panel3.setBackground(Color.WHITE);
				panel3.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				
				
				JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row1.setBackground(Color.WHITE);
				row1.add(new JLabel("Table updated:"));
				row1.add(lblDate);
				
				JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row2.setBackground(Color.WHITE);
				row2.add(new JLabel("Connected to: " + controller.getDBname()));
				
				JPanel row3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row3.setBackground(Color.WHITE);
				row3.add(new JLabel("Connection: Secure"));
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(5,5,0,5);
			
				panel3.add(row1, gc);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.insets = new Insets(0,5,0,5);
			
				panel3.add(row2, gc);
				
				gc.gridx = 0;
				gc.gridy = 2;
				gc.insets = new Insets(0,5,45,5);
			
				panel3.add(row3, gc);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.insets = new Insets(0,5,20,5);
			
				pnlSaveLeftPane.add(panel3, gc);
		
		pnlSaveRow.add(pnlSaveLeftPane, gc);
			
		//Create the second panel from the left (comments panel)
		JPanel pnlSaveRight = new JPanel(new GridBagLayout());
		pnlSaveRight.setBackground(Color.WHITE);
		pnlSaveRight.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));

			gc.gridx = 1;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHEAST;
			gc.insets = new Insets(0,0,0,0);
			
			pnlSaveRight.add(btnMoveStudent, gc);
			pnlSaveRow.add(pnlSaveRight, gc);
		
		pnlInformation.add(pnlSaveRow, gc);
	}

	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}

	public void setPasswordListener(PasswordListener passwordListener) {
		this.passwordListener = passwordListener;
	}
	
	static void populateComboBoxes() throws Exception {
		controller.connect();
		controller.load();
		
		List<Group> group_list = new ArrayList<Group>();
	    model = new DefaultComboBoxModel<String>();
	    model2 = new DefaultComboBoxModel<String>();


		group_list = Controller.getGroup();


		for(int i = 0; i < group_list.size(); i++){
			model.addElement(group_list.get(i).getGroupName());
			model2.addElement(group_list.get(i).getGroupName());

		}
		
		cmbMoveFromGroupName.setModel(model);
		cmbMoveFromGroupName.setSelectedIndex(-1);
		
		cmbMoveToGroupName.setModel(model2);
		cmbMoveToGroupName.setSelectedIndex(-1);
	
		controller.disconnect();
	}

	@SuppressWarnings("static-access")
	public static void reloadmodel() {
		
		try {
			controller.connect();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		List<Group> temp = new ArrayList<Group>();
		temp = controller.getGroup();
	
		model.removeAllElements();
		model2.removeAllElements();
		
		for(int i = 0; i < temp.size(); i++){
			model.addElement(temp.get(i).getGroupName());
			model2.addElement(temp.get(i).getGroupName());
		}
		controller.disconnect();
	}
	
	private final static int GET_VIEWALL_TABLE_CUSTOMER_LIST = 1;
	
	
	public static void setJTableColumnsWidth(JTable table, int tablePreferredWidth,
	        double... percentages) {
	    double total = 0;
	    for (int i = 0; i < table.getColumnModel().getColumnCount(); i++) {
	        total += percentages[i];
	    }
	 
	    for (int i = 0; i < table.getColumnModel().getColumnCount(); i++) {
	        TableColumn column = table.getColumnModel().getColumn(i);
	        column.setPreferredWidth((int)
	                (tablePreferredWidth * (percentages[i] / total)));
	    }
	}
}
