package group.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import control.build.FormListener;
import control.build.GroupComboListener;
import control.build.PasswordListener;
import group.controller.Controller;
import group.model.Group;
import settings.UI_Settings;
import utilities.JTextFieldLimit;
import utilities.TextPrompt;
import utilities.UniqueIDGenerator;

public class ViewGroupsPanel extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@SuppressWarnings("unused")
	private JFrame frame = new JFrame();
	private JPanel canvas;
	private JPanel detailsPanel;
	private JPanel centerPanel;
	private JPanel add_group_container;
	private JPanel add_group_left;
	private JPanel add_group_right;
	private JPanel save_group_container;
	private JPanel add_group_right_textfield_container;
	private JPanel table_container;
	private JPanel clearTableButtonPanel;
	private JPanel pnlTopGroupDetails;
    private JPanel header;
    
	private JPopupMenu popup;
	private UniqueIDGenerator idGenerator = new UniqueIDGenerator();
	private FormListener formListener;
	
	private JButton btnCommitChanges;
	private JTextField txtTopPanelStudentName;
	private JTextField txtTopPanelAge;
	private JTextField txtGroupName;
	private JTextField txtGroupID;
	private JTextField txtGroupPos;
	private JTextField txtGroupDay;
	private JTextField txtGroupTime;
	private JTextField txtGroupMaterial;
	private JTextField txtGroupMin;
	private JTextField txtGroupCurrentClassSize;
	private JTextField txtGroupLev;
	private JTextField txtAddGroupName;
	private JTextField txtAddGroupID;
	private JTextField txtAddGroupLev;
	private JTextField txtAddGroupDay;
	private JTextField txtAddGroupTime;
	private JTextField txtAddGroupMax;
	private JTextField txtAddGroupPos;
	private JTextField txtAddGroupMat;
	private JTextField txtAddCurrentClassSize;
	private List <JTextField> textfieldsViewGroupDetails = new ArrayList<JTextField>();
	private List <JTextField> textfieldsAddGroupDetails = new ArrayList<JTextField>();
	
	private List<Group> group_list = new ArrayList<Group>();
	//////////////////////////////////
    JFrame controllingFrame; 
    //////////////////////////////////
    private TablePanel addnew_table_panel = new TablePanel();
    private ViewGroupTablePanel viewgroup_table_panel = new ViewGroupTablePanel();
    
    private group.controller.Controller controller;
	private  JTextArea txtStudentListDisplayArea;
	private JLabel labels[];
    //////////////////////////////////
	private List<JCheckBox> checkboxes_days = new ArrayList<JCheckBox>();
	private List<JCheckBox> checkboxes_times = new ArrayList<JCheckBox>();
	private String[] times = UI_Settings.getGroupTimesList();
	private String[] days = UI_Settings.getGroupDaysList();
	
	private JComboBox<String> cmbGroupNameListCombobox = new JComboBox<String>();
    private DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>();
    
    private int tableWindowHeight = 0;
    private int tableRowNumber = 0;
    private int topFrameHeight = 210;
    private int centerTopHeight = 50;
    private int bottomFrameHeight = 200;
	@SuppressWarnings("unused")
	private PasswordListener passwordListener;
	private GroupComboListener groupComboListener;
	private JPanel addGroupHeading;
	
    public ViewGroupsPanel(final Controller controller, final DefaultComboBoxModel<String> model) throws Exception {
		this.controller = controller;
		this.controller.connect();
		this.model = model;
		popup = new JPopupMenu();
		
		JMenuItem deleteGroup = new JMenuItem("Delete group");
		popup.add(deleteGroup);
		
		initializeComboBoxes();
		populateComboBoxes();
		initializeHeadings();
		
		//Delete Group and GroupMemberList from the database//
		deleteGroup.addActionListener(new ActionListener(){
			
			@SuppressWarnings("unused")
			List<Group> group_list = new ArrayList<Group>();
			
			
			@SuppressWarnings("unchecked")
			public void actionPerformed(ActionEvent e){
				
				if(cmbGroupNameListCombobox.getItemCount() == 0){
					return;
				}
				
				controller.deleteGroup(txtGroupName.getText());
				
				//Reload the db array internally//
				try {
					controller.load();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
				this.group_list = Controller.getGroup();

				model.removeAllElements();
				
				//if(groupComboListener == null)System.out.println("null connection");
				
				groupComboListener = new GroupComboListener() {
					
					@SuppressWarnings({ "rawtypes", "static-access" })
					@Override
					public DefaultComboBoxModel reloadComboModel() {
						
						List<Group> temp = new ArrayList<Group>();
						temp = controller.getGroup();
						
						
						for(int i = 0; i < temp.size(); i++){
							model.addElement(temp.get(i).getGroupName());
						}
						
						
						return model;
					}
					
					@Override
					public void reloadAllComboBoxes() {
						//here//
						AddCustomerToGroupPanel.reloadmodel();
						MoveCustomerPanel.reloadmodel();
						
					}
				};

				groupComboListener.reloadAllComboBoxes();
				
				cmbGroupNameListCombobox.setModel(groupComboListener.reloadComboModel());
				cmbGroupNameListCombobox.repaint();
				
			}
		});
		
		//Add the contents of the bottom panel, the group details
		pnlTopGroupDetails = new JPanel(new GridBagLayout());
		setPanelSize(pnlTopGroupDetails, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
		pnlTopGroupDetails.addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				if(e.getButton() == MouseEvent.BUTTON3){
					popup.show(pnlTopGroupDetails, e.getX(), e.getY());
				}
			}
		});
		
		// TODO this needs to be completed
		
		tableWindowHeight = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height/9;
		tableRowNumber = tableWindowHeight/UI_Settings.getTableRowHeight();
		
		controller.setNumberOfRows(2);
		addnew_table_panel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*tableRowNumber)));
		addnew_table_panel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*tableRowNumber)));
		addnew_table_panel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*tableRowNumber)));
		addnew_table_panel.setData(Controller.getEmptyGroup());
		addnew_table_panel.addGroupTableListener(new AddGroupTableListener() {
			
			@Override
			public void rowDeleted(int row) {
				controller.removeGroup(row);
			}
		});
		
    	for(int i = 0; i < 2; i++){
    		
			FormEvent ev = new FormEvent(this, "", "", "", "", "", "", "", 00000);

    		
    		if(controller != null){
        		controller.addEmptyGroup(ev);
        		refresh();
    		}
    	}
    	
    	// TODO stuff here
		tableWindowHeight = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height/3;
		tableRowNumber = tableWindowHeight/UI_Settings.getTableRowHeight();
		
		controller.setNumberOfRows(tableRowNumber);
		viewgroup_table_panel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*12)));
		viewgroup_table_panel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*12)));
		viewgroup_table_panel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*12)));

		viewgroup_table_panel.setData(Controller.getViewAllGroups());
		
    	for(int i = 0; i < 12; i++){
    		
			FormEvent ev = new FormEvent(this, "", "", "", "", "", "", "", 00000);

    		
    		if(controller != null){
        		controller.addEmptyViewAllGroup(ev);
        		refresh();
    		}
    	}
    	
    	
    this.controller.disconnect();
	}

	private void initializeHeadings() {
		
		GridBagConstraints gc = new GridBagConstraints();
		
		addGroupHeading = new JPanel(new GridBagLayout());
		setPanelSize(addGroupHeading, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 70));
		addGroupHeading.setBackground(Color.WHITE);
		
		JLabel lblHeading = new JLabel("Adding Groups");
		lblHeading.setFont(lblHeading.getFont().deriveFont(16.0f));
		addGroupHeading.add(lblHeading);
		
		JPanel headingMessage = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 10));
		headingMessage.setBackground(Color.WHITE);
		JLabel lblHeadingMessage = new JLabel("Be sure to enter all of the requried information carefully. After hitting Commit Changes, the group\n"
				+ "will appear in the table below.");
		
		headingMessage.add(lblHeadingMessage);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(10,20,0,0);
		addGroupHeading.add(lblHeading, gc);
		
		gc.gridy = 1;
		gc.insets = new Insets(0,20,0,0);
		addGroupHeading.add(headingMessage, gc);

		
	}

	private void initializeComboBoxes() {
		cmbGroupNameListCombobox.setPreferredSize(new Dimension(180, UI_Settings.getComboBoxHeight()));
		cmbGroupNameListCombobox.setFont(UI_Settings.getComponentInputFontSize());
		cmbGroupNameListCombobox.setMinimumSize(cmbGroupNameListCombobox.getPreferredSize());
	}

	private void populateComboBoxes() throws Exception {
		controller.load();
		this.group_list = Controller.getGroup();


		for(int i = 0; i < group_list.size(); i++){
			model.addElement(group_list.get(i).getGroupName());
		}
		
		cmbGroupNameListCombobox.setModel(model);
		cmbGroupNameListCombobox.setSelectedIndex(-1);
	}

	public Component run() throws Exception {
		JScrollPane scroller = initialize();
		return scroller;
	}
	
	
	public JScrollPane initialize(){
		
		this.setFormListener(new FormListener(){
			
			public void formEventOccurred(FormEvent ev){
				controller.addGroup(ev);
			}

			@Override
			public void formEventOccurred(customer.gui.FormEvent e) {
			}

			public void formEventOccurred(product.gui.FormEvent ev) {
			}

			public void formEventOccurred(FormEventMemberList ev) {
				controller.addMemberList(ev);
			}
			
		});
		
		
		cmbGroupNameListCombobox.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
	        	if(cmbGroupNameListCombobox.getSelectedIndex() ==-1){
	        		return;
	        	}
				
				Group group = Controller.searchGroup(cmbGroupNameListCombobox.getSelectedItem().toString());
				
				//Populate group form with the returned group data//
				txtGroupName.setText(group.getGroupName());
				txtGroupID.setText(String.valueOf(group.getId()));
				
				//Convert currentClassSize and maxClassSize to number format//
				int current = Integer.parseInt(group.getCurrentClassSize());
				int maximum = Integer.parseInt(group.getMaxClassSize());
				int positions_available = maximum - current;
				
				txtGroupPos.setText(String.valueOf(positions_available));
				txtGroupLev.setText(group.getLevel());
				txtGroupDay.setText(getDayString(group));
				txtGroupTime.setText(group.getTime());
				txtGroupCurrentClassSize.setText(group.getCurrentClassSize());
				txtGroupMaterial.setText(group.getGroupMaterial());
			}

			private String getDayString(Group group) {
				
				if(group.getDay().equals("Mon"))return "Monday";
				if(group.getDay().equals("Tue"))return "Tuesday";
				if(group.getDay().equals("Wed"))return "Wednesday";
				if(group.getDay().equals("Thu"))return "Thursday";
				if(group.getDay().equals("Fri"))return "Friday";
				if(group.getDay().equals("Sat"))return "Saturday";
				if(group.getDay().equals("Sun"))return "Sunday";

				
				return "Unknown data format";
			}
	    });
		
		Border lightBorder = BorderFactory.createLineBorder(new Color(192,192,192));
		JLabel lblCloseWindow = new JLabel("close panel group [x]");
		lblCloseWindow.setCursor(new Cursor(Cursor.HAND_CURSOR));
		JLabel lblCloseWindow2 = new JLabel("close panel group [x]");
		lblCloseWindow2.setCursor(new Cursor(Cursor.HAND_CURSOR));
		/***************************************************Create labels***********************************************************************/
		final JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());
		failedMessage.setVisible(false);
		
		labels = new JLabel[7];
		labels[0] = new JLabel("reset fields");
		labels[1] = new JLabel("undo move");
		labels[2] = new JLabel("help");
		labels[3] = new JLabel("...");
		labels[4] = new JLabel("clear table");
		labels[5] = new JLabel("view interests");
		labels[6] = new JLabel("view comments");
		
		Calendar c = Calendar.getInstance();
		JLabel lblDate = new JLabel(c.getTime().toString());
		
		
		for(int i = 0; i < 7; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());	
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		
		////////Initialize local fields here for convenience/////////
		labels[3].setFont(labels[3].getFont().deriveFont(18.0f));
		labels[3].setVisible(false);
		labels[3].addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				add_group_container.setVisible(true);
				table_container.setVisible(true);
				labels[3].setVisible(false);
				clearTableButtonPanel.setVisible(true);
			}
		});
		
		
		txtStudentListDisplayArea = new JTextArea(7, 20);
		txtStudentListDisplayArea.setEditable(true);
		txtStudentListDisplayArea.setBorder(UI_Settings.getBorderoutline());
		txtStudentListDisplayArea.setWrapStyleWord(true);
		txtStudentListDisplayArea.setLineWrap(true);
		txtStudentListDisplayArea.setDocument(new JTextFieldLimit(150));
		txtStudentListDisplayArea.setPreferredSize(txtStudentListDisplayArea.getPreferredSize());
		
		/*********************************************Add the Bottom Panel TextFields***********************/

		int view_textfield_size = 13;
		int add_textfield_size = 28;
		//////////////Initialize View Group Fields///////////////
		txtGroupName = initializeTextFields(txtGroupName, view_textfield_size);
		txtGroupID = initializeTextFields(txtGroupID, view_textfield_size);
		txtGroupPos = initializeTextFields(txtGroupPos, view_textfield_size);
		txtGroupLev = initializeTextFields(txtGroupLev, view_textfield_size);
		txtGroupDay = initializeTextFields(txtGroupDay, view_textfield_size);
		txtGroupTime = initializeTextFields(txtGroupTime, view_textfield_size);
		txtGroupCurrentClassSize = initializeTextFields(txtGroupCurrentClassSize, view_textfield_size);
		txtGroupMaterial = initializeTextFields(txtGroupMaterial, view_textfield_size);
		txtGroupMin = initializeTextFields(txtGroupMin, view_textfield_size);

		
		txtAddGroupName = initializeTextFields(txtAddGroupName, add_textfield_size);
		txtAddGroupID = initializeTextFields(txtAddGroupID, add_textfield_size);
		txtAddGroupPos = initializeTextFields(txtAddGroupPos, add_textfield_size);
		txtAddGroupLev = initializeTextFields(txtAddGroupLev, add_textfield_size);
		txtAddGroupDay = initializeTextFields(txtAddGroupDay, add_textfield_size);
		txtAddGroupTime = initializeTextFields(txtAddGroupTime, add_textfield_size);
		txtAddGroupMax = initializeTextFields(txtAddGroupMax, add_textfield_size);
		txtAddGroupMat = initializeTextFields(txtAddGroupMat, add_textfield_size);
		txtAddCurrentClassSize = initializeTextFields(txtAddCurrentClassSize, add_textfield_size);

		
		textfieldsViewGroupDetails.add(txtGroupName); 
		textfieldsViewGroupDetails.add(txtGroupID); 		
		textfieldsViewGroupDetails.add(txtGroupPos); 		
		textfieldsViewGroupDetails.add(txtGroupLev); 		
		textfieldsViewGroupDetails.add(txtGroupDay); 		
		textfieldsViewGroupDetails.add(txtGroupTime); 		
		textfieldsViewGroupDetails.add(txtGroupCurrentClassSize); 		
		textfieldsViewGroupDetails.add(txtGroupMaterial);
		textfieldsViewGroupDetails.add(txtGroupMin);

		
		
		textfieldsAddGroupDetails.add(txtAddGroupName); 
		textfieldsAddGroupDetails.add(txtAddGroupID); 		
		textfieldsAddGroupDetails.add(txtAddGroupPos); 		
		textfieldsAddGroupDetails.add(txtAddGroupLev); 		
		textfieldsAddGroupDetails.add(txtAddGroupDay); 		
		textfieldsAddGroupDetails.add(txtAddGroupTime); 		
		textfieldsAddGroupDetails.add(txtAddGroupMax); 		
		textfieldsAddGroupDetails.add(txtAddGroupMat); 
		textfieldsAddGroupDetails.add(txtAddCurrentClassSize); 
		
		
		txtTopPanelStudentName = new JTextField(10);
		txtTopPanelStudentName.setEditable(true);
		txtTopPanelStudentName.setMinimumSize(txtTopPanelStudentName.getPreferredSize());
		new TextPrompt("-", txtTopPanelStudentName);
		txtTopPanelStudentName.setHorizontalAlignment(JTextField.CENTER);
		textfieldsViewGroupDetails.add(txtTopPanelStudentName);
		
		txtTopPanelAge = new JTextField(5);
		txtTopPanelAge.setEditable(true);
		txtTopPanelAge.setMinimumSize(txtTopPanelAge.getPreferredSize());
		new TextPrompt("-", txtTopPanelAge);
		txtTopPanelAge.setHorizontalAlignment(JTextField.CENTER);
		textfieldsViewGroupDetails.add(txtTopPanelAge);
		
		////////////////////////////////Format the JTextfield/////////////////////////
		for(int i = 0; i < textfieldsAddGroupDetails.size(); i++){
			new TextPrompt("-", textfieldsAddGroupDetails.get(i));
			textfieldsAddGroupDetails.get(i).setHorizontalAlignment(JTextField.CENTER);
			
			textfieldsAddGroupDetails.get(i).setMinimumSize(textfieldsAddGroupDetails.get(i).getPreferredSize());
			textfieldsAddGroupDetails.get(i).setForeground(UI_Settings.getComponentInputFontColor());
		}
		
		for(int i = 0; i < textfieldsViewGroupDetails.size(); i++){
			
			textfieldsViewGroupDetails.get(i).setMinimumSize(textfieldsViewGroupDetails.get(i).getPreferredSize());
			textfieldsViewGroupDetails.get(i).setForeground(UI_Settings.getComponentInputFontColor());
		}
		
		
		
		new TextPrompt("0/6", txtAddCurrentClassSize);
		new TextPrompt("0/6", txtAddGroupMax);
		
		////////////////////////////////////////////////////////////////////////////
		for(int i = 0; i < 7; i++){
			checkboxes_days.add(new JCheckBox(days[i]));
			checkboxes_days.get(i).setFont(UI_Settings.getComponentsFontPlain());
			checkboxes_days.get(i).setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			checkboxes_days.get(i).setForeground(UI_Settings.getComponentsFontColorLight());
		}
		
		
		for(int i = 0; i < 4; i++){
			checkboxes_times.add(new JCheckBox(times[i]));
			checkboxes_times.get(i).setFont(UI_Settings.getComponentsFontPlain());
			checkboxes_times.get(i).setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			checkboxes_times.get(i).setForeground(UI_Settings.getComponentsFontColorLight());
		}
		
		
		configure_checkboxes_days();
		configure_checkboxes_time();

		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
				cmbGroupNameListCombobox.setSelectedIndex(-1);
				
				failedMessage.setVisible(false);
				
				for(int i = 0; i < textfieldsViewGroupDetails.size(); i++){
					textfieldsViewGroupDetails.get(i).setText("");
				}
				
				for(int i = 0; i < textfieldsAddGroupDetails.size(); i++){
					textfieldsAddGroupDetails.get(i).setText("");
				}
				
				for(int i = 0; i < checkboxes_times.size(); i++){
					checkboxes_times.get(i).setSelected(false);
				}
				
				for(int i = 0; i < checkboxes_days.size(); i++){
					checkboxes_days.get(i).setSelected(false);
				}
			}
		});
		
		labels[4].addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
		    	for(int i = 0; i < tableRowNumber; i++){
		    		
					FormEvent ev = new FormEvent(this, "", "", "", "", "", "", "", 00000);

		    		
		    		if(controller != null){
		        		controller.addEmptyGroup(ev);
		        		refresh();
		    		}
		    	}				
			}
			
		});
		/**********************Create the messages panel***********************/
		GridBagConstraints gc = new GridBagConstraints();

		JPanel heading = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		JLabel lblHeading = new JLabel("Viewing Groups");
		heading.setBackground(Color.WHITE);
		lblHeading.setFont(lblHeading.getFont().deriveFont(16.0f));
		heading.add(lblHeading);
		
		JPanel headingMessage = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		headingMessage.setBackground(Color.WHITE);
		JLabel lblHeadingMessage = new JLabel("Viewing and adding groups to the database is simple. To add a group enter the necessary information in the\n"
				+ "blue areas and hit commit. New groups are automatically added to the dropdown box.");
		
		headingMessage.add(lblHeadingMessage);

		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-30));
		detailsPanel.setLayout(new GridBagLayout());
		
		header = new JPanel(new GridBagLayout());
		setPanelSize(header, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 100));
		header.setBackground(Color.WHITE);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		header.add(heading,gc);
		
		gc.gridy = 1;
		gc.insets = new Insets(-15,0,0,0);
		header.add(headingMessage, gc);
	
		gc.gridy = 2;
		gc.insets = new Insets(-30,0,0,0);
		header.add(detailsPanel, gc);
		
		JPanel firstRow = new JPanel();
		firstRow.setBackground(UI_Settings.getButtonPanelColor());
		firstRow.setLayout(new BoxLayout(firstRow, BoxLayout.X_AXIS));
		
		JPanel container = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		container.setBackground(Color.WHITE);
		container.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 50));
		container.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 50));
		container.add(new JLabel("Select the group you want view:"));
		container.add(cmbGroupNameListCombobox);
		
		container.setAlignmentX(Component.LEFT_ALIGNMENT);
		firstRow.add(container);
		
		firstRow.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,30));
		firstRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 30));

		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(17,0,0,0);
		detailsPanel.add(firstRow, gc);
		/******************************************************Add the Buttons Panel************************************************/
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 25));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 25));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 25));
		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
		rightPanel.setBackground(Color.WHITE);
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 25));
		rightPanel.add(labels[0]);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		
		/////////////////////////////Initialize the center panels///////////////////////////////////	
		Dimension dimension = new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getPopupHeaderHeight());

		add_group_container = new JPanel(new GridBagLayout());
		setPanelSize(add_group_container, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, bottomFrameHeight));
		add_group_container.setBackground(Color.WHITE);
		
		JPanel add_group_left_header = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 6));
		add_group_left_header.setBorder(new EmptyBorder(0,0,0,0));
		add_group_left_header.setBackground(new Color(191,210,236));
		add_group_left_header.add(lblCloseWindow2);
		setPanelSize(add_group_left_header, dimension);
		
		JPanel add_group_right_header = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 6));
		add_group_right_header.setBorder(new EmptyBorder(0,0,0,0));
		add_group_right_header.setBackground(new Color(191,210,236));
		add_group_right_header.add(lblCloseWindow);
		setPanelSize(add_group_right_header, dimension);
		
		JPanel add_group_bottom = new JPanel(new GridBagLayout());
		setPanelSize(add_group_bottom, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, bottomFrameHeight-dimension.height));
		add_group_bottom.setBackground(Color.WHITE);

		
		add_group_left = new JPanel(new GridBagLayout());
		setPanelSize(add_group_left, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, bottomFrameHeight));
		add_group_left.setBackground(Color.WHITE);
		add_group_left.setBorder(lightBorder);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridwidth = 4;
		gc.gridheight = 1;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		add_group_left.add(add_group_left_header, gc);
		
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(20,20,0,0);
			add_group_left.add(new JLabel("Group Name:"), gc);
			
			gc.gridx = 0;
			gc.gridy = 2;
			gc.insets = new Insets(5,20,0,0);
			add_group_left.add(new JLabel("Group Material:"), gc);
			
			gc.gridx = 0;
			gc.gridy = 3;
			gc.insets = new Insets(0,20,5,0);
			add_group_left.add(new JLabel("Group Level:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 1;
			gc.gridwidth = 3;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.insets = new Insets(20,0,0,20);
			add_group_left.add(txtAddGroupName, gc);
		
			gc.gridx = 1;
			gc.gridy = 2;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.insets = new Insets(2,0,0,20);
			add_group_left.add(txtAddGroupMat, gc);
			
			gc.gridx = 1;
			gc.gridy = 3;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.insets = new Insets(2,0,10,20);
			add_group_left.add(txtAddGroupLev, gc);
			
			gc.gridx = 0;
			gc.gridy = 4;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(15,35,15,0);
			add_group_left.add(checkboxes_times.get(0), gc);
			
			gc.gridx = 1;
			gc.gridy = 4;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(15,20,15,0);
			add_group_left.add(checkboxes_times.get(1), gc);
			
			gc.gridx = 2;
			gc.gridy = 4;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(15,0,15,0);
			add_group_left.add(checkboxes_times.get(2), gc);
			
			gc.gridx = 3;
			gc.gridy = 4;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(15,0,15,0);
			add_group_left.add(checkboxes_times.get(3), gc);
			
		add_group_right = new JPanel(new GridBagLayout());
		setPanelSize(add_group_right, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, bottomFrameHeight));
		add_group_right.setBackground(Color.WHITE);
		add_group_right.setBorder(lightBorder);
		
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 7;
			gc.weightx = 0.1;
			gc.weighty = 0.1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(-1,0,0,0);
			add_group_right.add(add_group_right_header, gc);
	
	
			
			lblCloseWindow.addMouseListener(new MouseAdapter(){
				
				public void mouseReleased(MouseEvent e){
					add_group_container.setVisible(false);
					labels[3].setVisible(true);
				}
			});
			
			lblCloseWindow2.addMouseListener(new MouseAdapter(){
				
				public void mouseReleased(MouseEvent e){
					add_group_container.setVisible(false);
					labels[3].setVisible(true);
				}
			});
			
			add_group_right_textfield_container = new JPanel(new GridBagLayout());
			setPanelSize(add_group_right_textfield_container, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 50));
			add_group_right_textfield_container.setBackground(new Color(246,246,246));
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridwidth = 	1;
			gc.gridheight = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,10,0,0);
			add_group_right_textfield_container.add(new JLabel("Class Size:"),gc);
			
			gc.gridx = 1;
			gc.gridy = 1;
			gc.gridwidth = 	1;
			gc.gridheight = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,0,0,20);
			add_group_right_textfield_container.add(txtAddCurrentClassSize,gc);
			
			gc.gridx = 0;
			gc.gridy = 2;
			gc.gridwidth = 	1;
			gc.gridheight = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,10,0,0);
			add_group_right_textfield_container.add(new JLabel("Max Size:"),gc);
			
			gc.gridx = 1;
			gc.gridy = 2;
			gc.gridwidth = 	1;
			gc.gridheight = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,0,3,20);
			add_group_right_textfield_container.add(txtAddGroupMax, gc);
		
			gc.gridx = 0;
			gc.gridy = 2;
			gc.gridheight = 1;
			gc.gridwidth = 7;
			gc.weightx = 0.1;
			gc.weighty = 0.1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(15,3,0,3);
			add_group_right.add(add_group_right_textfield_container,gc);
			
			
			gc.gridx = 0;
			gc.gridy = 3;
			gc.gridwidth = 1;
			gc.gridheight = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(10,25,14,0);
			add_group_right.add(checkboxes_days.get(0), gc);//Monday
			
			gc.gridx = 1;
			gc.gridy = 3;
			gc.insets = new Insets(10,-5,14,0);
			add_group_right.add(checkboxes_days.get(1), gc);//Tuesday
			
			gc.gridx = 2;
			gc.gridy = 3;
			gc.insets = new Insets(10,5,14,0);
			add_group_right.add(checkboxes_days.get(2), gc);//Wednesday
			
			gc.gridx = 3;
			gc.gridy = 3;
			gc.insets = new Insets(10,10,14,0);
			add_group_right.add(checkboxes_days.get(3), gc);//Thursday
			
			gc.gridx = 4;
			gc.gridy = 3;
			gc.insets = new Insets(10,10,14,0);
			add_group_right.add(checkboxes_days.get(4), gc);//Friday
			
			gc.gridx = 5;
			gc.gridy = 3;
			gc.insets = new Insets(10,10,14,0);
			add_group_right.add(checkboxes_days.get(5), gc);//Saturday
			
			gc.gridx = 6;
			gc.gridy = 3;
			gc.insets = new Insets(10,10,14,10);
			add_group_right.add(checkboxes_days.get(6), gc);//Sunday
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridwidth = 1;
		gc.gridheight = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,0,0,0);
		add_group_container.add(add_group_bottom, gc);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(0,0,0,5);
		add_group_bottom.add(add_group_left, gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.insets = new Insets(0,0,0,1);
		add_group_bottom.add(add_group_right, gc);
		


		///////////////////////////////////////////////////////////////////////////////////////
		table_container = new JPanel(new GridBagLayout());
		setPanelSize(table_container, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 100));
		table_container.setBackground(Color.YELLOW);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.BOTH;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		table_container.add(addnew_table_panel,gc);
		
		//////////////////////////////////////////////////////////////////////////////////////
		int savegroupsize = 130;
		//Begin Nested Details Panels (lowest panel on screen)
		save_group_container = new JPanel();
		save_group_container.setBackground(Color.WHITE);
		save_group_container.setLayout(new GridBagLayout());
		save_group_container.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, savegroupsize));
		save_group_container.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, savegroupsize));
		//pnlInformation.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()+java.awt.Toolkit.getDefaultToolkit().getScreenSize().height/8));
		
			JPanel pnlSaveRow = new JPanel();
			pnlSaveRow.setBackground(Color.WHITE);
			pnlSaveRow.setLayout(new GridBagLayout());
			pnlSaveRow.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, savegroupsize));
			pnlSaveRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, savegroupsize));
			pnlSaveRow.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, savegroupsize));

				//Create the far left container for the group details information
				JPanel pnlSaveLeftPane = new JPanel(new GridBagLayout());
				pnlSaveLeftPane.setBackground(Color.WHITE);
				pnlSaveLeftPane.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, savegroupsize));
				pnlSaveLeftPane.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, savegroupsize));
				pnlSaveLeftPane.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, savegroupsize));
				
				
					//Add the nested panels to the container panel (information panel)
				
					JPanel panel3 = new JPanel(new GridBagLayout());
					panel3.setBackground(Color.WHITE);
					panel3.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, savegroupsize));
					panel3.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, savegroupsize));
					panel3.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, savegroupsize));
					
					
					JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
					row1.setBackground(Color.WHITE);
					row1.add(new JLabel("Table updated:"));
					row1.add(lblDate);
					
					JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
					row2.setBackground(Color.WHITE);
					row2.add(new JLabel("Connected to: " + controller.getDBname())); //+ controller.getDBname()));
					
					JPanel row3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
					row3.setBackground(Color.WHITE);
					row3.add(new JLabel("Connection: Secure"));
					
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(30,5,0,5);
				
					panel3.add(row1, gc);
					
					gc.gridx = 0;
					gc.gridy = 1;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(0,5,0,5);
				
					panel3.add(row2, gc);
					
					gc.gridx = 0;
					gc.gridy = 2;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(0,5,45,5);
				
					panel3.add(row3, gc);
					
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(0,5,0,5);
				
					pnlSaveLeftPane.add(panel3, gc);
			
			pnlSaveRow.add(pnlSaveLeftPane, gc);
				
			//////////////////////////////////////////Main Column 2 ///////////////////////////////////////////
			//Create the second panel from the left (comments panel)

			JPanel pnlSaveRight = new JPanel(new GridBagLayout());
			pnlSaveRight.setBackground(Color.WHITE);
			pnlSaveRight.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 100));
			pnlSaveRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 100));
			pnlSaveRight.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, 100));

			btnCommitChanges = new JButton("Commit Changes");
			btnCommitChanges.setCursor(new Cursor(Cursor.HAND_CURSOR));
			btnCommitChanges.setPreferredSize(new Dimension(170,UI_Settings.getJbuttonSize().height));
			btnCommitChanges.setMinimumSize(new Dimension(170,UI_Settings.getJbuttonSize().height));
			btnCommitChanges.setFont(UI_Settings.getComponentInputFontSize());
			
			
			JPanel savepanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 5));
			setPanelSize(savepanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 50));
			savepanel.setBackground(Color.WHITE);
			savepanel.add(btnCommitChanges);
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(10,0,0,0);
			pnlSaveRight.add(savepanel, gc);
			

			gc.gridx = 1;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			pnlSaveRow.add(pnlSaveRight, gc);
				

				btnCommitChanges.addMouseListener(new MouseAdapter(){
					
					String groupName = "";
					String groupMaterial = "";
					String groupLevel = "";
					String groupDay = "";
					String groupTime = "";
					String groupClassSize = "";
					String groupMaxClassSize = "";
					int id = 0;
					
					
					public void mousePressed(MouseEvent e){
						//boolean applicationUnlocked = passwordListener.getPasswordState();
						getFieldValues();
						executeAction();
/*						if(applicationUnlocked){
							getFieldValues();
							executeAction();
						}else{
							JOptionPane.showMessageDialog(frame, "Application locked. This activity has been cancelled.",
									"Secure Login", JOptionPane.WARNING_MESSAGE);
						}*/
					}
					
					private void executeAction() {
						resetAddGroupFieldValues();
						
						int temp = idGenerator.getUniqueCustomerID();
						int flag = 0;
						int i = 0;
						id=temp;
						
						//Make sure the new group name hasn't already been added//
						while((flag == 0) && (i < cmbGroupNameListCombobox.getItemCount())){
							
							if(groupName.toLowerCase().equals(((String) cmbGroupNameListCombobox.getItemAt(i)).toLowerCase())){
								JOptionPane.showMessageDialog(controllingFrame,
									    "Group name already exists",
									    "Warning",
									    JOptionPane.WARNING_MESSAGE);								
								flag = 1;
								return;
							}
							
							i++;
						}
						if(flag == 0){
							performAddGroupOperation();
							reloadAllComboBoxes();
						}
					}



					private void getFieldValues() {
						groupName = txtAddGroupName.getText();
						groupMaterial = txtAddGroupMat.getText();
						groupLevel = txtAddGroupLev.getText();
						groupDay = getGroupDay();
						groupTime = getGroupTime();
						groupClassSize = getGroupClassSize();
						groupMaxClassSize = getMaxClassSize();
						
					}

					private String getMaxClassSize() {
						final String max_size = txtAddGroupMax.getText();
						txtAddGroupMax.setText(max_size + "/6");
						return max_size;
					}

					private String getGroupClassSize() {
						
						final String class_size = txtAddCurrentClassSize.getText();
						txtAddCurrentClassSize.setText(class_size + "/6");
						return class_size;
					}

					private String getGroupTime() {
						if(checkboxes_times.get(0).isSelected()) return times[0];
						if(checkboxes_times.get(1).isSelected()) return times[1];
						if(checkboxes_times.get(2).isSelected()) return times[2];
						if(checkboxes_times.get(3).isSelected()) return times[3];

						return "No time selected";
					}

					private String getGroupDay() {
						
						if(checkboxes_days.get(0).isSelected())return days[0];
						if(checkboxes_days.get(1).isSelected())return days[1];
						if(checkboxes_days.get(2).isSelected())return days[2];
						if(checkboxes_days.get(3).isSelected())return days[3];
						if(checkboxes_days.get(4).isSelected())return days[4];
						if(checkboxes_days.get(5).isSelected())return days[5];
						if(checkboxes_days.get(6).isSelected())return days[6];
						
						return "No day selected";
					}


					private void performAddGroupOperation() {
						//Create the new Group FormEvent Object//
						FormEvent ev = new FormEvent(this, groupName, groupMaterial, groupLevel, groupDay, groupTime, groupClassSize, groupMaxClassSize, id);

						//Create the new GroupMemberList FormEvent Object//
						System.out.println("FormEvent name contains: " + ev.getGroupName() + " :: FormEvent id contains: " + ev.getId());
						
						
						FormEventMemberList evm = new FormEventMemberList(this, ev.getGroupName(), ev.getId(), 0,0,0,0,0,0);
						
						if(formListener != null){
							formListener.formEventOccurred(ev);
							formListener.formEventOccurred(evm);
							refresh();
						}
						
						try {
						} catch (Exception e1) {
							e1.printStackTrace();
						}
						
						try {
							try {
								controller.connect();
							} catch (Exception e) {
								e.printStackTrace();
							}
							controller.save();
							//Add the new group name to the ComboBox//
							group_list.clear();
							group_list = Controller.getGroup();
							for(int i = 1; i < group_list.size(); i++){
								model.addElement(group_list.get(i).getGroupName());
							}
							model.addElement(groupName);
							group_list = Controller.getGroup();
							
							controller.disconnect();
						} catch (SQLException e1) {
							e1.printStackTrace();
						}						
					}
				});
				
				//Add the comments panel	
				JPanel resetThreeDonts = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
				resetThreeDonts.setBackground(Color.WHITE);
				resetThreeDonts.add(labels[3]);
				
			clearTableButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
			setPanelSize(clearTableButtonPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 30));
			clearTableButtonPanel.setBackground(Color.WHITE);
			clearTableButtonPanel.add(labels[4]);
			
			gc.gridx = 1;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHEAST;
			gc.insets = new Insets(0,0,0,0);
			save_group_container.add(clearTableButtonPanel, gc);
			

			
			gc.gridx = 1;
			gc.gridy = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHEAST;
			gc.insets = new Insets(0,0,0,0);
			save_group_container.add(pnlSaveRow, gc);
		
		
		/******************************************************Create the Table Data Panel************************************************/
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());
	    centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
	    
	    buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(buttonPanel);
	    
	    viewgroup_table_panel.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(viewgroup_table_panel);
	    
	    addGroupHeading.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(addGroupHeading);
	    
	    add_group_container.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(add_group_container);

	    resetThreeDonts.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(resetThreeDonts);
	    
	    table_container.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(table_container);
	    
	    
	    save_group_container.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(save_group_container);
		/*********************************************************************************************************************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) );
	    
	    canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 1050));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 1050));
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		
		JScrollPane scroller = new JScrollPane(canvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());		
		//Add the details section and table sections to the canvas.
		canvas.add(header, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());

		return(scroller);
	}
	
	protected void reloadAllComboBoxes() {
		try {
			AddCustomerToGroupPanel.populateComboBoxes();
			MoveCustomerPanel.populateComboBoxes();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private JTextField initializeTextFields(JTextField textfield, int length) {
		textfield = new JTextField(length);
		textfield.setMinimumSize(textfield.getPreferredSize());
		textfield.setHorizontalAlignment(JTextField.LEFT);
		
		return textfield;
	}

	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}

	public void resetPanels() {
		add_group_container.setVisible(true);
		table_container.setVisible(true);
		labels[3].setVisible(false);
		clearTableButtonPanel.setVisible(true);
	}
	
	private void configure_checkboxes_time() {
		
		ItemListener listener = new ItemListener(){

			@Override
			public void itemStateChanged(ItemEvent e) {
				
				if(e.getStateChange() == ItemEvent.SELECTED){
					
					if(e.getItem() == checkboxes_times.get(0)){
						resetCheckBoxDays(0);
					}
					
					if(e.getItem() == checkboxes_times.get(1)){
						resetCheckBoxDays(1);
					}
					
					if(e.getItem() == checkboxes_times.get(2)){
						resetCheckBoxDays(2);
					}
					
					if(e.getItem() == checkboxes_times.get(3)){
						resetCheckBoxDays(3);
					}
				}
			}

			private void resetCheckBoxDays(int j) {
				
				for(int i = 0; i < checkboxes_times.size(); i++){
					if(j != i){
						checkboxes_times.get(i).setSelected(false);
					}
				}
				
			}
		};
		
		for(int i = 0; i < checkboxes_times.size(); i++){
			checkboxes_times.get(i).addItemListener(listener);
		}
	}

	private void configure_checkboxes_days() {
		
		ItemListener listener = new ItemListener(){

			@Override
			public void itemStateChanged(ItemEvent e) {
				
				if(e.getStateChange() == ItemEvent.SELECTED){
					
					if(e.getItem() == checkboxes_days.get(0)){
						resetCheckBoxes(0);
					}
					
					if(e.getItem() == checkboxes_days.get(1)){
						resetCheckBoxes(1);
					}
					
					if(e.getItem() == checkboxes_days.get(2)){
						resetCheckBoxes(2);
					}
					
					if(e.getItem() == checkboxes_days.get(3)){
						resetCheckBoxes(3);
					}
					
					if(e.getItem() == checkboxes_days.get(4)){
						resetCheckBoxes(4);
					}
					
					if(e.getItem() == checkboxes_days.get(5)){
						resetCheckBoxes(5);
					}
					
					if(e.getItem() == checkboxes_days.get(6)){
						resetCheckBoxes(6);
					}
				}
			}
		};
		
		for(int i = 0; i < checkboxes_days.size(); i++){
			checkboxes_days.get(i).addItemListener(listener);
		}

	}
	
	public void refresh() {
		addnew_table_panel.refresh();
	}

	private void resetCheckBoxes(int j) {
		for(int i = 0; i < checkboxes_days.size(); i++){
			if(j != i){
				checkboxes_days.get(i).setSelected(false);
			}
		}
	}
	
	public void setFormListener(FormListener listener){
		this.formListener = listener;
	}
	
	private void resetAddGroupFieldValues() {
		for(int i = 0; i < textfieldsAddGroupDetails.size(); i++){
			textfieldsAddGroupDetails.get(i).setText("");
		}
		for(int i = 0; i < checkboxes_times.size(); i++){
			checkboxes_times.get(i).setSelected(false);
		}
		for(int i = 0; i < checkboxes_days.size(); i++){
			checkboxes_days.get(i).setSelected(false);
		}
	}

	public void setPasswordListener(PasswordListener passwordListener) {
		this.passwordListener = passwordListener;
	}

	public void setComboBoxListener(GroupComboListener groupComboListener) {
		this.groupComboListener = groupComboListener;
	}

}
