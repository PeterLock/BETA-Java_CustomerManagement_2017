package events.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;

import group.controller.Controller;
import group.model.Group;
import settings.UI_Settings;
import utilities.SentryModule;
import utilities.TextPrompt;

@SuppressWarnings("serial")
public class ViewEvents extends JPanel {
	
	private JButton btnDeleteEvent;
	private JTextArea txtAreaDescription;
	private JTextArea txtAreaEventList;
	private JTextArea txtAreaEmail;

	@SuppressWarnings("unused")
	private TextPrompt textPrompt;
	
	private  JPasswordField passwordField;
	private JComboBox<String> cmbGroupName = new JComboBox<String>(UI_Settings.getGroups());
	private JComboBox<String> cmbRequestBy = new JComboBox<String>(UI_Settings.getEmployeeNames());
	private JComboBox<String> cmbPreferredEmp_1 = new JComboBox<String>(UI_Settings.getEmployeeNames());
	private JComboBox<String> cmbPreferredEmp_2 = new JComboBox<String>(UI_Settings.getEmployeeNames());
	private JComboBox<String> cmbPreferredEmp_3 = new JComboBox<String>(UI_Settings.getEmployeeNames());
	private JComboBox<String> cmbEventMonth = new JComboBox<String>(UI_Settings.getMonths());
	
	private JPanel canvas;
	private JPanel centerPanel;
	private JPanel headerMessagePanel;
	private JPanel detailsPanel;
	private JPanel pnlSaveInformation;
	private Calendar c = Calendar.getInstance();
	private JLabel lblDate = new JLabel(c.getTime().toString());
	private GridBagConstraints gc = new GridBagConstraints();

	public ViewEvents(){
		
	}
	
	public Component run(){
		JScrollPane scroller = initialize();
		return scroller;
	}

	private JScrollPane initialize() {
		btnDeleteEvent = new JButton("Perform Action");
		btnDeleteEvent.setPreferredSize(new Dimension(200,UI_Settings.getJbuttonSize().height));
		btnDeleteEvent.setMinimumSize(new Dimension(200,UI_Settings.getJbuttonSize().height));

		btnDeleteEvent.setFont(UI_Settings.getComponentInputFontSize());
		
		JCheckBox chkSendRequest = new JCheckBox("send event office request");
		JCheckBox chkDeleteEvent = new JCheckBox("delete event");
		
		chkSendRequest.setFont(UI_Settings.getComponentsFontPlain());
		chkSendRequest.setForeground(UI_Settings.getComponentsFontColorLight());
		
		chkDeleteEvent.setFont(UI_Settings.getComponentsFontPlain());
		chkDeleteEvent.setForeground(UI_Settings.getComponentsFontColorLight());

		txtAreaDescription = new JTextArea(5, 35);
		txtAreaDescription.setMinimumSize(txtAreaDescription.getPreferredSize());
		txtAreaDescription.setEditable(true);
		Border line = BorderFactory.createLineBorder(new Color(224,224,224));
		Border empty = new EmptyBorder(5, 5, 5, 0);
		CompoundBorder border = new CompoundBorder(line, empty);
		txtAreaDescription.setBorder(border);
		txtAreaDescription.setWrapStyleWord(true);
		txtAreaDescription.setLineWrap(true);
		textPrompt = new TextPrompt("<no description found>", txtAreaDescription);
		txtAreaDescription.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaDescription.setMargin( new Insets(15,50,10,10) );
		
		
		txtAreaEventList = new JTextArea(5, 35);
		txtAreaEventList.setMinimumSize(txtAreaEventList.getPreferredSize());
		txtAreaEventList.setEditable(true);
		txtAreaEventList.setBorder(border);
		txtAreaEventList.setWrapStyleWord(true);
		txtAreaEventList.setLineWrap(true);
		textPrompt = new TextPrompt("<no events found>", txtAreaEventList);
		txtAreaEventList.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaEventList.setMargin( new Insets(5,5,5,5) );
		
		txtAreaEmail = new JTextArea(5, 35);
		txtAreaEmail.setMinimumSize(txtAreaEventList.getPreferredSize());
		txtAreaEmail.setEditable(true);
		txtAreaEmail.setBorder(border);
		txtAreaEmail.setWrapStyleWord(true);
		txtAreaEmail.setLineWrap(true);
		textPrompt = new TextPrompt("<requests are automatically saved after being sent>", txtAreaEmail);
		txtAreaEmail.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaEmail.setMargin( new Insets(5,5,5,5) );
		
		/***********************Initialize Fields******************************/
		JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());

		failedMessage.setVisible(false);
		
		JLabel failedMessage1 = new JLabel(UI_Settings.getFailedMessage());
		failedMessage1.setForeground(UI_Settings.getFailedMessageColor());

		failedMessage1.setVisible(false);
		
		JLabel labels[] = new JLabel[8];
		
		labels[0] = new JLabel("reset fields");
		labels[1] = new JLabel("delete");
		labels[2] = new JLabel("edit email");
		labels[3] = new JLabel("reset calendar");
		labels[4] = new JLabel("hint");
		labels[5] = new JLabel("edit event description");
		labels[6] = new JLabel("refresh event list");
		labels[7] = new JLabel("generate");


		for( int i = 0; i < 8; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		
        passwordField = new JPasswordField(10);
        passwordField.setActionCommand(UI_Settings.getOk());
		
		
        List<JTextField> textfields = new ArrayList<JTextField>();
        @SuppressWarnings("rawtypes")
		List<JComboBox> comboboxes = new ArrayList<JComboBox>();
		
		JTextField txtEndDate = new JTextField(12);
        txtEndDate.setEditable(true);
        txtEndDate.setMinimumSize(txtEndDate.getPreferredSize());
        txtEndDate.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtEndDate);
        
		JTextField txtStartDate = new JTextField(12);
		txtStartDate.setEditable(true);
		txtStartDate.setMinimumSize(txtEndDate.getPreferredSize());
		txtStartDate.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtStartDate);
        
		JTextField txtEventName = new JTextField(12);
		txtEventName.setEditable(true);
		txtEventName.setMinimumSize(txtEndDate.getPreferredSize());
		txtEventName.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtEventName);
        
		JTextField txtPreferredEmp1 = new JTextField(12);
		txtPreferredEmp1.setEditable(true);
		txtPreferredEmp1.setMinimumSize(txtPreferredEmp1.getPreferredSize());
		txtPreferredEmp1.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtEventName);
        
		JTextField txtPreferredEmp2 = new JTextField(12);
		txtPreferredEmp2.setEditable(true);
		txtPreferredEmp2.setMinimumSize(txtPreferredEmp2.getPreferredSize());
		txtPreferredEmp2.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtEventName);
        
		JTextField txtPreferredEmp3 = new JTextField(12);
		txtPreferredEmp3.setEditable(true);
		txtPreferredEmp3.setMinimumSize(txtPreferredEmp3.getPreferredSize());
		txtPreferredEmp3.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtEventName);
        
		
		/*********************************************************Create Combo Boxes*********************************************************/
		cmbRequestBy.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbRequestBy.setFont(UI_Settings.getComponentInputFontSize());
		cmbRequestBy.setMinimumSize(cmbRequestBy.getPreferredSize());
		//AutoCompletion.enable(cmbPreferredEmp_1, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbRequestBy);
		
		cmbEventMonth.setPreferredSize(new Dimension(120, 27));
		cmbEventMonth.setFont(UI_Settings.getComponentInputFontSize());
		cmbEventMonth.getEditor().getEditorComponent().setBackground(Color.WHITE);
		//AutoCompletion.enable(cmbStartMonth, 120, 28);
		
		cmbGroupName.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbGroupName.setFont(UI_Settings.getComponentInputFontSize());
		cmbGroupName.setMinimumSize(cmbGroupName.getPreferredSize());
		//AutoCompletion.enable(cmbGroupName, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbGroupName);
		
		cmbPreferredEmp_1.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbPreferredEmp_1.setFont(UI_Settings.getComponentInputFontSize());
		cmbPreferredEmp_1.setMinimumSize(cmbPreferredEmp_1.getPreferredSize());
		//AutoCompletion.enable(cmbPreferredEmp_1, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbPreferredEmp_1);
		
		cmbPreferredEmp_2.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbPreferredEmp_2.setFont(UI_Settings.getComponentInputFontSize());
		cmbPreferredEmp_2.setMinimumSize(cmbPreferredEmp_2.getPreferredSize());
		//AutoCompletion.enable(cmbPreferredEmp_2, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbPreferredEmp_2);
		
		cmbPreferredEmp_3.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbPreferredEmp_3.setFont(UI_Settings.getComponentInputFontSize());
		cmbPreferredEmp_3.setMinimumSize(cmbPreferredEmp_3.getPreferredSize());
		//AutoCompletion.enable(cmbPreferredEmp_2, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbPreferredEmp_3);
		
		/****************************Create the canvas**************************/
		addNorthPanel();
		addSouthPanel();
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
		       int action = JOptionPane.showConfirmDialog(ViewEvents.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		       
		       if(action == JOptionPane.OK_OPTION){
		    	   
		    	   cmbGroupName.setSelectedIndex(0);
				   failedMessage.setVisible(false);
				   failedMessage1.setVisible(false);
				   
				   txtAreaDescription.setText("");
				   
				   txtEventName.setText("");
				   txtStartDate.setText("");
				   txtEndDate.setText("");
				   passwordField.setText("");
				   
				   txtPreferredEmp1.setText("");
				   txtPreferredEmp2.setText("");
				   txtPreferredEmp3.setText("");
				   
		       }
			}
		});
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/******************************************************Add the Reset Panel************************************************/
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(labels[0]);//Reset label
		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		/******************************************************Add The Central Components************************************************/
		int containerHght = (int) (java.awt.Toolkit.getDefaultToolkit().getScreenSize().getHeight()/3*1.3);
		
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, containerHght));
		container.setBackground(Color.WHITE);
			JPanel containerLeft = new JPanel(new GridBagLayout());
			setPanelSize(containerLeft, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, containerHght));
			containerLeft.setBackground(new Color(246,246,246));
			containerLeft.setBorder(border);
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(20,10,0,0);
				containerLeft.add(new JLabel("Click on the event name to select:"),gc);
			
				gc.gridx = 0;
				gc.gridy = 0;
				gc.fill = GridBagConstraints.BOTH;
				gc.insets = new Insets(50,10,10,10);
				containerLeft.add(txtAreaEventList,gc);

		gc.gridx = 0;
		gc.gridy = 0;
		gc.weightx = 0.4;
		gc.weighty = 0.4;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,2,0,2);
		container.add(containerLeft,gc);
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		JPanel trainingRequestsSavedPanel = new JPanel();
		trainingRequestsSavedPanel.setBackground(Color.WHITE);
		trainingRequestsSavedPanel.setLayout(new BoxLayout(trainingRequestsSavedPanel, BoxLayout.X_AXIS));
		
		trainingRequestsSavedPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		trainingRequestsSavedPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		trainingRequestsSavedPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		
		JPanel pnlGenLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
		pnlGenLeft.setBackground(Color.WHITE);
		pnlGenLeft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3*2, UI_Settings.getTableButtonsPanelHeight()));
		pnlGenLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getTableButtonsPanelHeight()));
		pnlGenLeft.add(new JLabel("Request made for: "));
		pnlGenLeft.add(cmbRequestBy);
		pnlGenLeft.add(labels[7]);
		
		JPanel pnlGenRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
		pnlGenRight.setBackground(Color.WHITE);
		pnlGenRight.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
		pnlGenRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
		pnlGenRight.add(chkSendRequest);
		pnlGenRight.add(chkDeleteEvent);

		pnlGenLeft.setAlignmentX(Component.LEFT_ALIGNMENT);
		trainingRequestsSavedPanel.add(pnlGenLeft);
		pnlGenRight.setAlignmentX(Component.RIGHT_ALIGNMENT);
		trainingRequestsSavedPanel.add(pnlGenRight);
		/*******************************************Message panel*************************************************************/
		JPanel pnlInformation = new JPanel();
		pnlInformation.setBackground(Color.WHITE);
		pnlInformation.setLayout(new GridBagLayout());
		setPanelSize(pnlInformation, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 120));
			//Create the far left container for the group details information
			JPanel pnlMessageContainer = new JPanel(new GridBagLayout());
			pnlMessageContainer.setBackground(Color.WHITE);
			setPanelSize(pnlMessageContainer, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, 120));
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,0,0,0);
			
				JPanel pnlMessageArea = new JPanel(new GridBagLayout());
				pnlMessageArea.setBackground(Color.WHITE);
				setPanelSize(pnlMessageArea, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, 120));
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.BOTH;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,0,0,0);
				
				pnlMessageArea.add(txtAreaEmail, gc);
				
					int offset = 10;
				
					JPanel messageButtons = new JPanel();
					messageButtons.setBackground(UI_Settings.getButtonPanelColor());
					messageButtons.setLayout(new BoxLayout(messageButtons, BoxLayout.X_AXIS));
					
					setPanelSize(messageButtons, new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-offset));
					
					JPanel editButton = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
					editButton.setBackground(Color.WHITE);
					editButton.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
					editButton.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
					editButton.add(labels[2]);
	
					
					editButton.setAlignmentX(Component.RIGHT_ALIGNMENT);
					messageButtons.add(editButton);
					
				gc.gridx = 0;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(-10,0,0,0);
				
				pnlMessageArea.add(messageButtons, gc);
				
				/////////////////////////////////////////
				gc.gridx = 0;
				gc.gridy = 0;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,0,5);
				pnlMessageContainer.add(pnlMessageArea, gc);
		pnlInformation.add(pnlMessageContainer, gc);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(0,5,0,5);
		pnlMessageContainer.add(pnlMessageArea, gc);
		/******************************************************Create the Table Data Panel*******************************************/
		
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(buttonPanel);
        
        container.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(container);
        
        centerPanel.add(Box.createVerticalStrut(5));
        
        trainingRequestsSavedPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(trainingRequestsSavedPanel);
        
        centerPanel.add(Box.createVerticalStrut(5));

        
        pnlInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlInformation);
        
        pnlSaveInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlSaveInformation);
		/*********************************************************************************************************************************/

        canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 800));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 800));
		canvas.add(headerMessagePanel, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
	
		JScrollPane scroller = new JScrollPane(canvas);

		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());

		return scroller;
	}
	
	private void addNorthPanel() {
		JPanel heading = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		JLabel lblHeading = new JLabel("Viewing scheduled event details");
		heading.setBackground(Color.WHITE);
		lblHeading.setFont(lblHeading.getFont().deriveFont(16.0f));
		heading.add(lblHeading);
		
		JPanel headingMessage = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		headingMessage.setBackground(Color.WHITE);
		JLabel lblHeadingMessage = new JLabel("Viewing scheduled event details is simple. Choose the event name from the dropdown box below or select the month to search.\n"
				+ "If you want to get more details double click on the event tile from the area below.");
		
		headingMessage.add(lblHeadingMessage);

		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-30));
		detailsPanel.setLayout(new GridBagLayout());
		
		headerMessagePanel = new JPanel(new GridBagLayout());
		setPanelSize(headerMessagePanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 100));
		headerMessagePanel.setBackground(Color.WHITE);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		headerMessagePanel.add(heading,gc);
		
		gc.gridy = 1;
		gc.insets = new Insets(-15,0,0,0);
		headerMessagePanel.add(headingMessage, gc);
	
		gc.gridy = 2;
		gc.insets = new Insets(-30,0,0,0);
		headerMessagePanel.add(detailsPanel, gc);
		
		JPanel firstRow = new JPanel();
		firstRow.setBackground(UI_Settings.getButtonPanelColor());
		firstRow.setLayout(new BoxLayout(firstRow, BoxLayout.X_AXIS));
		
		JPanel fieldcontainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		fieldcontainer.setBackground(Color.WHITE);
		fieldcontainer.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 50));
		fieldcontainer.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 50));
		fieldcontainer.add(new JLabel("Group Name:"));
		fieldcontainer.add(cmbGroupName);
		fieldcontainer.add(new JLabel("Event Month:"));
		fieldcontainer.add(cmbEventMonth);
		
		fieldcontainer.setAlignmentX(Component.LEFT_ALIGNMENT);
		firstRow.add(fieldcontainer);
		
		firstRow.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,30));
		firstRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 30));

		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(17,0,0,0);
		detailsPanel.add(firstRow, gc);
		
	}
	
	private void setPanelSize(JPanel container, Dimension dimension) {
		
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
		
	}
	
	private void addSouthPanel() {
		//Begin Nested Details Panels (lowest panel on screen)
		pnlSaveInformation = new JPanel();
		pnlSaveInformation.setBackground(Color.WHITE);
		pnlSaveInformation.setLayout(new GridBagLayout());
		pnlSaveInformation.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveInformation.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveInformation.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		
		//Begin Nested Details Panels (lowest panel on screen)
		JPanel pnlSaveRow = new JPanel();
		pnlSaveRow.setBackground(Color.WHITE);
		pnlSaveRow.setLayout(new GridBagLayout());
		pnlSaveRow.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));

			//Create the far left container for the group details information
			JPanel pnlSaveLeftPane = new JPanel(new GridBagLayout());
			pnlSaveLeftPane.setBackground(Color.WHITE);
			pnlSaveLeftPane.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			
			//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,0,0,0);
			
				//Add the nested panels to the container panel (information panel)
			
				JPanel panel3 = new JPanel(new GridBagLayout());
				panel3.setBackground(Color.WHITE);
				panel3.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				
				
				JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row1.setBackground(Color.WHITE);
				row1.add(new JLabel("Table updated:"));
				row1.add(lblDate);
				
				JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row2.setBackground(Color.WHITE);
				row2.add(new JLabel("Connected to: " /*+ controller.getDBname()*/));
				
				JPanel row3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row3.setBackground(Color.WHITE);
				row3.add(new JLabel("Connection: Secure"));
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(5,5,0,5);
			
				panel3.add(row1, gc);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.insets = new Insets(0,5,0,5);
			
				panel3.add(row2, gc);
				
				gc.gridx = 0;
				gc.gridy = 2;
				gc.insets = new Insets(0,5,45,5);
			
				panel3.add(row3, gc);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.insets = new Insets(0,5,20,5);
			
				pnlSaveLeftPane.add(panel3, gc);
		
		pnlSaveRow.add(pnlSaveLeftPane, gc);
			
		//Create the second panel from the left (comments panel)
		JPanel pnlSaveRight = new JPanel(new GridBagLayout());
		pnlSaveRight.setBackground(Color.WHITE);
		pnlSaveRight.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));

			gc.gridx = 1;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHEAST;
			gc.insets = new Insets(0,0,0,0);
			pnlSaveRight.add(btnDeleteEvent, gc);
			
			pnlSaveRow.add(pnlSaveRight, gc);
		
		pnlSaveInformation.add(pnlSaveRow, gc);
	}
	
/*	private void populateComboBoxes() throws Exception {
		controller.connect();
		controller.load();
		
		List<Group> group_list = new ArrayList<Group>();
	    model = new DefaultComboBoxModel<String>();


		group_list = Controller.getGroup();


		for(int i = 0; i < group_list.size(); i++){
			model.addElement(group_list.get(i).getGroupName());

		}
		
		cmbMoveFromGroupName.setModel(model);
		cmbMoveFromGroupName.setSelectedIndex(-1);
		
	
		controller.disconnect();
	}*/

}
