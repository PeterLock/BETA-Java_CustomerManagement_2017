package events.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField.AbstractFormatter;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ColorUIResource;

import control.build.TableTemplate;
import settings.UI_Settings;
import utilities.JTextFieldLimit;
import utilities.SentryModule;
import utilities.TextPrompt;
import utilities.UniqueIDGenerator;

public class EventsPane extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static JTabbedPane pane = new JTabbedPane();
	UniqueIDGenerator idGenerator = new UniqueIDGenerator();
    JPasswordField passwordField;
    JFrame controllingFrame; //needed for dialogs



	TextPrompt textPrompt;

	/**********************************************************************************************************************************/
	////////////View Scheduled Open Houses Tab////////////////
	TD_ViewAllOH viewAllTableData = new TD_ViewAllOH();
	TableTemplate viewAllTable = new TableTemplate(viewAllTableData, TD_ViewAllOH.getCOLUMN_PERCENTAGES(), "");
	
	
	TD_EGroupMembers groupMemberTableData = new TD_EGroupMembers();
	TableTemplate groupMembersTable = new TableTemplate(groupMemberTableData, groupMemberTableData.getCOLUMN_PERCENTAGES(), "Group Members");

	
	TD_EGroupDetails groupDetailsTableData = new TD_EGroupDetails();
	TableTemplate groupDetailsTable = new TableTemplate(groupDetailsTableData, groupDetailsTableData.getCOLUMN_PERCENTAGES(), "Group Details");
	
	////////////Add Open House Tab////////////////////////////
	TD_EGroupMembers addGroupMemberTableData = new TD_EGroupMembers();
	TableTemplate addGroupMembersTable = new TableTemplate(addGroupMemberTableData, addGroupMemberTableData.getCOLUMN_PERCENTAGES(), "");

	
	TD_EAdded openHouseAddedTableData = new TD_EAdded();
	TableTemplate openHouseAddedTable = new TableTemplate(openHouseAddedTableData, openHouseAddedTableData.getCOLUMN_PERCENTAGES(), "");
	/**********************************************************************************************************************************/
	
	public EventsPane() {
        initializeUI();
    }

    private void initializeUI() {
    	
    	UIManager.put("Label.font", UI_Settings.getComponentsFontPlain());
    	UIManager.put("Label.foreground", UI_Settings.getComponentsFontColorDark());
    	
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, java.awt.Toolkit.getDefaultToolkit().getScreenSize().height));

        //OK
        UIManager.put("TabbedPane.selected", new ColorUIResource(UI_Settings.getBottomTabColor()));
        UIManager.put("TabbedPane.unselectedTabBackground", UI_Settings.getCmsGray());    
        
     	UIManager.put("OptionPane.messageFont", new Font("System", Font.PLAIN, 12));
    	UIManager.put("OptionPane.buttonFont", new Font("System", Font.PLAIN, 12));
        
        pane.setForeground(Color.WHITE);
        pane.setFocusable(false);
        pane.setBorder(new EmptyBorder(0, 0, 0, 0));


        //OK
        UIManager.getDefaults().put("TabbedPane.tabAreaInsets", new Insets(0,0,0,0));
        UIManager.put("TabbedPane.contentBorderInsets", new Insets(0, 0, 0, 0)); 
        

        //Sets the JPanel container to black
        setBackground(UI_Settings.getCmsTabSecondLvlGrey());
        pane.addTab("<html><body><table width='150' style='font-size:11'><td style='text-align:center'>View Scheduled Events</td></table></body></html>", viewEvent());//0
        pane.addTab("<html><body><table width='150' style='font-size:11'><td style='text-align:center'>Add Event</td></table></body></html>", addEvent());//1
        
        //Set the text color for each tab
        pane.setForeground(Color.WHITE);

        pane.setBackgroundAt(0, UI_Settings.getCmsGray());	//0
        pane.setBackgroundAt(1, UI_Settings.getCmsGray());	//1

    
        changeUI(UI_Settings.getBottomTabColor());

    }

    public void changeUI( Color bottomTabColor) {
        pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
            @Override protected int calculateTabHeight(
              int tabPlacement, int tabIndex, int fontHeight) {
            	
    	       highlight = UI_Settings.getCmsTabSecondLvlGrey();
    	       lightHighlight = UI_Settings.getCmsTabSecondLvlGrey();
    	       shadow = UI_Settings.getCmsTabSecondLvlGrey();
    	       darkShadow = UI_Settings.getCmsTabSecondLvlGrey();
    	       focus = UI_Settings.getCmsTabSecondLvlGrey();
            	
              return 27;
            }
            
            
            @Override protected void paintTab(
              Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
              Rectangle iconRect, Rectangle textRect) {
        
               rects[tabIndex].height = 25 + 1;
               rects[tabIndex].y = 20 - rects[tabIndex].height + 7;
              
              super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
            }
          });
        
        //Add the tab to the canvas
        this.add(pane, BorderLayout.CENTER);		
	}

	public static void showFrame() {
        JPanel panel = new EventsPane();
        panel.setOpaque(true);

        JFrame frame = new JFrame("CMS Test Screen");
        JFrame.setDefaultLookAndFeelDecorated(false);
        frame.setPreferredSize(UI_Settings.getMinimumScreenSize());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(panel);
        frame.pack();
        frame.setVisible(true);
    }
    
    public void changeTheme(Color c) {
      UIManager.put("TabbedPane.selected",new ColorUIResource(c));
		 
      pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
          @Override protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
            return 27;
          }
      });
      
	pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
	    @Override protected int calculateTabHeight(
	      int tabPlacement, int tabIndex, int fontHeight) {
	    	
	       highlight = UI_Settings.getCmsTabSecondLvlGrey();
	       lightHighlight = UI_Settings.getCmsTabSecondLvlGrey();
	       shadow = UI_Settings.getCmsTabSecondLvlGrey();
	       darkShadow = UI_Settings.getCmsTabSecondLvlGrey();
	       focus = UI_Settings.getCmsTabSecondLvlGrey();
	    	
	      return 27;
	    }
	    
	    
	    @Override protected void paintTab(
	      Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
	      Rectangle iconRect, Rectangle textRect) {
	
	       rects[tabIndex].height = 25 + 1;
	       rects[tabIndex].y = 20 - rects[tabIndex].height + 7;
	      
	      super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
	    }
	  });
	}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                EventsPane.showFrame();
            }
        });
    }

	public Component viewEvent()
	{
		JPanel canvas;
		JPanel detailsPanel;
		JPanel centerPanel;
		
		JButton btnDeleteEvent;
		
		JTextArea txtAreaDescription;
		JTextArea txtAreaEventList;
		JTextArea txtAreaEmail;

		btnDeleteEvent = new JButton("Perform Action");
		btnDeleteEvent.setPreferredSize(new Dimension(200,UI_Settings.getJbuttonSize().height));
		btnDeleteEvent.setMinimumSize(new Dimension(200,UI_Settings.getJbuttonSize().height));

		btnDeleteEvent.setFont(UI_Settings.getComponentInputFontSize());
		
		JCheckBox chkSendRequest = new JCheckBox("send event office request");
		JCheckBox chkDeleteEvent = new JCheckBox("delete event");
		
		chkSendRequest.setFont(UI_Settings.getComponentsFontPlain());
		chkSendRequest.setForeground(UI_Settings.getComponentsFontColorLight());
		
		chkDeleteEvent.setFont(UI_Settings.getComponentsFontPlain());
		chkDeleteEvent.setForeground(UI_Settings.getComponentsFontColorLight());

		/***************************************************Create textAreas********************************************************************/
		
		txtAreaDescription = new JTextArea(5, 35);
		txtAreaDescription.setMinimumSize(txtAreaDescription.getPreferredSize());
		txtAreaDescription.setEditable(true);
		Border line = BorderFactory.createLineBorder(new Color(224,224,224));
		Border empty = new EmptyBorder(5, 5, 5, 0);
		CompoundBorder border = new CompoundBorder(line, empty);
		txtAreaDescription.setBorder(border);
		txtAreaDescription.setWrapStyleWord(true);
		txtAreaDescription.setLineWrap(true);
		textPrompt = new TextPrompt("<no description found>", txtAreaDescription);
		txtAreaDescription.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaDescription.setMargin( new Insets(15,50,10,10) );
		
		
		txtAreaEventList = new JTextArea(5, 35);
		txtAreaEventList.setMinimumSize(txtAreaEventList.getPreferredSize());
		txtAreaEventList.setEditable(true);
		txtAreaEventList.setBorder(border);
		txtAreaEventList.setWrapStyleWord(true);
		txtAreaEventList.setLineWrap(true);
		textPrompt = new TextPrompt("<no events found>", txtAreaEventList);
		txtAreaEventList.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaEventList.setMargin( new Insets(5,5,5,5) );
		
		txtAreaEmail = new JTextArea(5, 35);
		txtAreaEmail.setMinimumSize(txtAreaEventList.getPreferredSize());
		txtAreaEmail.setEditable(true);
		txtAreaEmail.setBorder(border);
		txtAreaEmail.setWrapStyleWord(true);
		txtAreaEmail.setLineWrap(true);
		textPrompt = new TextPrompt("<no requests for office time found>", txtAreaEmail);
		txtAreaEmail.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaEmail.setMargin( new Insets(5,5,5,5) );
		
		/***********************Initialize Fields******************************/
		JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());

		failedMessage.setVisible(false);
		
		JLabel failedMessage1 = new JLabel(UI_Settings.getFailedMessage());
		failedMessage1.setForeground(UI_Settings.getFailedMessageColor());

		failedMessage1.setVisible(false);
		
		JLabel labels[] = new JLabel[8];
		
		labels[0] = new JLabel("reset fields");
		labels[1] = new JLabel("delete");
		labels[2] = new JLabel("edit email");
		labels[3] = new JLabel("reset calendar");
		labels[4] = new JLabel("hint");
		labels[5] = new JLabel("edit event description");
		labels[6] = new JLabel("refresh event list");
		labels[7] = new JLabel("generate");


		for( int i = 0; i < 8; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		
        passwordField = new JPasswordField(10);
        passwordField.setActionCommand(UI_Settings.getOk());
		
		
        List<JTextField> textfields = new ArrayList<JTextField>();
        @SuppressWarnings("rawtypes")
		List<JComboBox> comboboxes = new ArrayList<JComboBox>();
		
		JTextField txtEndDate = new JTextField(12);
        txtEndDate.setEditable(true);
        txtEndDate.setMinimumSize(txtEndDate.getPreferredSize());
        txtEndDate.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtEndDate);
        
		JTextField txtStartDate = new JTextField(12);
		txtStartDate.setEditable(true);
		txtStartDate.setMinimumSize(txtEndDate.getPreferredSize());
		txtStartDate.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtStartDate);
        
		JTextField txtEventName = new JTextField(12);
		txtEventName.setEditable(true);
		txtEventName.setMinimumSize(txtEndDate.getPreferredSize());
		txtEventName.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtEventName);
        
		JTextField txtPreferredEmp1 = new JTextField(12);
		txtPreferredEmp1.setEditable(true);
		txtPreferredEmp1.setMinimumSize(txtPreferredEmp1.getPreferredSize());
		txtPreferredEmp1.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtEventName);
        
		JTextField txtPreferredEmp2 = new JTextField(12);
		txtPreferredEmp2.setEditable(true);
		txtPreferredEmp2.setMinimumSize(txtPreferredEmp2.getPreferredSize());
		txtPreferredEmp2.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtEventName);
        
		JTextField txtPreferredEmp3 = new JTextField(12);
		txtPreferredEmp3.setEditable(true);
		txtPreferredEmp3.setMinimumSize(txtPreferredEmp3.getPreferredSize());
		txtPreferredEmp3.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtEventName);
        
		
		/*********************************************************Create Combo Boxes*********************************************************/
		JComboBox cmbGroupName = new JComboBox(UI_Settings.getGroups());
		JComboBox cmbRequestBy = new JComboBox(UI_Settings.getEmployeeNames());

		JComboBox cmbPreferredEmp_1 = new JComboBox(UI_Settings.getEmployeeNames());
		JComboBox cmbPreferredEmp_2 = new JComboBox(UI_Settings.getEmployeeNames());
		JComboBox cmbPreferredEmp_3 = new JComboBox(UI_Settings.getEmployeeNames());
		JComboBox cmbEventMonth = new JComboBox(UI_Settings.getMonths());

		cmbRequestBy.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbRequestBy.setFont(UI_Settings.getComponentInputFontSize());
		cmbRequestBy.setMinimumSize(cmbRequestBy.getPreferredSize());
		//AutoCompletion.enable(cmbPreferredEmp_1, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbRequestBy);
		
		cmbEventMonth.setPreferredSize(new Dimension(120, 27));
		cmbEventMonth.setFont(UI_Settings.getComponentInputFontSize());
		cmbEventMonth.getEditor().getEditorComponent().setBackground(Color.WHITE);
		//AutoCompletion.enable(cmbStartMonth, 120, 28);
		
		cmbGroupName.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbGroupName.setFont(UI_Settings.getComponentInputFontSize());
		cmbGroupName.setMinimumSize(cmbGroupName.getPreferredSize());
		//AutoCompletion.enable(cmbGroupName, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbGroupName);
		
		cmbPreferredEmp_1.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbPreferredEmp_1.setFont(UI_Settings.getComponentInputFontSize());
		cmbPreferredEmp_1.setMinimumSize(cmbPreferredEmp_1.getPreferredSize());
		//AutoCompletion.enable(cmbPreferredEmp_1, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbPreferredEmp_1);
		
		cmbPreferredEmp_2.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbPreferredEmp_2.setFont(UI_Settings.getComponentInputFontSize());
		cmbPreferredEmp_2.setMinimumSize(cmbPreferredEmp_2.getPreferredSize());
		//AutoCompletion.enable(cmbPreferredEmp_2, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbPreferredEmp_2);
		
		cmbPreferredEmp_3.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbPreferredEmp_3.setFont(UI_Settings.getComponentInputFontSize());
		cmbPreferredEmp_3.setMinimumSize(cmbPreferredEmp_3.getPreferredSize());
		//AutoCompletion.enable(cmbPreferredEmp_2, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbPreferredEmp_3);
		
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/**********************Create the components panel***********************/
		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 120));
		detailsPanel.setLayout(new GridBagLayout());
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
		       int action = JOptionPane.showConfirmDialog(EventsPane.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		       
		       if(action == JOptionPane.OK_OPTION){
		    	   
		    	   cmbGroupName.setSelectedIndex(0);
				   failedMessage.setVisible(false);
				   failedMessage1.setVisible(false);
				   
				   txtAreaDescription.setText("");
				   
				   txtEventName.setText("");
				   txtStartDate.setText("");
				   txtEndDate.setText("");
				   passwordField.setText("");
				   
				   txtPreferredEmp1.setText("");
				   txtPreferredEmp2.setText("");
				   txtPreferredEmp3.setText("");
				   
		       }
			}
		});
		GridBagConstraints gc = new GridBagConstraints();
		
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/**********************Create the components panel***********************/
		detailsPanel = new JPanel();
		detailsPanel.setBackground(UI_Settings.getButtonPanelColor());
		detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.X_AXIS));
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-30));
		/******************************************************Add the Header Panel************************************************/
		
		JPanel dpLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 30));
		dpLeft.setBackground(Color.WHITE);
		dpLeft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		dpLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));

		dpLeft.add(new JLabel("Group Name:"));
		dpLeft.add(cmbGroupName);
		
		dpLeft.add(new JLabel("Event Month:"));
		dpLeft.add(cmbEventMonth);

		
		JPanel dpRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 2));
		dpRight.setBackground(Color.WHITE);
		setPanelSize(dpRight, new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		
		dpLeft.setAlignmentX(Component.LEFT_ALIGNMENT);
		detailsPanel.add(dpLeft);
		
		dpRight.setAlignmentX(Component.RIGHT_ALIGNMENT);
		detailsPanel.add(dpRight);
		
		/******************************************************Add the Reset Panel************************************************/
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(labels[0]);//Reset label
		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		/******************************************************Add The Central Components************************************************/
		int containerHght = (int) (java.awt.Toolkit.getDefaultToolkit().getScreenSize().getHeight()/3*1.5);
		
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, containerHght));
		container.setBackground(Color.WHITE);

			JPanel containerLeft = new JPanel(new GridBagLayout());
			setPanelSize(containerLeft, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, containerHght));
			containerLeft.setBackground(new Color(246,246,246));
			containerLeft.setBorder(border);
			
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(20,10,0,0);
				containerLeft.add(new JLabel("Click on the event name to select:"),gc);
			
				gc.gridx = 0;
				gc.gridy = 0;
				gc.fill = GridBagConstraints.BOTH;
				gc.insets = new Insets(50,10,10,10);
				containerLeft.add(txtAreaEventList,gc);
			
				JPanel containerRight = new JPanel(new GridBagLayout());
				setPanelSize(containerRight, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, containerHght));
				containerRight.setBackground(Color.LIGHT_GRAY);
					
					int datesoffset = 20;

					JPanel scheduleDatesContainer = new JPanel(new GridBagLayout());
					setPanelSize(scheduleDatesContainer, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-datesoffset));
					scheduleDatesContainer.setBackground(Color.WHITE);
					

					JPanel datesLeft = new JPanel(new GridBagLayout());
					setPanelSize(datesLeft, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getSmallPanelHeight()-datesoffset));
					datesLeft.setBackground(Color.WHITE);
					datesLeft.setBorder(border);
				
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 0.5;
					gc.weighty = 0.5;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(0,10,0,0);
					datesLeft.add(new JLabel("Scheduled From:"), gc);
					
					gc.gridx = 1;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.insets = new Insets(0,0,0,15);
					datesLeft.add(txtStartDate, gc);

					JPanel datesRight = new JPanel(new GridBagLayout());
					setPanelSize(datesRight, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getSmallPanelHeight()-datesoffset));
					datesRight.setBackground(new Color(246,246,246));
					datesRight.setBorder(border);
				
					gc.gridx = 0;
					gc.gridy = 0;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(0,10,0,0);
					datesRight.add(new JLabel("Scheduled To:"), gc);
					
					gc.gridx = 1;
					gc.insets = new Insets(0,0,0,15);
					datesRight.add(txtEndDate, gc);

			
					gc.gridx = 0;
					gc.gridy = 0;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(0,5,5,5);
					container.add(containerLeft, gc);
					
					gc.gridx = 0;
					scheduleDatesContainer.add(datesLeft, gc);
					
					gc.gridx = 1;
					gc.insets = new Insets(0,5,5,10);
					scheduleDatesContainer.add(datesRight, gc);
					
					gc.gridx = 0;
					gc.gridy = 0;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(0,0,0,0);
					containerRight.add(scheduleDatesContainer, gc);
					
					//Add the lower components to containerRight - event description - preferred instructors//
					JPanel banner = new JPanel(new GridBagLayout());
					setPanelSize(banner, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getSmallPanelHeight()-datesoffset*2));
					banner.setBackground(Color.WHITE);
					
					int banneroffsetfromtop = UI_Settings.getSmallPanelHeight() - datesoffset;
					
					JPanel bannertext = new JPanel(new FlowLayout(FlowLayout.LEFT, 10,7));
					
					bannertext.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3*2, UI_Settings.getTableButtonsPanelHeight()));
					bannertext.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getTableButtonsPanelHeight()));
					bannertext.setBackground(Color.WHITE);
					bannertext.add(new JLabel("Event Description:"));
					
					gc.gridx = 0;
					gc.gridy = 0;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.SOUTHWEST;
					gc.insets = new Insets(0,0,10,0);
					banner.add(bannertext, gc);
					
					
					gc.gridx = 0;
					gc.gridy = 0;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(banneroffsetfromtop,0,0,0);
					containerRight.add(banner,gc);
					
					int contentsheight = (containerHght-banneroffsetfromtop*2)+UI_Settings.getTableButtonsPanelHeight();
					
					JPanel contents = new JPanel(new GridBagLayout());
					setPanelSize(contents, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, contentsheight));
					contents.setBackground(Color.GREEN);
					
						JPanel contentsLeft = new JPanel(new GridBagLayout());
						setPanelSize(contentsLeft, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, contentsheight));
						contentsLeft.setBackground(Color.WHITE);
						
						gc.gridx = 0;
						gc.gridy = 0;
						gc.fill = GridBagConstraints.BOTH;
						gc.anchor = GridBagConstraints.SOUTHWEST;
						gc.insets = new Insets(0,5,0,10);
						contentsLeft.add(txtAreaDescription,gc);
						
						
						JPanel contentsRight = new JPanel(new GridBagLayout());
						setPanelSize(contentsRight, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, contentsheight));
						contentsRight.setBackground(Color.WHITE);
						
							JPanel reportDetails = new JPanel(new GridBagLayout());
							
							setPanelSize(reportDetails, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-30));
							
							reportDetails.setBackground(new Color(246,246,246));
							reportDetails.setBorder(border);
							
							gc.gridx = 0;
							gc.gridy = 0;
							gc.fill = GridBagConstraints.HORIZONTAL;
							gc.anchor = GridBagConstraints.WEST;
							gc.insets = new Insets(0,10,0,0);
							reportDetails.add(new JLabel("Preferred Instructor 1:"), gc);
							
							gc.gridx = 0;
							gc.gridy = 1;
							reportDetails.add(new JLabel("Preferred Instructor 2:"), gc);
							
							gc.gridx = 0;
							gc.gridy = 2;
							reportDetails.add(new JLabel("Preferred Instructor 3:"), gc);
							
							
							gc.gridx = 1;
							gc.gridy = 0;
							gc.insets = new Insets(0,0,0,15);
							reportDetails.add(txtPreferredEmp1, gc);
							
							gc.gridx = 1;
							gc.gridy = 1;
							reportDetails.add(txtPreferredEmp2, gc);
							
							gc.gridx = 1;
							gc.gridy = 2;
							reportDetails.add(txtPreferredEmp3, gc);
							
						
							gc.gridx = 0;
							gc.gridy = 0;
							gc.weightx = 0.3;
							gc.weighty = 0.3;
							gc.anchor = GridBagConstraints.NORTHWEST;
							gc.insets = new Insets(0,0,0,10);
							contentsRight.add(reportDetails, gc);
							

						gc.gridx = 0;
						gc.gridy = 0;
						gc.anchor = GridBagConstraints.SOUTHWEST;
						gc.insets = new Insets(0,0,0,0);
						contents.add(contentsLeft,gc);
						gc.gridx = 1;
						gc.gridy = 0;
						contents.add(contentsRight,gc);
					
					
					gc.gridx = 0;
					gc.gridy = 0;
					gc.insets = new Insets(banneroffsetfromtop,0,0,0);
					containerRight.add(contents, gc);
					

		gc.gridx = 0;
		gc.gridy = 0;
		gc.weightx = 0.4;
		gc.weighty = 0.4;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,2,0,2);
		container.add(containerLeft,gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.weightx = 1;
		gc.weighty = 1;
		container.add(containerRight,gc);
		
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		/******************************************Generate request panel***************************************/
		
		JPanel trainingRequestsSavedPanel = new JPanel();
		trainingRequestsSavedPanel.setBackground(Color.WHITE);
		trainingRequestsSavedPanel.setLayout(new BoxLayout(trainingRequestsSavedPanel, BoxLayout.X_AXIS));
		
		trainingRequestsSavedPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		trainingRequestsSavedPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		trainingRequestsSavedPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel pnlGenLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
		pnlGenLeft.setBackground(Color.WHITE);
		pnlGenLeft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3*2, UI_Settings.getTableButtonsPanelHeight()));
		pnlGenLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getTableButtonsPanelHeight()));
		pnlGenLeft.add(new JLabel("Request made for: "));
		pnlGenLeft.add(cmbRequestBy);
		pnlGenLeft.add(labels[7]);

		
		JPanel pnlGenRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
		pnlGenRight.setBackground(Color.WHITE);
		pnlGenRight.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
		pnlGenRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
		pnlGenRight.add(chkSendRequest);
		pnlGenRight.add(chkDeleteEvent);

		
		pnlGenLeft.setAlignmentX(Component.LEFT_ALIGNMENT);
		trainingRequestsSavedPanel.add(pnlGenLeft);
		
		pnlGenRight.setAlignmentX(Component.RIGHT_ALIGNMENT);
		trainingRequestsSavedPanel.add(pnlGenRight);
		
		/*******************************************Message panel*************************************************************/
		//Begin Nested Details Panels (lowest panel on screen)
		JPanel pnlInformation = new JPanel();
		pnlInformation.setBackground(Color.WHITE);
		pnlInformation.setLayout(new GridBagLayout());
		
		setPanelSize(pnlInformation, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		

			//Create the far left container for the group details information
			JPanel pnlMessageContainer = new JPanel(new GridBagLayout());
			pnlMessageContainer.setBackground(Color.WHITE);
			
			setPanelSize(pnlMessageContainer, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-20));
			
			//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,0,0,0);
			
				//Add the nested panels to the container panel (information panel)
			
				JPanel pnlMessageArea = new JPanel(new GridBagLayout());
				pnlMessageArea.setBackground(Color.WHITE);
				Border informationBorder = BorderFactory.createLineBorder(Color.LIGHT_GRAY);
				//pnlMessageArea.setBorder(informationBorder);
				
				setPanelSize(pnlMessageArea, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-20));
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.BOTH;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,0,0,0);
				
				pnlMessageArea.add(txtAreaEmail, gc);
				
					int offset = 10;
				
					JPanel messageButtons = new JPanel();
					messageButtons.setBackground(UI_Settings.getButtonPanelColor());
					messageButtons.setLayout(new BoxLayout(messageButtons, BoxLayout.X_AXIS));
					
					setPanelSize(messageButtons, new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-offset));
					
					JPanel messageText = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 10));
					messageText.setBackground(Color.WHITE);
					messageText.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
					messageText.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
					messageText.add(new JLabel("Office Time Requests are automatically saved"));
					
					JPanel editButton = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
					editButton.setBackground(Color.WHITE);
					editButton.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
					editButton.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
					editButton.add(labels[2]);
	
					
					messageText.setAlignmentX(Component.LEFT_ALIGNMENT);
					messageButtons.add(messageText);
					
					editButton.setAlignmentX(Component.RIGHT_ALIGNMENT);
					messageButtons.add(editButton);
					
				gc.gridx = 0;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(-10,0,0,0);
				
				pnlMessageArea.add(messageButtons, gc);
				
				/////////////////////////////////////////
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,17,5);
			
				pnlMessageContainer.add(pnlMessageArea, gc);
				
		
		pnlInformation.add(pnlMessageContainer, gc);
		
		/////////////////////////////////////////
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(0,5,0,5);
	
		pnlMessageContainer.add(pnlMessageArea, gc);
		//////////////////////////////////////////Main Column 3 ///////////////////////////////////////////
		JPanel pnlButtons = new JPanel(new GridBagLayout());
		pnlButtons.setBackground(Color.WHITE);
		
		setPanelSize(pnlButtons, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3+10, UI_Settings.getRegularPanelHeight()));
		
			JPanel pnlPassword = new JPanel(new GridBagLayout());
			pnlPassword.setBackground(new Color(246,246,246));
			pnlPassword.setBorder(informationBorder);
			
			setPanelSize(pnlPassword, new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)+10, UI_Settings.getRegularPanelHeight()-50));
			
			int password;
			btnDeleteEvent.addMouseListener(new MouseAdapter(){
				public void mouseReleased(MouseEvent e){
					
/*					if(txtAreaEmail.getText().equals("")){
						System.err.println("Nothing there");
						return;
					}*/
					
					SentryModule module = new SentryModule();
					
			           char[] input = passwordField.getPassword();
			            if (module.takeInput(input)) {
			                JOptionPane.showMessageDialog(controllingFrame,
			                    "Welcome administrator. The office time request has been sent.");
			            } else {
			                JOptionPane.showMessageDialog(controllingFrame,
			                    "To send an office time request please enter the correct password.",
			                    "Error Message",
			                    JOptionPane.ERROR_MESSAGE);
			            }
	
			            //Zero out the possible password, for security.
			            Arrays.fill(input, '0');
	
			            passwordField.selectAll();
					
				}
			});
			
			labels[4].setCursor(UI_Settings.getJlabelCursor());
			labels[4].addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e){
					
					JOptionPane.showMessageDialog(controllingFrame,
			                "The administrator password can be found with the \"Kids Coordinator\"\n"
			              + "or by contacting your \"Branch Manager\".");
					
				}
			});
			JPanel adminPanel = new JPanel(new GridBagLayout());
			adminPanel.setBackground(Color.WHITE);

			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.1;
			gc.weighty = 0.1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,10,0,0);
			
			adminPanel.add(new JLabel("Administrator password:"), gc);
			
			gc.gridx = 1;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,5,0,0);
			
			adminPanel.add(passwordField, gc);
			
			gc.gridx = 2;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.2;
			gc.weighty = 0.2;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,5,0,5);
			adminPanel.add(labels[4], gc);
			
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTH;
			gc.insets = new Insets(15,0,0,0);
			
			pnlPassword.add(adminPanel, gc);
			

			gc.gridx = 0;
			gc.gridy = 2;
			gc.insets = new Insets(-5,5,10,0);
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			pnlPassword.add(btnDeleteEvent, gc);//Send request button
			
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.anchor = GridBagConstraints.NORTH;
			gc.insets = new Insets(0,0,0,0);
			
			pnlButtons.add(pnlPassword, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(-15,0,0,5);
			
			
			pnlButtons.add(new JLabel("This action cannot be undone"), gc);
		
		gc.gridx = 2;
		gc.gridy = 0;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,10);
		
		//Add the nested panels to the container panel (information panel)
		pnlInformation.add(pnlButtons, gc);
				
		/******************************************************Create the Table Data Panel*******************************************/
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        detailsPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(detailsPanel);

        buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(buttonPanel);
        
        container.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(container);
        
        trainingRequestsSavedPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(trainingRequestsSavedPanel);
        
        pnlInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlInformation);
        
        
		/*********************************************************************************************************************************/
    	/////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 700));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 700));

		//Add the details section and table sections to the canvas.
		canvas.add(detailsPanel, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
	
		
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(canvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());

		return scroller;
	}//END addOpenHouse
	
	private void setPanelSize(JPanel container, Dimension dimension) {
		
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
		
	}

	public Component addEvent()
	{
		JPanel canvas;
		JPanel detailsPanel;
		JPanel centerPanel;
		
		JButton btnSaveEvent;
		
		JTextArea txtAreaDescription;

		btnSaveEvent = new JButton("Save Event");
		btnSaveEvent.setPreferredSize(new Dimension(150,UI_Settings.getJbuttonSize().height));
		btnSaveEvent.setMinimumSize(new Dimension(150,UI_Settings.getJbuttonSize().height));

		btnSaveEvent.setFont(UI_Settings.getComponentInputFontSize());
		
		/***********************Initialize Fields******************************/
		JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());

		failedMessage.setVisible(false);
		
		JLabel failedMessage1 = new JLabel(UI_Settings.getFailedMessage());
		failedMessage1.setForeground(UI_Settings.getFailedMessageColor());

		failedMessage1.setVisible(false);
		
		JLabel labels[] = new JLabel[5];
		
		labels[0] = new JLabel("reset fields");
		labels[1] = new JLabel("delete");
		labels[2] = new JLabel("edit");
		labels[3] = new JLabel("auto-fill preferred instructors");
		labels[4] = new JLabel("hint");


		for( int i = 0; i < 5; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		
        passwordField = new JPasswordField(10);
        passwordField.setActionCommand(UI_Settings.getOk());
		
		
        List<JTextField> textfields = new ArrayList<JTextField>();
        @SuppressWarnings("rawtypes")
		List<JComboBox> comboboxes = new ArrayList<JComboBox>();
		
		JTextField txtEndDate = new JTextField(12);
        txtEndDate.setEditable(true);
        txtEndDate.setMinimumSize(txtEndDate.getPreferredSize());
        txtEndDate.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtEndDate);
        
		JTextField txtStartDate = new JTextField(12);
		txtStartDate.setEditable(true);
		txtStartDate.setMinimumSize(txtEndDate.getPreferredSize());
		txtStartDate.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtStartDate);
        
		JTextField txtEventName = new JTextField(12);
		txtEventName.setEditable(true);
		txtEventName.setMinimumSize(txtEndDate.getPreferredSize());
		txtEventName.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtEventName);
        
		
        
		/***************************************************Create textAreas********************************************************************/
		txtAreaDescription = new JTextArea(6, 30);
		txtAreaDescription.setEditable(true);
		txtAreaDescription.setMinimumSize(new Dimension((int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth()/2, (int)txtAreaDescription.getPreferredSize().getHeight()));
		txtAreaDescription.setBorder(UI_Settings.getBorderoutline());
		txtAreaDescription.setWrapStyleWord(true);
		txtAreaDescription.setLineWrap(true);
		txtAreaDescription.setDocument(new JTextFieldLimit(250));
		textPrompt = new TextPrompt("<enter a description of the event>", txtAreaDescription);
		
		/*********************************************************Create Combo Boxes*********************************************************/
		JComboBox cmbGroupName = new JComboBox(UI_Settings.getGroups());
		JComboBox cmbPreferredEmp_1 = new JComboBox(UI_Settings.getEmployeeNames());
		JComboBox cmbPreferredEmp_2 = new JComboBox(UI_Settings.getEmployeeNames());
		JComboBox cmbPreferredEmp_3 = new JComboBox(UI_Settings.getEmployeeNames());


		
		cmbGroupName.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbGroupName.setFont(UI_Settings.getComponentInputFontSize());
		cmbGroupName.setMinimumSize(cmbGroupName.getPreferredSize());
		//AutoCompletion.enable(cmbGroupName, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbGroupName);
		
		cmbPreferredEmp_1.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbPreferredEmp_1.setFont(UI_Settings.getComponentInputFontSize());
		cmbPreferredEmp_1.setMinimumSize(cmbPreferredEmp_1.getPreferredSize());
		//AutoCompletion.enable(cmbPreferredEmp_1, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbPreferredEmp_1);
		
		cmbPreferredEmp_2.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbPreferredEmp_2.setFont(UI_Settings.getComponentInputFontSize());
		cmbPreferredEmp_2.setMinimumSize(cmbPreferredEmp_2.getPreferredSize());
		//AutoCompletion.enable(cmbPreferredEmp_2, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbPreferredEmp_2);
		
		cmbPreferredEmp_3.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbPreferredEmp_3.setFont(UI_Settings.getComponentInputFontSize());
		cmbPreferredEmp_3.setMinimumSize(cmbPreferredEmp_3.getPreferredSize());
		//AutoCompletion.enable(cmbPreferredEmp_2, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbPreferredEmp_3);
		
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/**********************Create the components panel***********************/
		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 120));
		detailsPanel.setLayout(new GridBagLayout());
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
		       int action = JOptionPane.showConfirmDialog(EventsPane.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		       
		       if(action == JOptionPane.OK_OPTION){
		    	   
		    	   cmbGroupName.setSelectedIndex(0);
				   failedMessage.setVisible(false);
				   failedMessage1.setVisible(false);
				   
				   txtAreaDescription.setText("");
				   
				   txtEventName.setText("");
				   txtStartDate.setText("");
				   txtEndDate.setText("");
				   passwordField.setText("");
				   
				   cmbPreferredEmp_1.setSelectedIndex(0);
				   cmbPreferredEmp_2.setSelectedIndex(0);
				   cmbPreferredEmp_3.setSelectedIndex(0);
				   
				   
		       }
			}
		});
		GridBagConstraints gc = new GridBagConstraints();
		
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/**********************Create the components panel***********************/
		detailsPanel = new JPanel();
		detailsPanel.setBackground(UI_Settings.getButtonPanelColor());
		detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.X_AXIS));
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-30));
		/******************************************************Add the Header Panel************************************************/
		
		JPanel dpLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 30));
		dpLeft.setBackground(Color.WHITE);
		dpLeft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		dpLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		dpLeft.add(new JLabel("Group Name:"));
		dpLeft.add(cmbGroupName);

		
		JPanel dpRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 2));
		dpRight.setBackground(Color.WHITE);
		dpRight.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		dpRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		//dpRight.add(new JLabel("Good Times"));
		
		dpLeft.setAlignmentX(Component.LEFT_ALIGNMENT);
		detailsPanel.add(dpLeft);
		
		dpRight.setAlignmentX(Component.RIGHT_ALIGNMENT);
		detailsPanel.add(dpRight);
		
		/******************************************************Add the Reset Panel************************************************/
		int offset = 10;
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-offset));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-offset));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-offset));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(labels[0]);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		/******************************************************Add Boxes Row Panel************************************************/

		Border border = BorderFactory.createLineBorder(Color.LIGHT_GRAY);

		
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-offset));
		container.setBackground(Color.WHITE);
		
			JPanel containerLeft = new JPanel(new GridBagLayout());
			setPanelSize(containerLeft, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getSmallPanelHeight()-offset));
			containerLeft.setBackground(new Color(246,246,246));
			containerLeft.setBorder(border);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,0);
				containerLeft.add(new JLabel("Event Name:"), gc);
				
				gc.gridx = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.insets = new Insets(0,0,0,25);
				containerLeft.add(txtEventName, gc);
				
			
			JPanel containerMiddle = new JPanel(new GridBagLayout());
			setPanelSize(containerMiddle, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getSmallPanelHeight()-offset));
			containerMiddle.setBackground(Color.WHITE);
			containerMiddle.setBorder(border);
			
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,0);
				containerMiddle.add(new JLabel("Scheduled From:"), gc);
				
				gc.gridx = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.insets = new Insets(0,0,0,25);
				containerMiddle.add(txtStartDate, gc);
			
			

			JPanel containerRight = new JPanel(new GridBagLayout());
			setPanelSize(containerRight, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getSmallPanelHeight()-offset));
			containerRight.setBackground(new Color(246,246,246));
			containerRight.setBorder(border);
			
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,0);
				containerRight.add(new JLabel("Scheduled To:"), gc);
				
				gc.gridx = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.insets = new Insets(0,0,0,25);
				containerRight.add(txtEndDate, gc);

		
			gc.gridx = 0;
			gc.gridy = 0;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(5,5,5,5);
			container.add(containerLeft, gc);
			
			gc.gridx = 1;
			container.add(containerMiddle, gc);
			
			gc.gridx = 2;
			gc.insets = new Insets(5,5,5,10);
			container.add(containerRight, gc);
			
		/******************************************************Add Center Boxes Panel************************************************/
/*		JPanel heading = new JPanel(new FlowLayout(FlowLayout.LEFT, 10,10));
		setPanelSize(heading, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		heading.setBackground(Color.RED);
		
		
		*/
		JPanel heading = new JPanel();
		heading.setBackground(new Color(246,246,246));
		heading.setLayout(new BoxLayout(heading, BoxLayout.X_AXIS));
		
		heading.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-10));
		heading.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-10));
		heading.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-10));

		
		JPanel headLft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
		headLft.setBackground(new Color(246,246,246));
		headLft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		headLft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		headLft.add(failedMessage);
		headLft.add(new JLabel("Event Description:"));

		
		JPanel headRght = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
		headRght.setBackground(new Color(246,246,246));
		headRght.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		headRght.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		headRght.add(labels[3]);
		//headRght.add(btnSort);

		
		headLft.setAlignmentX(Component.LEFT_ALIGNMENT);
		heading.add(headLft);
		
		headRght.setAlignmentX(Component.RIGHT_ALIGNMENT);
		heading.add(headRght);
		///////////////////////////////////////////////Add The Main Components To This Area//////////////////////////////////////////
				
		int paneloffset = 20;
		
		JPanel commentsPanel = new JPanel(new GridBagLayout());
		setPanelSize(commentsPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-paneloffset));
		commentsPanel.setBackground(Color.WHITE);
		
		//Add the comments box//
		JPanel comments = new JPanel(new GridBagLayout());
		setPanelSize(comments, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-paneloffset));
		comments.setBackground(Color.WHITE);
		//comments.setBorder(border);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.BOTH;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		comments.add(txtAreaDescription, gc);
		
		JPanel reportDetails = new JPanel(new GridBagLayout());
		setPanelSize(reportDetails, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-paneloffset));
		reportDetails.setBackground(new Color(246,246,246));
		reportDetails.setBorder(border);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.fill = GridBagConstraints.NONE;
		gc.insets = new Insets(15,20,0,0);
		reportDetails.add(new JLabel("Preferred Instructor 1:"), gc);
		
		gc.gridx = 0;
		gc.gridy = 1;
		reportDetails.add(new JLabel("Preferred Instructor 2:"), gc);
		
		gc.gridx = 0;
		gc.gridy = 2;
		reportDetails.add(new JLabel("Preferred Instructor 3:"), gc);
		
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(10,0,0,20);
		reportDetails.add(cmbPreferredEmp_1, gc);
		
		gc.gridx = 1;
		gc.gridy = 1;
		reportDetails.add(cmbPreferredEmp_2, gc);
		
		gc.gridx = 1;
		gc.gridy = 2;
		reportDetails.add(cmbPreferredEmp_3, gc);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(5,5,5,0);
		commentsPanel.add(comments, gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.3;
		gc.weighty = 0.3;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(5,5,5,10);
		commentsPanel.add(reportDetails, gc);
		/*************************************************Print Report Button Panel**************************************************/
		JPanel bottomButtons = new JPanel(new GridBagLayout());
		setPanelSize(bottomButtons, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-paneloffset));
		bottomButtons.setBackground(Color.WHITE);
		
		//Add the comments box//
		JPanel reportsFolder = new JPanel(new GridBagLayout());
		setPanelSize(reportsFolder, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-paneloffset));
		reportsFolder.setBackground(Color.WHITE);
		
		
		JPanel lowerButtons = new JPanel();
		lowerButtons.setBackground(UI_Settings.getButtonPanelColor());
		lowerButtons.setLayout(new BoxLayout(lowerButtons, BoxLayout.X_AXIS));
		setPanelSize(lowerButtons, new Dimension(UI_Settings.getMinimumScreenSize().width/3*2, UI_Settings.getDetailsButtonPanelHeight()));
		
		JPanel lowerleft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
		lowerleft.setBackground(Color.WHITE);
		//lowerleft.add(labels[9]);
		
		JPanel lowerright = new JPanel(new FlowLayout(FlowLayout.RIGHT, 25, 0));
		lowerright.setBackground(UI_Settings.getComponentpanefillcolor());
		//lowerright.add(labels[10]);
		//lowerright.add(labels[8]);
		
		lowerleft.setAlignmentX(Component.LEFT_ALIGNMENT);
		lowerButtons.add(lowerleft);
		
		lowerright.setAlignmentX(Component.RIGHT_ALIGNMENT);
		lowerButtons.add(lowerright);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		reportsFolder.add(lowerButtons, gc);
		
		
		JPanel pnlPassword = new JPanel(new GridBagLayout());
		pnlPassword.setBackground(new Color(246,246,246));
		pnlPassword.setBorder(border);
		
		setPanelSize(pnlPassword, new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)+10, UI_Settings.getRegularPanelHeight()-50));
		
		int password;
		btnSaveEvent.addMouseListener(new MouseAdapter(){
			public void mouseReleased(MouseEvent e){
				
/*					if(txtAreaEmail.getText().equals("")){
					System.err.println("Nothing there");
					return;
				}*/
				
				SentryModule module = new SentryModule();
				
		           char[] input = passwordField.getPassword();
		            if (module.takeInput(input)) {
		                JOptionPane.showMessageDialog(controllingFrame,
		                    "Welcome administrator. The office time request has been sent.");
		            } else {
		                JOptionPane.showMessageDialog(controllingFrame,
		                    "To send an office time request please enter the correct password.",
		                    "Error Message",
		                    JOptionPane.ERROR_MESSAGE);
		            }

		            //Zero out the possible password, for security.
		            Arrays.fill(input, '0');

		            passwordField.selectAll();
				
			}
		});
		
		labels[4].setCursor(UI_Settings.getJlabelCursor());
		labels[4].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
				JOptionPane.showMessageDialog(controllingFrame,
		                "The administrator password can be found with the \"Kids Coordinator\"\n"
		              + "or by contacting your \"Branch Manager\".");
				
			}
		});
		JPanel adminPanel = new JPanel(new GridBagLayout());
		adminPanel.setBackground(Color.WHITE);

		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,10,0,0);
		
		adminPanel.add(new JLabel("Administrator password:"), gc);
		
		gc.gridx = 1;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,5,0,0);
		
		adminPanel.add(passwordField, gc);
		
		gc.gridx = 2;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.2;
		gc.weighty = 0.2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,5,0,5);
		adminPanel.add(labels[4], gc);
		
		
		gc.gridx = 0;
		gc.gridy = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTH;
		gc.insets = new Insets(15,0,0,0);
		
		pnlPassword.add(adminPanel, gc);
		

		gc.gridx = 0;
		gc.gridy = 2;
		gc.insets = new Insets(-5,5,10,0);
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.NORTHWEST;
		pnlPassword.add(btnSaveEvent, gc);//Send request button
		
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.insets = new Insets(5,5,5,0);
		bottomButtons.add(reportsFolder, gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.2;
		gc.weighty = 0.2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(5,5,5,10);
		bottomButtons.add(pnlPassword, gc);
				
		/******************************************************Create the Table Data Panel*******************************************/
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        detailsPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(detailsPanel);
        
        buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(buttonPanel);
        
        container.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(container);
        
        heading.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(heading);
        
        commentsPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(commentsPanel);
        
        bottomButtons.setAlignmentY(Component.RIGHT_ALIGNMENT);
        centerPanel.add(bottomButtons);
        
        openHouseAddedTable.setAlignmentY(Component.RIGHT_ALIGNMENT);
        centerPanel.add(openHouseAddedTable);
        
        
        
		/*********************************************************************************************************************************/
    	/////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 700));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 700));

		//Add the details section and table sections to the canvas.
		canvas.add(detailsPanel, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
	
		
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(canvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());

		return scroller;
	}//END addEvents
	
	public class DateLabelFormatter extends AbstractFormatter {

	    /**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private String datePattern = "yyyy-MM-dd";
	    private SimpleDateFormat dateFormatter = new SimpleDateFormat(datePattern);

	    @Override
	    public Object stringToValue(String text) throws ParseException {
	        return dateFormatter.parseObject(text);
	    }

	    @Override
	    public String valueToString(Object value) throws ParseException {
	        if (value != null) {
	            Calendar cal = (Calendar) value;
	            return dateFormatter.format(cal.getTime());
	        }

	        return "";
	    }

	}
}