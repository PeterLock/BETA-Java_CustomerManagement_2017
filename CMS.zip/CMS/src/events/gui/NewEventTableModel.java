package events.gui;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import events.model.NewEvent;

public class NewEventTableModel extends AbstractTableModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<NewEvent>db;
	
	
	private String[] colNames = {"Event Name", "Start Date", "Finish Date", "Group Name", "Preference 1", "Preference 2", "Preference 3"};

	@Override
	public int getRowCount() {
		return db.size();
	}

	@Override
	public int getColumnCount() {
		return 7;
	}
	
	@Override
	public String getColumnName(int column) {
		return colNames[column];
	}

	@Override
	public Object getValueAt(int row, int col) {
		
		NewEvent newEvent = db.get(row);
		
		switch(col){
		case 0: 
			return newEvent.getEventname();
		case 1:
			return newEvent.getStart();
		case 2:
			return newEvent.getFinish();
		case 3:
			return newEvent.getGroupname();
		case 4:
			return newEvent.getPref1();
		case 5:
			return newEvent.getPref2();
		case 6:
			return newEvent.getPref3();
		default:
			return null;
		}
	}

	public void setData(List<NewEvent> db) {
		this.db = db;
	}
}
