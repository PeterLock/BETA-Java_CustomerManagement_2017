package events.gui;

import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.table.AbstractTableModel;

public class TD_EAdded extends AbstractTableModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public final static int GROUP_NAME = 0;
	public final static int EVENT_NAME = 1;
	public final static int SCHEDULED_FROM = 2;
	public final static int SCHEDULED_TO = 3;
	public final static int PREFERRED_INSTRUCTOR_1 = 4;
	public final static int PREFERRED_INSTRUCTOR_2 = 5;
	public final static int PREFERRED_INSTRUCTOR_3 = 6;
	
	
	public Object[][]values =
		{
			{"Duffy", "Halloween", "October 14th", "October 31st","Renee Jones", "Andrew Smith", "Paul Ude" },
			{"", "", "", "", "", "", ""},
			{"", "", "", "", "", "", ""},
			{"", "", "", "", "", "", ""}

		};
	
	public final static String[] COLUMN_NAMES = {"Group Name", "Event Name",
			"Scheduled From", "Scheduled To", "Preferred Instructor 1", "Preferred Instructor 2", "Preferred Instructor 3"};


	
	public String getColumnName(int column){
		return COLUMN_NAMES[column];
	}
	
	@Override
	public int getRowCount() {
		return values.length;
	}
	
	
	@Override
	public int getColumnCount() {
		return values[0].length;
	}
	
	
	@Override
	public Object getValueAt(int row, int column) {
		return values[row][column];
	}
	


	public ArrayList<Integer> getCOLUMN_PERCENTAGES() {
		return COLUMN_PERCENTAGES;
	}

	public static void setCOLUMN_PERCENTAGES(ArrayList<Integer> cOLUMN_PERCENTAGES) {
		COLUMN_PERCENTAGES = cOLUMN_PERCENTAGES;
	}



	private static ArrayList<Integer> COLUMN_PERCENTAGES = new ArrayList<>(Arrays.asList(14,14,14,14,14,14,14));

}

