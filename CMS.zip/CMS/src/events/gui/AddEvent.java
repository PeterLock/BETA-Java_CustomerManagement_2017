package events.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;

import group.controller.Controller;
import group.model.Group;
import settings.UI_Settings;
import utilities.JTextFieldLimit;
import utilities.SentryModule;
import utilities.TextPrompt;

public class AddEvent extends JPanel {
	
	private JFrame controllingFrame; 
	private JPanel headerMessagePanel;
	private JPanel detailsPanel;
	private JPanel pnlCenterTopPanel;
	private JPanel pnlTopGroupDetails;
	private JPanel pnlInformation;
	
	private Calendar c = Calendar.getInstance();
	private JLabel lblDate = new JLabel(c.getTime().toString());
	private Controller controller;
    private int tableWindowHeight = 0;
    private int tableRowNumber = 0;
    private int topFrameHeight = 210;
    private int centerTopHeight = 50;
    private int bottomFrameHeight = 200;
    
	private  JTextArea txtStudentListDisplayArea;
	private JButton btnSaveEvent;

	private JTextField txtTopPanelStudentName;
	private JTextField txtTopPanelAge;
	private JTextField txtGroupName;
	private JTextField txtGroupID;
	private JTextField txtGroupPos;
	private JTextField txtGroupDay;
	private JTextField txtGroupTime;
	private JTextField txtGroupMaterial;
	private JTextField txtGroupMin;
	private JTextField txtGroupCurrentClassSize;
	private JTextField txtGroupLev;
	private JTextField txtAddGroupName;
	private JTextField txtAddGroupID;
	private JTextField txtAddGroupLev;
	private JTextField txtAddGroupDay;
	private JTextField txtAddGroupTime;
	private JTextField txtAddGroupMax;
	private JTextField txtAddGroupPos;
	private JTextField txtAddGroupMat;
	private JTextField txtAddCurrentClassSize;
	private List <JTextField> textfieldsViewGroupDetails = new ArrayList<JTextField>();
	private List <JTextField> textfieldsAddGroupDetails = new ArrayList<JTextField>();
	
	private JLabel labels[];

	
	private List<Group> group_list = new ArrayList<Group>();

	
	@SuppressWarnings("unused")
	private TextPrompt textPrompt;
	
	private  JPasswordField passwordField;
	private GridBagConstraints gc = new GridBagConstraints();
	
	JComboBox<String> cmbGroupName = new JComboBox<String>(UI_Settings.getGroups());
	JComboBox<String> cmbPreferredEmp_1 = new JComboBox<String>(UI_Settings.getEmployeeNames());
	JComboBox<String> cmbPreferredEmp_2 = new JComboBox<String>(UI_Settings.getEmployeeNames());
	JComboBox<String> cmbPreferredEmp_3 = new JComboBox<String>(UI_Settings.getEmployeeNames());

    private JTextField txtEndDate;
    private JTextField txtStartDate;
    private JTextField txtEventName;
	
	
	public AddEvent(){
	}
	
	public Component run(){
		JScrollPane scroller = initialize();
		return scroller;
	}

	private JScrollPane initialize() {
		JPanel canvas;
		JPanel detailsPanel;
		JPanel centerPanel;
		
		
		JTextArea txtAreaDescription;
		
		labels = new JLabel[7];
		labels[0] = new JLabel("reset fields");
		labels[1] = new JLabel("undo move");
		labels[2] = new JLabel("help");
		labels[3] = new JLabel("...");
		labels[4] = new JLabel("clear table");
		labels[5] = new JLabel("view interests");
		labels[6] = new JLabel("view comments");
		
		txtStudentListDisplayArea = new JTextArea(7, 20);
		txtStudentListDisplayArea.setEditable(true);
		txtStudentListDisplayArea.setBorder(UI_Settings.getBorderoutline());
		txtStudentListDisplayArea.setWrapStyleWord(true);
		txtStudentListDisplayArea.setLineWrap(true);
		txtStudentListDisplayArea.setDocument(new JTextFieldLimit(150));
		txtStudentListDisplayArea.setPreferredSize(txtStudentListDisplayArea.getPreferredSize());

		btnSaveEvent = new JButton("Save Event");
		btnSaveEvent.setPreferredSize(new Dimension(150,UI_Settings.getJbuttonSize().height));
		btnSaveEvent.setMinimumSize(new Dimension(150,UI_Settings.getJbuttonSize().height));

		btnSaveEvent.setFont(UI_Settings.getComponentInputFontSize());
		
		/***********************Initialize Fields******************************/
		JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());

		failedMessage.setVisible(false);
		
		JLabel failedMessage1 = new JLabel(UI_Settings.getFailedMessage());
		failedMessage1.setForeground(UI_Settings.getFailedMessageColor());

		failedMessage1.setVisible(false);
		
		JLabel labels[] = new JLabel[5];
		
		labels[0] = new JLabel("reset fields");
		labels[1] = new JLabel("delete");
		labels[2] = new JLabel("edit");
		labels[3] = new JLabel("auto-fill preferred instructors");
		labels[4] = new JLabel("hint");


		for( int i = 0; i < 5; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		
        passwordField = new JPasswordField(10);
        passwordField.setActionCommand(UI_Settings.getOk());
		
		
        List<JTextField> textfields = new ArrayList<JTextField>();
        @SuppressWarnings("rawtypes")
		List<JComboBox> comboboxes = new ArrayList<JComboBox>();

        
		txtEndDate = new JTextField(12);
        txtEndDate.setEditable(true);
        txtEndDate.setMinimumSize(txtEndDate.getPreferredSize());
        txtEndDate.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtEndDate);
        
		txtStartDate = new JTextField(12);
		txtStartDate.setEditable(true);
		txtStartDate.setMinimumSize(txtEndDate.getPreferredSize());
		txtStartDate.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtStartDate);
        
		txtEventName = new JTextField(12);
		txtEventName.setEditable(true);
		txtEventName.setMinimumSize(txtEndDate.getPreferredSize());
		txtEventName.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtEventName);
        
		/***************************************************Create textAreas********************************************************************/
		txtAreaDescription = new JTextArea(6, 30);
		txtAreaDescription.setEditable(true);
		txtAreaDescription.setMinimumSize(new Dimension((int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth()/2, (int)txtAreaDescription.getPreferredSize().getHeight()));
		txtAreaDescription.setBorder(UI_Settings.getBorderoutline());
		txtAreaDescription.setWrapStyleWord(true);
		txtAreaDescription.setLineWrap(true);
		txtAreaDescription.setDocument(new JTextFieldLimit(250));
		textPrompt = new TextPrompt("<enter a description of the event>", txtAreaDescription);
		
		/*********************************************************Create Combo Boxes*********************************************************/
		cmbGroupName.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbGroupName.setFont(UI_Settings.getComponentInputFontSize());
		cmbGroupName.setMinimumSize(cmbGroupName.getPreferredSize());
		//AutoCompletion.enable(cmbGroupName, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbGroupName);
		
		cmbPreferredEmp_1.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbPreferredEmp_1.setFont(UI_Settings.getComponentInputFontSize());
		cmbPreferredEmp_1.setMinimumSize(cmbPreferredEmp_1.getPreferredSize());
		//AutoCompletion.enable(cmbPreferredEmp_1, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbPreferredEmp_1);
		
		cmbPreferredEmp_2.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbPreferredEmp_2.setFont(UI_Settings.getComponentInputFontSize());
		cmbPreferredEmp_2.setMinimumSize(cmbPreferredEmp_2.getPreferredSize());
		//AutoCompletion.enable(cmbPreferredEmp_2, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbPreferredEmp_2);
		
		cmbPreferredEmp_3.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbPreferredEmp_3.setFont(UI_Settings.getComponentInputFontSize());
		cmbPreferredEmp_3.setMinimumSize(cmbPreferredEmp_3.getPreferredSize());
		//AutoCompletion.enable(cmbPreferredEmp_2, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbPreferredEmp_3);
		
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/**********************Create the components panel***********************/
		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 120));
		detailsPanel.setLayout(new GridBagLayout());
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
		       int action = JOptionPane.showConfirmDialog(AddEvent.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		       
		       if(action == JOptionPane.OK_OPTION){
		    	   
		    	   cmbGroupName.setSelectedIndex(0);
				   failedMessage.setVisible(false);
				   failedMessage1.setVisible(false);
				   
				   txtAreaDescription.setText("");
				   
				   txtEventName.setText("");
				   txtStartDate.setText("");
				   txtEndDate.setText("");
				   passwordField.setText("");
				   
				   cmbPreferredEmp_1.setSelectedIndex(0);
				   cmbPreferredEmp_2.setSelectedIndex(0);
				   cmbPreferredEmp_3.setSelectedIndex(0);
				   
				   
		       }
			}
		});
		/**********************Create the Group Details Panel********************/

		addGroupDetailsPanel();
		
		/************************************************************************/
		
		addSouthPanel();

		/************************************************************************/
		GridBagConstraints gc = new GridBagConstraints();
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/**********************Create the components panel***********************/
		detailsPanel = new JPanel();
		detailsPanel.setBackground(UI_Settings.getButtonPanelColor());
		detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.X_AXIS));
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-30));
		/******************************************************Add the north panel************************************************/

		addNorthPanel();
		
		/******************************************************Add the Reset Panel************************************************/

		Border border = BorderFactory.createLineBorder(Color.LIGHT_GRAY);
		int offset = 10;

			
		JPanel heading = new JPanel();
		heading.setBackground(new Color(246,246,246));
		heading.setLayout(new BoxLayout(heading, BoxLayout.X_AXIS));
		
		heading.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-10));
		heading.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-10));
		heading.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-10));

		
		JPanel headLft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
		headLft.setBackground(Color.WHITE);
		headLft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		headLft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		headLft.add(failedMessage);
		headLft.add(new JLabel("Event Description:"));

		
		JPanel headRght = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
		headRght.setBackground(Color.WHITE);
		headRght.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		headRght.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		headRght.add(labels[3]);
		//headRght.add(btnSort);

		
		headLft.setAlignmentX(Component.LEFT_ALIGNMENT);
		heading.add(headLft);
		
		headRght.setAlignmentX(Component.RIGHT_ALIGNMENT);
		heading.add(headRght);
		///////////////////////////////////////////////Add The Main Components To This Area//////////////////////////////////////////
				
		int paneloffset = 20;
		
		JPanel commentsPanel = new JPanel(new GridBagLayout());
		setPanelSize(commentsPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-paneloffset));
		commentsPanel.setBackground(Color.WHITE);
		
		//Add the comments box//
		JPanel comments = new JPanel(new GridBagLayout());
		setPanelSize(comments, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-paneloffset));
		comments.setBackground(Color.WHITE);
		//comments.setBorder(border);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.BOTH;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		comments.add(txtAreaDescription, gc);
		
		JPanel reportDetails = new JPanel(new GridBagLayout());
		setPanelSize(reportDetails, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-paneloffset));
		reportDetails.setBackground(new Color(246,246,246));
		reportDetails.setBorder(border);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.fill = GridBagConstraints.NONE;
		gc.insets = new Insets(15,20,0,0);
		reportDetails.add(new JLabel("Preferred Instructor 1:"), gc);
		
		gc.gridx = 0;
		gc.gridy = 1;
		reportDetails.add(new JLabel("Preferred Instructor 2:"), gc);
		
		gc.gridx = 0;
		gc.gridy = 2;
		reportDetails.add(new JLabel("Preferred Instructor 3:"), gc);
		
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(10,0,0,20);
		reportDetails.add(cmbPreferredEmp_1, gc);
		
		gc.gridx = 1;
		gc.gridy = 1;
		reportDetails.add(cmbPreferredEmp_2, gc);
		
		gc.gridx = 1;
		gc.gridy = 2;
		reportDetails.add(cmbPreferredEmp_3, gc);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(5,5,5,0);
		commentsPanel.add(comments, gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.3;
		gc.weighty = 0.3;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(5,5,5,10);
		commentsPanel.add(reportDetails, gc);
				
		/******************************************************Create the Table Data Panel*******************************************/
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        detailsPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(detailsPanel);
        
	    pnlCenterTopPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(pnlCenterTopPanel);
        
        
        heading.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(heading);
        
        commentsPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(commentsPanel);
        
        pnlInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlInformation);
        
        
		/*********************************************************************************************************************************/
    	/////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 700));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 700));

		//Add the details section and table sections to the canvas.
		canvas.add(headerMessagePanel, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
	
		
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(canvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());

		return scroller;
	}
	
	private void addGroupDetailsPanel(){
		
		for(int i = 0; i < 7; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());	
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		
		txtStudentListDisplayArea = new JTextArea(7, 20);
		txtStudentListDisplayArea.setEditable(true);
		txtStudentListDisplayArea.setBorder(UI_Settings.getBorderoutline());
		txtStudentListDisplayArea.setWrapStyleWord(true);
		txtStudentListDisplayArea.setLineWrap(true);
		txtStudentListDisplayArea.setDocument(new JTextFieldLimit(150));
		txtStudentListDisplayArea.setPreferredSize(txtStudentListDisplayArea.getPreferredSize());
		
		/*********************************************Add the Bottom Panel TextFields***********************/

		int view_textfield_size = 13;
		int add_textfield_size = 28;
		
		//Add the contents of the bottom panel, the group details
		pnlTopGroupDetails = new JPanel(new GridBagLayout());
		setPanelSize(pnlTopGroupDetails, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, topFrameHeight-centerTopHeight));
		
		//////////////Initialize View Group Fields///////////////
		txtGroupName = initializeTextFields(txtGroupName, view_textfield_size);
		txtGroupID = initializeTextFields(txtGroupID, view_textfield_size);
		txtGroupPos = initializeTextFields(txtGroupPos, view_textfield_size);
		txtGroupLev = initializeTextFields(txtGroupLev, view_textfield_size);
		txtGroupDay = initializeTextFields(txtGroupDay, view_textfield_size);
		txtGroupTime = initializeTextFields(txtGroupTime, view_textfield_size);
		txtGroupCurrentClassSize = initializeTextFields(txtGroupCurrentClassSize, view_textfield_size);
		txtGroupMaterial = initializeTextFields(txtGroupMaterial, view_textfield_size);
		txtGroupMin = initializeTextFields(txtGroupMin, view_textfield_size);

		
		txtAddGroupName = initializeTextFields(txtAddGroupName, add_textfield_size);
		txtAddGroupID = initializeTextFields(txtAddGroupID, add_textfield_size);
		txtAddGroupPos = initializeTextFields(txtAddGroupPos, add_textfield_size);
		txtAddGroupLev = initializeTextFields(txtAddGroupLev, add_textfield_size);
		txtAddGroupDay = initializeTextFields(txtAddGroupDay, add_textfield_size);
		txtAddGroupTime = initializeTextFields(txtAddGroupTime, add_textfield_size);
		txtAddGroupMax = initializeTextFields(txtAddGroupMax, add_textfield_size);
		txtAddGroupMat = initializeTextFields(txtAddGroupMat, add_textfield_size);
		txtAddCurrentClassSize = initializeTextFields(txtAddCurrentClassSize, add_textfield_size);

		
		textfieldsViewGroupDetails.add(txtGroupName); 
		textfieldsViewGroupDetails.add(txtGroupID); 		
		textfieldsViewGroupDetails.add(txtGroupPos); 		
		textfieldsViewGroupDetails.add(txtGroupLev); 		
		textfieldsViewGroupDetails.add(txtGroupDay); 		
		textfieldsViewGroupDetails.add(txtGroupTime); 		
		textfieldsViewGroupDetails.add(txtGroupCurrentClassSize); 		
		textfieldsViewGroupDetails.add(txtGroupMaterial);
		textfieldsViewGroupDetails.add(txtGroupMin);

		
		
		textfieldsAddGroupDetails.add(txtAddGroupName); 
		textfieldsAddGroupDetails.add(txtAddGroupID); 		
		textfieldsAddGroupDetails.add(txtAddGroupPos); 		
		textfieldsAddGroupDetails.add(txtAddGroupLev); 		
		textfieldsAddGroupDetails.add(txtAddGroupDay); 		
		textfieldsAddGroupDetails.add(txtAddGroupTime); 		
		textfieldsAddGroupDetails.add(txtAddGroupMax); 		
		textfieldsAddGroupDetails.add(txtAddGroupMat); 
		textfieldsAddGroupDetails.add(txtAddCurrentClassSize); 
		
		
		txtTopPanelStudentName = new JTextField(10);
		txtTopPanelStudentName.setEditable(true);
		txtTopPanelStudentName.setMinimumSize(txtTopPanelStudentName.getPreferredSize());
		new TextPrompt("-", txtTopPanelStudentName);
		txtTopPanelStudentName.setHorizontalAlignment(JTextField.CENTER);
		textfieldsViewGroupDetails.add(txtTopPanelStudentName);
		
		txtTopPanelAge = new JTextField(5);
		txtTopPanelAge.setEditable(true);
		txtTopPanelAge.setMinimumSize(txtTopPanelAge.getPreferredSize());
		new TextPrompt("-", txtTopPanelAge);
		txtTopPanelAge.setHorizontalAlignment(JTextField.CENTER);
		textfieldsViewGroupDetails.add(txtTopPanelAge);
		
		pnlCenterTopPanel = new JPanel(new GridBagLayout());
		setPanelSize(pnlCenterTopPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, topFrameHeight));
		
		JPanel pnlCenterTopLeft = new JPanel(new GridBagLayout());
		setPanelSize(pnlCenterTopLeft, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, topFrameHeight));
		
		Border darkBorder = BorderFactory.createLineBorder(Color.LIGHT_GRAY);

			//add components to the left panel
			pnlCenterTopLeft.setBorder(darkBorder);
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(10,10,0,0);
			pnlCenterTopLeft.add(new JLabel("Click on the customers name to select:"), gc);
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.BOTH;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,10,10,10);
			pnlCenterTopLeft.add(txtStudentListDisplayArea, gc);
			
		JPanel pnlCenterTopRight = new JPanel(new GridBagLayout());
		setPanelSize(pnlCenterTopRight, new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2), topFrameHeight));
		pnlCenterTopRight.setBackground(Color.WHITE);

			JPanel pnlCenterTopRightTop = new JPanel(new GridBagLayout());
			setPanelSize(pnlCenterTopRightTop, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, centerTopHeight));
			pnlCenterTopRightTop.setBackground(Color.WHITE);

				//Add the contents of this panel - the student name and the student age plus buttons
				//Add the student name panel//
				JPanel pnlStudentName = new JPanel(new GridBagLayout());
				setPanelSize(pnlStudentName, new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3,centerTopHeight));
				pnlStudentName.setBorder(darkBorder);
				pnlStudentName.setBackground(Color.WHITE);
					//Add student name fields//
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.weightx = 0.2;
					gc.weighty = 0.2;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(0,10,0,0);
					pnlStudentName.add(new JLabel("Student Name:"),gc);
					gc.gridx = 1;
					gc.gridy = 0;
					pnlStudentName.add(txtTopPanelStudentName,gc);
				gc.gridx = 0;
				gc.gridy = 0;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,0,0,0);
				pnlCenterTopRightTop.add(pnlStudentName,gc);
				
				JPanel pnlStudentButtons = new JPanel(new GridBagLayout());
				setPanelSize(pnlStudentButtons, new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2)/3*2,centerTopHeight));
				pnlStudentButtons.setBorder(darkBorder);
				pnlStudentButtons.setBackground(Color.WHITE);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,1);
				pnlStudentButtons.add(new JLabel("Age:"), gc);
				
				gc.gridx = 1;
				gc.gridy = 0;
				gc.insets = new Insets(0,-20,0,0);
				pnlStudentButtons.add(txtTopPanelAge, gc);
				
				
				gc.gridx = 2;
				gc.gridy = 0;
				gc.insets = new Insets(0,5,0,0);
				pnlStudentButtons.add(labels[5], gc);
				
				gc.gridx = 3;
				gc.gridy = 0;
				gc.insets = new Insets(0,5,0,0);
				pnlStudentButtons.add(labels[6], gc);
				
				gc.gridx = 1;
				gc.gridy = 0;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,0,1);
				pnlCenterTopRightTop.add(pnlStudentButtons, gc);

		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.weightx = 0.2;
		gc.weighty = 0.2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		pnlCenterTopRight.add(pnlCenterTopRightTop, gc);

				pnlTopGroupDetails.setBackground(Color.WHITE);
				pnlTopGroupDetails.setBorder(darkBorder);
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridwidth = 1;
				gc.gridheight = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(20,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Name:"),gc);
				gc.gridx = 0;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group ID:"),gc);
				gc.gridx = 0;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Positions Available:"),gc);
				gc.gridx = 0;
				gc.gridy = 3;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Level:"),gc);
				gc.gridx = 1;
				gc.gridy = 0;
				gc.insets = new Insets(15,10,0,0);
				pnlTopGroupDetails.add(txtGroupName,gc);
				gc.gridx = 1;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtGroupID,gc);
				gc.gridx = 1;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtGroupPos,gc);
				gc.gridx = 1;
				gc.gridy = 3;
				gc.gridheight = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtGroupLev,gc);
				gc.gridx = 2;
				gc.gridy = 0;
				gc.insets = new Insets(20,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Day:"),gc);
				gc.gridx = 2;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Group Time:"),gc);
				gc.gridx = 2;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Current Group Size:"),gc);
				gc.gridx = 2;
				gc.gridy = 3;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(new JLabel("Material:"),gc);
				gc.gridx = 3;
				gc.gridy = 0;
				gc.insets = new Insets(15,10,0,0);
				pnlTopGroupDetails.add(txtGroupDay,gc);
				gc.gridx = 3;
				gc.gridy = 1;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtGroupTime,gc);
				gc.gridx = 3;
				gc.gridy = 2;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtGroupCurrentClassSize,gc);
				gc.gridx = 3;
				gc.gridy = 3;
				gc.insets = new Insets(0,10,0,0);
				pnlTopGroupDetails.add(txtGroupMaterial,gc);
				
		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 0.2;
		gc.weighty = 0.2;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(5,0,1,0);
		pnlCenterTopRight.add(pnlTopGroupDetails, gc);
		pnlCenterTopLeft.setBackground(new Color(246,246,246));
		
		//This is the main container panel for the North most components on the central stage - namely pnlCenterTopLeftPanel and pnlCenterTopRight//
		pnlCenterTopPanel.setBackground(Color.WHITE);
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.weightx = 0.2;
			gc.weighty = 0.2;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,5,0,5);
			pnlCenterTopPanel.add(pnlCenterTopLeft, gc);
			
			gc.gridx = 1;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,5,0,10);
			pnlCenterTopPanel.add(pnlCenterTopRight, gc);
	}
	
	private void addNorthPanel() {
		JPanel heading = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		JLabel lblHeading = new JLabel("Adding scheduled event to groups");
		heading.setBackground(Color.WHITE);
		lblHeading.setFont(lblHeading.getFont().deriveFont(16.0f));
		heading.add(lblHeading);
		
		JPanel headingMessage = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		headingMessage.setBackground(Color.WHITE);
		JLabel lblHeadingMessage = new JLabel("Adding scheduled event details is simple. Choose the event name from the dropdown box below.\n"
				+ "Add all necessary information and you are done and choose which tile you want to assign to the event.");
		
		headingMessage.add(lblHeadingMessage);

		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-30));
		detailsPanel.setLayout(new GridBagLayout());
		
		headerMessagePanel = new JPanel(new GridBagLayout());
		setPanelSize(headerMessagePanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 100));
		headerMessagePanel.setBackground(Color.WHITE);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		headerMessagePanel.add(heading,gc);
		
		gc.gridy = 1;
		gc.insets = new Insets(-15,0,0,0);
		headerMessagePanel.add(headingMessage, gc);
	
		gc.gridy = 2;
		gc.insets = new Insets(-30,0,0,0);
		headerMessagePanel.add(detailsPanel, gc);
		
		JPanel firstRow = new JPanel();
		firstRow.setBackground(UI_Settings.getButtonPanelColor());
		firstRow.setLayout(new BoxLayout(firstRow, BoxLayout.X_AXIS));
		
		JPanel fieldcontainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		fieldcontainer.setBackground(Color.WHITE);
		fieldcontainer.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 50));
		fieldcontainer.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 50));
		fieldcontainer.add(new JLabel("Group Name:"));
		fieldcontainer.add(cmbGroupName);
		
		fieldcontainer.add(new JLabel("Event Name:"));
		fieldcontainer.add(txtEventName);
		
		fieldcontainer.add(new JLabel("Start Date:"));
		fieldcontainer.add(txtStartDate);
		
		fieldcontainer.add(new JLabel("End Date:"));
		fieldcontainer.add(txtEndDate);
		
		fieldcontainer.setAlignmentX(Component.LEFT_ALIGNMENT);
		firstRow.add(fieldcontainer);
		
		firstRow.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,30));
		firstRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 30));

		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(17,0,0,0);
		detailsPanel.add(firstRow, gc);
		
	}
	
	private void setPanelSize(JPanel container, Dimension dimension) {
		
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
		
	}
	
	private JTextField initializeTextFields(JTextField textfield, int length) {
		textfield = new JTextField(length);
		textfield.setMinimumSize(textfield.getPreferredSize());
		textfield.setHorizontalAlignment(JTextField.LEFT);
		
		return textfield;
	}
	
	private void addSouthPanel() {
		//Begin Nested Details Panels (lowest panel on screen)
		pnlInformation = new JPanel();
		pnlInformation.setBackground(Color.WHITE);
		pnlInformation.setLayout(new GridBagLayout());
		pnlInformation.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlInformation.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlInformation.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		
		//Begin Nested Details Panels (lowest panel on screen)
		JPanel pnlSaveRow = new JPanel();
		pnlSaveRow.setBackground(Color.WHITE);
		pnlSaveRow.setLayout(new GridBagLayout());
		pnlSaveRow.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));

			//Create the far left container for the group details information
			JPanel pnlSaveLeftPane = new JPanel(new GridBagLayout());
			pnlSaveLeftPane.setBackground(Color.WHITE);
			pnlSaveLeftPane.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			
			//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,0,0,0);
			
				//Add the nested panels to the container panel (information panel)
			
				JPanel panel3 = new JPanel(new GridBagLayout());
				panel3.setBackground(Color.WHITE);
				panel3.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				
				
				JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row1.setBackground(Color.WHITE);
				row1.add(new JLabel("Table updated:"));
				row1.add(lblDate);
				
				JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row2.setBackground(Color.WHITE);
				row2.add(new JLabel("Connected to: " /*+ controller.getDBname()*/));
				
				JPanel row3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row3.setBackground(Color.WHITE);
				row3.add(new JLabel("Connection: Secure"));
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(5,5,0,5);
			
				panel3.add(row1, gc);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.insets = new Insets(0,5,0,5);
			
				panel3.add(row2, gc);
				
				gc.gridx = 0;
				gc.gridy = 2;
				gc.insets = new Insets(0,5,45,5);
			
				panel3.add(row3, gc);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.insets = new Insets(0,5,20,5);
			
				pnlSaveLeftPane.add(panel3, gc);
		
		pnlSaveRow.add(pnlSaveLeftPane, gc);
			
		//Create the second panel from the left (comments panel)
		JPanel pnlSaveRight = new JPanel(new GridBagLayout());
		pnlSaveRight.setBackground(Color.WHITE);
		pnlSaveRight.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));

			gc.gridx = 1;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHEAST;
			gc.insets = new Insets(0,0,0,0);
			pnlSaveRight.add(btnSaveEvent, gc);
			
			pnlSaveRow.add(pnlSaveRight, gc);
		
		pnlInformation.add(pnlSaveRow, gc);
	}

}
