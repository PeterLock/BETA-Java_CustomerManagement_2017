 package events.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.table.TableColumn;

import settings.UI_Settings;
import utilities.JTextFieldLimit;
import utilities.TextPrompt;
import utilities.UniqueIDGenerator;


public class AddEvent extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel headerMessagePanel;
	private JPanel detailsPanel;
	private JPanel pnlInformation;
	private JPanel canvas;
	private JPanel centerPanel;
	
	private UniqueIDGenerator idGenerator = new UniqueIDGenerator();
	private Calendar c = Calendar.getInstance();
	private JLabel lblDate = new JLabel(c.getTime().toString());
    private  JTextArea txtStudentListDisplayArea;
	private JButton btnSaveEvent;
	

	private JTextArea txtAreaDescription;
	private JLabel labels[];

	
	@SuppressWarnings("unused")
	private TextPrompt textPrompt;
	private  JPasswordField passwordField;
	
	private JComboBox<String> cmbGroupName = new JComboBox<String>(UI_Settings.getGroups());
	private JComboBox<String> cmbPreferredEmp_1 = new JComboBox<String>(UI_Settings.getEmployeeNames());
	private JComboBox<String> cmbPreferredEmp_2 = new JComboBox<String>(UI_Settings.getEmployeeNames());
	private JComboBox<String> cmbPreferredEmp_3 = new JComboBox<String>(UI_Settings.getEmployeeNames());
	private int screenwidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;

    private JTextField txtEndDate;
    private JTextField txtStartDate;
    private JTextField txtEventName;
    
    private events.controller.Controller controller = new events.controller.Controller();
	private GridBagConstraints gc = new GridBagConstraints();

	
	public AddEvent(){
	}
	
	public Component run(){
		JScrollPane scroller = initialize();
		return scroller;
	}

	private JScrollPane initialize() {
		labels = new JLabel[7];
		labels[0] = new JLabel("reset fields");
		labels[1] = new JLabel("undo move");
		labels[2] = new JLabel("help");
		labels[3] = new JLabel("...");
		labels[4] = new JLabel("clear table");
		labels[5] = new JLabel("view interests");
		labels[6] = new JLabel("view comments");
		
		txtStudentListDisplayArea = new JTextArea(7, 20);
		txtStudentListDisplayArea.setEditable(true);
		txtStudentListDisplayArea.setBorder(UI_Settings.getBorderoutline());
		txtStudentListDisplayArea.setWrapStyleWord(true);
		txtStudentListDisplayArea.setLineWrap(true);
		txtStudentListDisplayArea.setDocument(new JTextFieldLimit(150));
		txtStudentListDisplayArea.setPreferredSize(txtStudentListDisplayArea.getPreferredSize());
		
		TablePanel newEventTable = new TablePanel();
		
		int tableRowNumber = 12;
		
		try {
			controller.connect();
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		
		controller.setNumberOfRows(tableRowNumber);
		controller.setRowNumber(12);
		
		newEventTable.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*12)));
		newEventTable.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*12)));
		newEventTable.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*12)));
		newEventTable.setData(events.controller.Controller.getNewEvent(GET_ADDNEW_TABLE_ERRORLOG_LIST));

		
    	for(int i = 0; i < 12; i++){
    		FormEvent ev = new FormEvent(this, 0, "", "", "", "", "", "", "", "");
    		if(controller != null){
        		this.controller.addEmptyNewEvent(ev);
    		}
    	}
    	
    	
    	//setJTableColumnsWidth(table, 200, 10, 20, 10, 10, 10, 10);
    	setJTableColumnsWidth(newEventTable.getTable(), screenwidth, 30, 10, 10, 20, 10, 10, 10);
    	
    	controller.disconnect();
    	
		/********************************************************Set the Table Objects Sizes**************************************************/
		
    	newEventTable.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*12)));
    	newEventTable.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*12)));
		

		btnSaveEvent = new JButton("Save Event");
		btnSaveEvent.setPreferredSize(new Dimension(200,UI_Settings.getJbuttonSize().height));
		btnSaveEvent.setMinimumSize(new Dimension(200,UI_Settings.getJbuttonSize().height));
		btnSaveEvent.setFont(UI_Settings.getComponentInputFontSize());
		btnSaveEvent.addMouseListener(new MouseAdapter(){
			
			int id;
			String eventName;
			String groupName;
			String startDate;
			String endDate;
			String description;
			String pref1;
			String pref2;
			String pref3;
			
			FormEvent ev;
			
			public void mousePressed(MouseEvent e){
				
				try {
					controller.connect();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				
				int temp = idGenerator.getUniqueCustomerID();
				id=temp;
				eventName = txtEventName.getText();
				groupName = cmbGroupName.getSelectedItem().toString();
				startDate = txtStartDate.getText();
				endDate = txtEndDate.getText();
				description = txtAreaDescription.getText();
				pref1 = cmbPreferredEmp_1.getSelectedItem().toString();
				pref2 = cmbPreferredEmp_2.getSelectedItem().toString();
				pref3 = cmbPreferredEmp_3.getSelectedItem().toString();
				
				ev = new FormEvent(this, id, eventName, groupName, startDate, endDate, description, pref1, pref2, pref3);

				controller.addNewEvent(ev);
				try {
					controller.save();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			
			
			
		});
		
		/***********************Initialize Fields******************************/
		final JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());

		failedMessage.setVisible(false);
		
		final JLabel failedMessage1 = new JLabel(UI_Settings.getFailedMessage());
		failedMessage1.setForeground(UI_Settings.getFailedMessageColor());

		failedMessage1.setVisible(false);
		
		JLabel labels[] = new JLabel[5];
		
		labels[0] = new JLabel("reset fields");
		labels[1] = new JLabel("delete");
		labels[2] = new JLabel("edit");
		labels[3] = new JLabel("auto-fill preferred instructors");
		labels[4] = new JLabel("hint");


		for( int i = 0; i < 5; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		
        passwordField = new JPasswordField(10);
        passwordField.setActionCommand(UI_Settings.getOk());
		
		
        List<JTextField> textfields = new ArrayList<JTextField>();
        @SuppressWarnings("rawtypes")
		List<JComboBox> comboboxes = new ArrayList<JComboBox>();

        
		txtEndDate = new JTextField(6);
        txtEndDate.setEditable(true);
        txtEndDate.setMinimumSize(txtEndDate.getPreferredSize());
        txtEndDate.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtEndDate);
        
		txtStartDate = new JTextField(6);
		txtStartDate.setEditable(true);
		txtStartDate.setMinimumSize(txtEndDate.getPreferredSize());
		txtStartDate.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtStartDate);
        
		txtEventName = new JTextField(24);
		txtEventName.setEditable(true);
		txtEventName.setMinimumSize(txtEndDate.getPreferredSize());
		txtEventName.setHorizontalAlignment(JTextField.LEFT);
        textfields.add(txtEventName);
        
		/***************************************************Create textAreas********************************************************************/
		txtAreaDescription = new JTextArea(6, 30);
		txtAreaDescription.setEditable(true);
		txtAreaDescription.setMinimumSize(new Dimension((int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth()/2, (int)txtAreaDescription.getPreferredSize().getHeight()));
		txtAreaDescription.setBorder(UI_Settings.getBorderoutline());
		txtAreaDescription.setWrapStyleWord(true);
		txtAreaDescription.setLineWrap(true);
		txtAreaDescription.setDocument(new JTextFieldLimit(250));
		textPrompt = new TextPrompt("<enter a description of the event>", txtAreaDescription);
		
		/*********************************************************Create Combo Boxes*********************************************************/
		cmbGroupName.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbGroupName.setFont(UI_Settings.getComponentInputFontSize());
		cmbGroupName.setMinimumSize(cmbGroupName.getPreferredSize());
		//AutoCompletion.enable(cmbGroupName, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbGroupName);
		
		cmbPreferredEmp_1.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbPreferredEmp_1.setFont(UI_Settings.getComponentInputFontSize());
		cmbPreferredEmp_1.setMinimumSize(cmbPreferredEmp_1.getPreferredSize());
		//AutoCompletion.enable(cmbPreferredEmp_1, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbPreferredEmp_1);
		
		cmbPreferredEmp_2.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbPreferredEmp_2.setFont(UI_Settings.getComponentInputFontSize());
		cmbPreferredEmp_2.setMinimumSize(cmbPreferredEmp_2.getPreferredSize());
		//AutoCompletion.enable(cmbPreferredEmp_2, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbPreferredEmp_2);
		
		cmbPreferredEmp_3.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbPreferredEmp_3.setFont(UI_Settings.getComponentInputFontSize());
		cmbPreferredEmp_3.setMinimumSize(cmbPreferredEmp_3.getPreferredSize());
		//AutoCompletion.enable(cmbPreferredEmp_2, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbPreferredEmp_3);
		
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
		       int action = JOptionPane.showConfirmDialog(AddEvent.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		       
		       if(action == JOptionPane.OK_OPTION){
		    	   
		    	   cmbGroupName.setSelectedIndex(0);
				   failedMessage.setVisible(false);
				   failedMessage1.setVisible(false);
				   
				   txtAreaDescription.setText("");
				   
				   txtEventName.setText("");
				   txtStartDate.setText("");
				   txtEndDate.setText("");
				   passwordField.setText("");
				   
				   cmbPreferredEmp_1.setSelectedIndex(0);
				   cmbPreferredEmp_2.setSelectedIndex(0);
				   cmbPreferredEmp_3.setSelectedIndex(0);
				   
				   
		       }
			}
		});
		
		/******************************************************Add the Reset Panel************************************************/
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(labels[0]);//Reset label
		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		/**********************Create the Group Details Panel********************/

		addGroupDetailsPanel();
		addNorthPanel();
		addSouthPanel();
		
		/******************************************************Add the Reset Panel************************************************/

		Border border = BorderFactory.createLineBorder(Color.LIGHT_GRAY);
		JPanel heading = new JPanel();
		heading.setBackground(new Color(246,246,246));
		heading.setLayout(new BoxLayout(heading, BoxLayout.X_AXIS));
		
		heading.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		heading.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		heading.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel headLft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
		headLft.setBackground(Color.WHITE);
		headLft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		headLft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		headLft.add(failedMessage);
		headLft.add(new JLabel("Event Description:"));

		
		JPanel headRght = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		headRght.setBackground(Color.WHITE);
		headRght.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		headRght.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		headRght.add(labels[3]);
		//headRght.add(btnSort);

		
		headLft.setAlignmentX(Component.LEFT_ALIGNMENT);
		heading.add(headLft);
		
		headRght.setAlignmentX(Component.RIGHT_ALIGNMENT);
		heading.add(headRght);
		///////////////////////////////////////////////Add The Main Components To This Area//////////////////////////////////////////
				
		int paneloffset = 20;
		
		JPanel commentsPanel = new JPanel(new GridBagLayout());
		setPanelSize(commentsPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-paneloffset));
		commentsPanel.setBackground(Color.WHITE);
		
		//Add the comments box//
		JPanel comments = new JPanel(new GridBagLayout());
		setPanelSize(comments, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-paneloffset));
		comments.setBackground(Color.WHITE);
		//comments.setBorder(border);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.BOTH;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		comments.add(txtAreaDescription, gc);
		
		JPanel reportDetails = new JPanel(new GridBagLayout());
		setPanelSize(reportDetails, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-paneloffset));
		reportDetails.setBackground(new Color(246,246,246));
		reportDetails.setBorder(border);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.fill = GridBagConstraints.NONE;
		gc.insets = new Insets(15,20,0,0);
		reportDetails.add(new JLabel("Preference 1:"), gc);
		
		gc.gridx = 0;
		gc.gridy = 1;
		reportDetails.add(new JLabel("Preference 2:"), gc);
		
		gc.gridx = 0;
		gc.gridy = 2;
		reportDetails.add(new JLabel("Preference 3:"), gc);
		
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.insets = new Insets(10,0,0,20);
		reportDetails.add(cmbPreferredEmp_1, gc);
		
		gc.gridx = 1;
		gc.gridy = 1;
		reportDetails.add(cmbPreferredEmp_2, gc);
		
		gc.gridx = 1;
		gc.gridy = 2;
		reportDetails.add(cmbPreferredEmp_3, gc);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(5,5,5,0);
		commentsPanel.add(comments, gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.3;
		gc.weighty = 0.3;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(5,5,5,10);
		commentsPanel.add(reportDetails, gc);
				
		/******************************************************Create the Table Data Panel*******************************************/
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
	    buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(buttonPanel);
	    
        newEventTable.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(newEventTable);
        
        
        heading.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(heading);
        
        commentsPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(commentsPanel);
        
        pnlInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlInformation);
		/*********************************************************************************************************************************/
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 850));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 850));
		canvas.add(headerMessagePanel, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
		JScrollPane scroller = new JScrollPane(canvas);
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());
		return scroller;
	}
	
	public static void setJTableColumnsWidth(JTable table, int tablePreferredWidth,
	        double... percentages) {
	    double total = 0;
	    for (int i = 0; i < table.getColumnModel().getColumnCount(); i++) {
	        total += percentages[i];
	    }
	 
	    for (int i = 0; i < table.getColumnModel().getColumnCount(); i++) {
	        TableColumn column = table.getColumnModel().getColumn(i);
	        column.setPreferredWidth((int)
	                (tablePreferredWidth * (percentages[i] / total)));
	    }
	}
	
	private void addGroupDetailsPanel(){
		
		for(int i = 0; i < 7; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());	
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		
		txtStudentListDisplayArea = new JTextArea(7, 20);
		txtStudentListDisplayArea.setEditable(true);
		txtStudentListDisplayArea.setBorder(UI_Settings.getBorderoutline());
		txtStudentListDisplayArea.setWrapStyleWord(true);
		txtStudentListDisplayArea.setLineWrap(true);
		txtStudentListDisplayArea.setDocument(new JTextFieldLimit(150));
		txtStudentListDisplayArea.setPreferredSize(txtStudentListDisplayArea.getPreferredSize());
		
	}
	
	private void addNorthPanel() {
		JPanel heading = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		JLabel lblHeading = new JLabel("Adding scheduled event to groups");
		heading.setBackground(Color.WHITE);
		lblHeading.setFont(lblHeading.getFont().deriveFont(16.0f));
		heading.add(lblHeading);
		
		JPanel headingMessage = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		headingMessage.setBackground(Color.WHITE);
		JLabel lblHeadingMessage = new JLabel("Adding scheduled event details is simple. Choose the event name from the dropdown box below.\n"
				+ "Add all necessary information and you are done and choose which tile you want to assign to the event.");
		
		headingMessage.add(lblHeadingMessage);

		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.RED);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-30));
		detailsPanel.setLayout(new GridBagLayout());
		
		headerMessagePanel = new JPanel(new GridBagLayout());
		setPanelSize(headerMessagePanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 100));
		headerMessagePanel.setBackground(Color.WHITE);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		headerMessagePanel.add(heading,gc);
		
		gc.gridy = 1;
		gc.insets = new Insets(-15,0,0,0);
		headerMessagePanel.add(headingMessage, gc);
	
		gc.gridy = 2;
		gc.insets = new Insets(-30,0,0,0);
		headerMessagePanel.add(detailsPanel, gc);
		
		JPanel firstRow = new JPanel();
		firstRow.setBackground(UI_Settings.getButtonPanelColor());
		firstRow.setLayout(new BoxLayout(firstRow, BoxLayout.X_AXIS));
		
		JPanel fieldcontainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		fieldcontainer.setBackground(Color.WHITE);
		fieldcontainer.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 50));
		fieldcontainer.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 50));
		fieldcontainer.add(new JLabel("Group Name:"));
		fieldcontainer.add(cmbGroupName);
		
		fieldcontainer.add(new JLabel("Event Name:"));
		fieldcontainer.add(txtEventName);
		
		fieldcontainer.add(new JLabel("Start Date:"));
		fieldcontainer.add(txtStartDate);
		
		fieldcontainer.add(new JLabel("End Date:"));
		fieldcontainer.add(txtEndDate);
		
		fieldcontainer.setAlignmentX(Component.LEFT_ALIGNMENT);
		firstRow.add(fieldcontainer);
		
		firstRow.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,30));
		firstRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 30));

		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(17,0,0,0);
		detailsPanel.add(firstRow, gc);
		
	}
	
	private void setPanelSize(JPanel container, Dimension dimension) {
		
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
		
	}
	
	private void addSouthPanel() {
		//Begin Nested Details Panels (lowest panel on screen)
		pnlInformation = new JPanel();
		pnlInformation.setBackground(Color.WHITE);
		pnlInformation.setLayout(new GridBagLayout());
		pnlInformation.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlInformation.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlInformation.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		
		//Begin Nested Details Panels (lowest panel on screen)
		JPanel pnlSaveRow = new JPanel();
		pnlSaveRow.setBackground(Color.WHITE);
		pnlSaveRow.setLayout(new GridBagLayout());
		pnlSaveRow.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));

			//Create the far left container for the group details information
			JPanel pnlSaveLeftPane = new JPanel(new GridBagLayout());
			pnlSaveLeftPane.setBackground(Color.WHITE);
			pnlSaveLeftPane.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			
			//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,0,0,0);
			
				//Add the nested panels to the container panel (information panel)
			
				JPanel panel3 = new JPanel(new GridBagLayout());
				panel3.setBackground(Color.WHITE);
				panel3.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				
				
				JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row1.setBackground(Color.WHITE);
				row1.add(new JLabel("Table updated:"));
				row1.add(lblDate);
				
				JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row2.setBackground(Color.WHITE);
				row2.add(new JLabel("Connected to: " /*+ controller.getDBname()*/));
				
				JPanel row3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row3.setBackground(Color.WHITE);
				row3.add(new JLabel("Connection: Secure"));
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(5,5,0,5);
			
				panel3.add(row1, gc);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.insets = new Insets(0,5,0,5);
			
				panel3.add(row2, gc);
				
				gc.gridx = 0;
				gc.gridy = 2;
				gc.insets = new Insets(0,5,45,5);
			
				panel3.add(row3, gc);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.insets = new Insets(0,5,20,5);
			
				pnlSaveLeftPane.add(panel3, gc);
		
		pnlSaveRow.add(pnlSaveLeftPane, gc);
			
		//Create the second panel from the left (comments panel)
		JPanel pnlSaveRight = new JPanel(new GridBagLayout());
		pnlSaveRight.setBackground(Color.WHITE);
		pnlSaveRight.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));

			gc.gridx = 1;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHEAST;
			gc.insets = new Insets(0,0,0,0);
			pnlSaveRight.add(btnSaveEvent, gc);
			
			pnlSaveRow.add(pnlSaveRight, gc);
		
		pnlInformation.add(pnlSaveRow, gc);
	}
	
	
	
	
	private final static int GET_ADDNEW_TABLE_ERRORLOG_LIST = 2;
	
	
}
