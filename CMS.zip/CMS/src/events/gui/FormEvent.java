package events.gui;

import java.util.EventObject;

public class FormEvent extends EventObject{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String groupname;
	private String pref1;
	private String pref2;
	private String start;
	private String finish;
	private String desription;
	private int ID;

	public String getGroupname() {
		return groupname;
	}

	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}

	public String getPref1() {
		return pref1;
	}

	public void setPref1(String pref1) {
		this.pref1 = pref1;
	}

	public String getPref2() {
		return pref2;
	}

	public void setPref2(String pref2) {
		this.pref2 = pref2;
	}


	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public String getFinish() {
		return finish;
	}

	public void setFinish(String finish) {
		this.finish = finish;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public FormEvent(Object source, String groupname, String pref1, String pref2, String start, String finish, String description, int number) {
		super(source);
		
		this.groupname = groupname;
		this.pref1 = pref1;
		this.pref2 = pref2;
		this.start = start;
		this.finish = finish;
		this.desription = description;
		this.ID = number;
		
	}

	public String getDesription() {
		return desription;
	}

	public void setDesription(String desription) {
		this.desription = desription;
	}

}
