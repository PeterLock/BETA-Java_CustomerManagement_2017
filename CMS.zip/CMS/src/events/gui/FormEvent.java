package events.gui;

import java.awt.event.MouseAdapter;
import java.util.EventObject;

public class FormEvent extends EventObject{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String eventname;
	private String groupname;
	private String pref1;
	private String pref2;
	private String pref3;
	private String start;
	private String finish;
	private String desription;
	private int id;

	public FormEvent(Object source, int id, String eventName, String groupName, String startDate, String endDate, String description, String pref1, String pref2, String pref3) {
		super(source);
		this.eventname = eventName;
		this.groupname = groupName;
		this.pref1 = pref1;
		this.pref2 = pref2;
		this.pref3 = pref3;
		this.start = startDate;
		this.finish = endDate;
		this.desription = description;
		this.id = id;
	}
	
	public String getEventname() {
		return eventname;
	}

	public void setEventname(String eventname) {
		this.eventname = eventname;
	}
	
	public String getGroupname() {
		return groupname;
	}


	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}


	public String getPref1() {
		return pref1;
	}


	public void setPref1(String pref1) {
		this.pref1 = pref1;
	}


	public String getPref2() {
		return pref2;
	}


	public void setPref2(String pref2) {
		this.pref2 = pref2;
	}


	public String getPref3() {
		return pref3;
	}


	public void setPref3(String pref3) {
		this.pref3 = pref3;
	}


	public String getStart() {
		return start;
	}


	public void setStart(String start) {
		this.start = start;
	}


	public String getFinish() {
		return finish;
	}


	public void setFinish(String finish) {
		this.finish = finish;
	}


	public String getDesription() {
		return desription;
	}


	public void setDesription(String desription) {
		this.desription = desription;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


}
