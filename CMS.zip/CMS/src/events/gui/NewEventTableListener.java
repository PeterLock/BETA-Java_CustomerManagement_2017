package events.gui;

public interface NewEventTableListener {
	public void rowDeleted(int row);
}
