package events.controller;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import events.gui.FormEvent;
import events.model.Database;
import events.model.NewEvent;

public class Controller {
	
	public Controller(){
	}
	
	public void showGroupControllerMessage(){
	}
	
	static Database db = new Database();
	
	public void addNewEvent(events.gui.FormEvent ev){

		int id = ev.getId();
		
		String eventname = ev.getEventname();
		String groupname = ev.getGroupname();
		String startDate = ev.getStart();
		String finishDate = ev.getFinish();
		String description = ev.getDesription();
		String pref1 = ev.getPref1();
		String pref2 = ev.getPref2();
		String pref3 = ev.getPref3();
		
		
		NewEvent newevent = new NewEvent(id, eventname, groupname, startDate, finishDate, description, pref1, pref2, pref3);
		
		db.addNewEvent(newevent);
	}

	public void save() throws SQLException {
		db.saveNewEvent();
	}

	public void load() throws SQLException {
		db.load();
	}

	public void connect() throws Exception {
		db.connect();
	}

	public void saveToFile(File file) throws IOException {
		//db.saveToFile(file);
	}
	
	public void loadFromFile(File file) throws IOException {
		//db.loadFromFile(file);
	}

	public void setNumberOfRows(int tableRowNumber) {
		db.setAddNewRowNumber(tableRowNumber);
	}

	public static List<NewEvent> getNewEvents() {
		return db.getNewEvents();
	}
	
	public static List<NewEvent> getEmptyNewEvent() {
		return db.getEmpty_event();
	}



	public String getDBname() {
		return db.getName();
	}

	public void deleteNewEvent(int id) {
		db.deleteNewEvent(id);
	}
	
	///////////////////////////////////////// Methods for adding new customers from the group panel ////////////////////////////////////////
	public void setRowNumber(int i) {
		db.setAddNewRowNumber(i);
	}
	
	public static List<NewEvent> getNewEvent(int value){
		
		if(value == 1){
			return db.getNewEvents();
		}else{
			return db.getEmpty_event();
		}
		
	}
	
	
	public void addEmptyNewEvent(FormEvent ev) {
		NewEvent newevent = new NewEvent(0, "", "", "", "", "", "", "", "");
		db.addNewEvent(newevent);
	}
	
	public void removeNewEvent(int index, int i){
		db.removeNewEvent(index, i);
	}
	
	public void saveNewEvent() throws SQLException {
		db.saveNewEvent();
	}

	public void setNewEventRowNumber(int value) {
		db.setAddNewRowNumber(value);
	}

	public void searchNewEvent(int id) {
		db.searchNewEvent(id);
	}

	public void clearAddNewTable() {
		db.clearAddNewEventTableData();
	}

	public void disconnect() {
		db.disconnect();
	}
}
