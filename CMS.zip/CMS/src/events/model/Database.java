package events.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import events.model.NewEvent;

public class Database {
	
	private List<NewEvent> viewall_events;
	private List<NewEvent> addnew_events;

	private int count = 0;
	private Connection con;
	private int setNumberOfRows = 0;
	private int setViewAllRowNumber = 0;
	private int flag = 0;
	
	public Database(){
		try {
			connect();
		} catch (Exception e) {
			e.printStackTrace();
		}
		viewall_events = new ArrayList<NewEvent>();
		addnew_events = new ArrayList<NewEvent>();
	}
	
	public void connect() throws Exception{
		
	    con = null;
	    try {
	      Class.forName("org.sqlite.JDBC");
	      con = DriverManager.getConnection("jdbc:sqlite:CMS_DB.db");
	    } catch ( Exception e ) {
	      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
	      System.exit(0);
	    }
	    System.out.println("Opened events database successfully");
	}
	
	public void disconnect(){
		if(con != null){
			try {
				con.close();
				System.out.println("Closed events database successfully");
			} catch (SQLException e) {
				System.out.println("Can't close the connection");
			}
		}
	}
	public void saveNewEvent() throws SQLException{
		if(flag == 1)return;
		try {
			connect();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("save event triggered");
		String checkSql = "select count(*) as count from EventsList where id=?";
		PreparedStatement checkStmt = con.prepareStatement(checkSql);
		String insertSql = "INSERT INTO EventsList (id, eventName, groupName, startDate, endDate, description, preference1, preference2, preference3) values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement insertStatement = con.prepareStatement(insertSql);
		String updateSql = "UPDATE EventsList set eventName=?, groupName=?, startDate=?, endDate=?, description=?, preference1=?, preference2=?, preference3=? where id=?";
		PreparedStatement updateStatement = con.prepareStatement(updateSql);
		
		
		for(NewEvent newevent : addnew_events){
			int t = newevent.getId();
			if(t > 0){
				int id = newevent.getId();
				String eventname = newevent.getEventname();
				String groupname = newevent.getGroupname();
				String startDate = newevent.getStart();
				String finishDate = newevent.getFinish();
				String description = newevent.getDesription();
				String pref1 = newevent.getPref1();
				String pref2 = newevent.getPref2();
				String pref3 = newevent.getPref3();
				
				checkStmt.setInt(1, id);
				
				ResultSet checkResult = checkStmt.executeQuery();
				checkResult.next();
				
				int count = checkResult.getInt(1);
				if(count == 0){
					int col = 1;
					insertStatement.setInt(col++, id);
					insertStatement.setString(col++, eventname);
					insertStatement.setString(col++, groupname);
					insertStatement.setString(col++, startDate);
					insertStatement.setString(col++, finishDate);
					insertStatement.setString(col++, description);
					insertStatement.setString(col++, pref1);
					insertStatement.setString(col++, pref2);
					insertStatement.setString(col++, pref3);
					insertStatement.executeUpdate();
				}
				else{
					int col = 1;
					
					updateStatement.setString(col++, eventname);
					updateStatement.setString(col++, groupname);
					updateStatement.setString(col++, startDate);
					updateStatement.setString(col++, finishDate);
					updateStatement.setString(col++, description);
					updateStatement.setString(col++, pref1);
					updateStatement.setString(col++, pref2);
					updateStatement.setString(col++, pref3);
					updateStatement.setInt(col++, id);
					updateStatement.executeUpdate();
				}
			}
		}
		updateStatement.close();
		insertStatement.close();
		checkStmt.close();
	    System.out.println("New event created successfully");
	    disconnect();
	  }
	
	public void load() throws SQLException{
		if(flag == 1)return;
		viewall_events.clear();
	    Connection c = null;
	    Statement stmt = null;
	    try {
	      Class.forName("org.sqlite.JDBC");
	      c = DriverManager.getConnection("jdbc:sqlite:CMS_DB.db");
	      c.setAutoCommit(false);
	      System.out.println("Opened database successfully");

	      stmt = c.createStatement();
	      ResultSet rs = stmt.executeQuery( "SELECT * FROM EventsList;" );
	      while ( rs.next() ) {
				int id = rs.getInt("id");
				
				String eventname = rs.getString("eventName");
				String groupname = rs.getString("groupName");
				String startDate = rs.getString("startDate");
				String finishDate = rs.getString("endDate");
				String description = rs.getString("description");
				String pref1 = rs.getString("preference1");
				String pref2 = rs.getString("preference2");
				String pref3 = rs.getString("preference3");
				
				NewEvent newevent = new NewEvent(id, eventname, groupname, startDate, finishDate, description, pref1, pref2, pref3);

				viewall_events.add(newevent);
	      }
	      rs.close();
	      stmt.close();
	      c.close();
	    } catch ( Exception e ) {
	      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
	      System.exit(0);
	    }
	    
		if(viewall_events.size() < setViewAllRowNumber){
			populateRemainingRows(viewall_events, setViewAllRowNumber);
		}
		flag = 0;
	    System.out.println("Loaded database successfully");
	}
		

	public void removeNewEvent(int index, int i){
		if(index <0){
			return;
		}else{
			if( i == 1){
				int remove_id = viewall_events.get(index).getId();
				viewall_events.remove(index);
				populateRemainingRows(viewall_events, setViewAllRowNumber);
				delete(remove_id);
				try {
					this.saveNewEvent();
				} catch (SQLException e) {
					System.err.println("Unable to save database");
				}
			}
			if( i == 2){
				addnew_events.remove(index);
				populateRemainingRows(addnew_events, setNumberOfRows);			
			}
		}
	}
	
	private void delete(int remove_id) {
		// TODO Auto-generated method stub
		
	}

	public void deleteNewEvent(int remove_id) {
		 try 
		 {  
			PreparedStatement statement = con.prepareStatement("DELETE FROM EventsList WHERE id = ?");
			statement.setInt(1,remove_id);
			statement.executeUpdate(); 
		 }
		 catch(Exception e)
		 {
		     System.out.println("Could not delete from database.");
		 }
	}

	public void addNewEvent(NewEvent newevent){
		if(this.addnew_events.size()==setNumberOfRows){
			this.addnew_events.add(0, newevent);
			this.addnew_events.remove(this.addnew_events.get(this.getEmpty_event().size()-1));
		}else{
			if(count >setNumberOfRows){
				this.addnew_events.add(0, newevent);
			}else{
				this.addnew_events.add(0, newevent);
				count++;	
			}
		}
	}
	
	public void addNewEventViewAllTable(NewEvent newevent){
		if(this.viewall_events.size()==setViewAllRowNumber){
			this.viewall_events.add(0, newevent);
			this.viewall_events.remove(this.viewall_events.get(this.getNewEvents().size()-1));
		}else{
			if(count >setViewAllRowNumber){
				this.viewall_events.add(0, newevent);
			}else{
				this.viewall_events.add(0, newevent);
				count++;	
			}
		}
	}
	
	public List<NewEvent>getNewEvents(){
		return viewall_events;
	}
	
	public List<NewEvent> getEmpty_event() {
		return addnew_events;
	}
	
	public void saveToFile(File file) throws IOException{
		FileOutputStream fos = new FileOutputStream(file);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		NewEvent[] newevents = this.viewall_events.toArray(new NewEvent[this.viewall_events.size()]);
		oos.reset();
		oos.writeObject(newevents);
		fos.close();
		oos.close();
	}
	
	public void loadFromFile(File file) throws IOException {
		FileInputStream fis = new FileInputStream(file);
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		try {
			NewEvent[] newevents = (NewEvent[]) ois.readObject();
			viewall_events.clear();
			viewall_events.addAll(Arrays.asList(newevents));
			if(viewall_events.size() < setViewAllRowNumber){
				populateRemainingRows(viewall_events, setViewAllRowNumber);
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		fis.close();
		ois.close();
	}

	public void populateRemainingRows(List<NewEvent> data, int j) {
       	for(int i = data.size()+1; i <=j; i++){
       		data.add(new NewEvent(0, "", "", "", "", "", "", "", ""));
    	}
	}

	public String getName() {
		return "CIS_DB";
	}

	public void setAddNewRowNumber(int i) {
		this.setNumberOfRows = i;
	}
	
	public void setViewAllRowNumber(int tableRowNumber) {
		this.setViewAllRowNumber  = tableRowNumber;
	}

	public void clearViewAllTableData() {
		this.viewall_events.clear();
		count = 0;
	}

	public void clearAddNewEventTableData() {
		this.addnew_events.clear();
		count = 0;
	}

	public void buildEmptyTable() {
       	for(int i = viewall_events.size()+1; i <=setViewAllRowNumber; i++){
       		viewall_events.add(new NewEvent(0, "", "", "", "", "", "", "", ""));
    	}
       	System.err.println("Database is not connected. Building empty table");
       	flag = 1;
	}

	public NewEvent searchNewEvent(int id) {
		return null;
	}
}
