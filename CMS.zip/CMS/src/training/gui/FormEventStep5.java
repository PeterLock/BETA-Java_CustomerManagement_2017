package training.gui;

import java.util.EventObject;

public class FormEventStep5 extends EventObject {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String firstWe;
	String thenWe;
	String andFinallyWe;
	String whatIsTheNextStep;
	String whenIsTheNextMeeting;
	public String getFirstWe() {
		return firstWe;
	}

	public void setFirstWe(String firstWe) {
		this.firstWe = firstWe;
	}

	public String getThenWe() {
		return thenWe;
	}

	public void setThenWe(String thenWe) {
		this.thenWe = thenWe;
	}

	public String getAndFinallyWe() {
		return andFinallyWe;
	}

	public void setAndFinallyWe(String andFinallyWe) {
		this.andFinallyWe = andFinallyWe;
	}

	public String getWhatIsTheNextStep() {
		return whatIsTheNextStep;
	}

	public void setWhatIsTheNextStep(String whatIsTheNextStep) {
		this.whatIsTheNextStep = whatIsTheNextStep;
	}

	public String getWhenIsTheNextMeeting() {
		return whenIsTheNextMeeting;
	}

	public void setWhenIsTheNextMeeting(String whenIsTheNextMeeting) {
		this.whenIsTheNextMeeting = whenIsTheNextMeeting;
	}

	public String getAdditionalNotes() {
		return additionalNotes;
	}

	public void setAdditionalNotes(String additionalNotes) {
		this.additionalNotes = additionalNotes;
	}

	String additionalNotes;

	public FormEventStep5(Object source, String firstWe, String thenWe, String andFinallyWe, String whatIsTheNextStep, String whenIsTheNextMeeting, String additionalNotes) {
		super(source);
		
		this.firstWe = firstWe;
		this.thenWe = thenWe;
		this.andFinallyWe = andFinallyWe;
		this.whatIsTheNextStep = whatIsTheNextStep;
		this.whenIsTheNextMeeting = whenIsTheNextMeeting;
		this.additionalNotes = additionalNotes;
	}

}
