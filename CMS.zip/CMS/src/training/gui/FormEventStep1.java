package training.gui;

import java.util.EventObject;

import javax.swing.JTextField;

public class FormEventStep1 extends EventObject {
	
	String presenter = "";
	String sessionTitle = "";
	String topic1Title = "";
	String topic2Title = "";
	public String getPresenter() {
		return presenter;
	}


	public void setPresenter(String presenter) {
		this.presenter = presenter;
	}


	public String getSessionTitle() {
		return sessionTitle;
	}


	public void setSessionTitle(String sessionTitle) {
		this.sessionTitle = sessionTitle;
	}


	public String getTopic1Title() {
		return topic1Title;
	}


	public void setTopic1Title(String topic1Title) {
		this.topic1Title = topic1Title;
	}


	public String getTopic2Title() {
		return topic2Title;
	}


	public void setTopic2Title(String topic2Title) {
		this.topic2Title = topic2Title;
	}


	public String getTopic3Title() {
		return topic3Title;
	}


	public void setTopic3Title(String topic3Title) {
		this.topic3Title = topic3Title;
	}


	String topic3Title = "";


	public FormEventStep1(Object source, String presenter, String sessionTitle, String topic1Title, String topic2Title, String topic3Title ) {
		super(source);
		
		this.presenter = presenter;
		this.sessionTitle = sessionTitle;
		this.topic1Title = topic1Title;
		this.topic2Title = topic2Title;
		this.topic3Title = topic3Title;
	}

}
