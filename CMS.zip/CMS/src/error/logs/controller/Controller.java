package error.logs.controller;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import error.logs.model.Database;
import error.logs.model.ErrorLog;


public class Controller {
	
	static Database db = new Database();
	
	public Controller(){
	}
	
	public void showErrorControllerMessage(){
	}
	
	public void addErrorLog(error.logs.gui.FormEvent ev) throws SQLException {
		
		

		int id = ev.getId();
		String alertDescription = ev.getDescription();
		String alertDate = ev.getAlertDate();
		int alertLevel = ev.getAlertLvl();
		
		
		ErrorLog errorlog = new ErrorLog(id, alertDescription, alertDate, alertLevel);
		
		db.addNewErrorLog(errorlog);
		db.save();
	}

	public void save() throws SQLException {
		db.save();
	}

	public void load() throws SQLException {
		db.load();
	}

	public void connect() throws Exception {
		db.connect();
	}

	public void saveToFile(File file) throws IOException {
	}
	
	public void loadFromFile(File file) throws IOException {
	}

	public void removeErrorLog(int row, int i) {
		db.removeErrorLog(row, i);
		
	}

	public void setNumberOfRows(int tableRowNumber) {
		db.setAddNewRowNumber(tableRowNumber);
	}

	public static List<ErrorLog> getErrorLog(int value) {
		
		if(value == 1){
			return db.getErrorLogs();
		}else{
			return db.getEmptyErrorLog();
		}
	}
	
	public static List<ErrorLog> getEmptyErrorLog() {
		return db.getEmptyErrorLog();
	}

	public void addEmptyErrorLog() {

   		ErrorLog errorlog = new ErrorLog(0, "", "", 0);


		db.addEmptyErrorLog(errorlog);
	}

	public String getDBname() {
		return db.getName();
	}


	public void setErrorLogRowNumber(int rows) {
		db.addNewErrorLogRowNumber(rows);
	}

	public void disconnect() {
		db.disconnect();
	}

	public static List<ErrorLog> getErrorLogFrom(int getAddnewTableErrorLogList) {
		return null;
	}

}
