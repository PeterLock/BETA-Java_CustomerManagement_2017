package error.logs.model;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;


public class Database {
	
	private List<ErrorLog> error_list = new ArrayList<ErrorLog>();
	private List<ErrorLog> loaded_error_list = new ArrayList<ErrorLog>();
	private int flag = 0;

	private List<ErrorLog> addnew_error;
	private List<ErrorLog> viewall_error;

	private int setNumberOfRows = 0;
	private int setViewAllRowNumber = 0;
	
	private int setAddErrorRowNumber = 4;
	private int setViewAllWaitingRowNumber = 0;
	
	private int count = 0;
	private Connection con;
	
	public Database(){
		error_list = new ArrayList<ErrorLog>();
		loaded_error_list = new ArrayList<ErrorLog>();
	}
	
	public void connect() throws Exception{
		
	    con = null;
	    try {
	      Class.forName("org.sqlite.JDBC");
	      con = DriverManager.getConnection("jdbc:sqlite:CMS_DB.db");
	    } catch ( Exception e ) {
	      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
	      System.exit(0);
	    }
	}
	
	public void disconnect(){
		if(con != null){
			try {
				con.close();
			} catch (SQLException e) {
				System.out.println("Can't close the connection");
			}
		}
	}
	
	public void save() throws SQLException{
		
		String checkSql = "select count(*) as count from AlertsList where id=?";
		PreparedStatement checkStmt = con.prepareStatement(checkSql);
		
		String insertSql = "insert into AlertsList (id, alertDescription, alertDate, alertLevel) values (?, ?, ?, ?)";
		PreparedStatement insertStatement = con.prepareStatement(insertSql);
		

		String updateSql = "update AlertsList set alertDescription=?, alertDate=?, alertLevel=? where id=?";
		PreparedStatement updateStatement = con.prepareStatement(updateSql);
		
		for(ErrorLog errorlogs : error_list){
			
			int t = errorlogs.getId();
			if(t > 0){
				
				int id = errorlogs.getId();
				String alertDescription = errorlogs.getDescription();
				String alertDate = errorlogs.getAlertDate();
				int alertLevel = errorlogs.getAlertLvl();
				
				checkStmt.setInt(1, id);
				
				ResultSet checkResult = checkStmt.executeQuery();
				checkResult.next();
				
				int count = checkResult.getInt(1);
				
				
				if(count == 0){
					System.out.println("Inserting ErrorLogs with ID " + id);
					
					int col = 1;

					insertStatement.setInt(col++, id);
					insertStatement.setString(col++, alertDescription);
					insertStatement.setString(col++, alertDate);
					insertStatement.setInt(col++, alertLevel);

					insertStatement.executeUpdate();

				}
				else{
					System.out.println("Updating ErrorLogs with ID " + id);
					
					int col = 1;
					
					updateStatement.setString(col++, alertDescription);
					updateStatement.setString(col++, alertDate);
					updateStatement.setInt(col++, alertLevel);
					
					updateStatement.setInt(col++, id);
					
					updateStatement.executeUpdate();
				}
			}
		}
		updateStatement.close();
		insertStatement.close();
		checkStmt.close();
		
	}
	
	public void load(){
		
	}
	
	public void addNewErrorLog(ErrorLog errorlog){
		
		if(this.error_list.size()==setNumberOfRows){
			this.error_list.add(0, errorlog);
			this.error_list.remove(this.error_list.get(this.getEmptyErrorLog().size()-1));
		}else{
			if(count >setNumberOfRows){
				this.error_list.add(0, errorlog);
			}else{
				this.error_list.add(0, errorlog);
				count++;	
			}
		}
		
		try {
			this.save();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void addEmptyErrorLog(ErrorLog errorlog){
	}
	
	public void printErrorLog(){
	}
	
	public void saveToFile(File file) throws IOException{
		FileOutputStream fos = new FileOutputStream(file);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		ErrorLog[] errorlogs = this.error_list.toArray(new ErrorLog[this.error_list.size()]);
		
		oos.writeObject(errorlogs);
		
		fos.close();
		oos.close();
		
	}
	
	public void loadFromFile(File file) throws IOException {
		
	}
	
	public void removeErrorLog(int index, int i){
		if(index <0){
			return;
		}else{
			if( i == 1){
				int remove_id = viewall_error.get(index).getId();
				
				viewall_error.remove(index);

				populateRemainingErrorLogRows(viewall_error, setViewAllRowNumber);
				
				delete(remove_id);
				
				try {
					this.save();
				} catch (SQLException e) {
					System.err.println("Unable to save database");
				}

			}
			if( i == 2){
				addnew_error.remove(index);
				populateRemainingErrorLogRows(addnew_error, setNumberOfRows);			
			}
		}
	}
	
	
	public void populateRemainingErrorLogRows(List<ErrorLog> data, int j) {
       	for(int i = data.size()+1; i <=j; i++){
       		data.add(new ErrorLog(0,"","",0));
    	}
	}
	
	public void delete(int remove_id){
		
	}
	
	public void setAddNewRowNumber(int i) {
		setNumberOfRows = i;
	}

	public List<ErrorLog> getErrorLogs() {
		return loaded_error_list;
	}
	
	public List<ErrorLog> getEmptyErrorLog() {
		return error_list;
	}
	
	public void populateRemainingRows(List<ErrorLog> data, int j) {
		
       	for(int i = data.size()+1; i <=j; i++){
       		data.add(new ErrorLog(0,"","",0));
    	}
	}
	public String getName() {
		return "CIS_DB";
	}
	
	public ErrorLog searchErrorLogs(String errorlogs){
		return null;
	}
	
	public void addNewErrorLogRowNumber(int rows) {
		setAddErrorRowNumber = rows;
	}
}
