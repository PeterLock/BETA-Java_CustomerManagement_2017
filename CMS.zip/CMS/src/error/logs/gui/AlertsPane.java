package error.logs.gui;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Calendar;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ColorUIResource;

import control.build.TableTemplate;
import settings.UI_Settings;
import utilities.AutoCompletion;

public class AlertsPane extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static JTabbedPane pane = new JTabbedPane();
	private JPanel headerMessagePanel;
	private JPanel detailsPanel;
	
	private GridBagConstraints gc = new GridBagConstraints();
	
	private JPanel pnlSaveInformation;
	private Calendar c = Calendar.getInstance();
	private JLabel lblDate = new JLabel(c.getTime().toString());
	private JButton btnDeleteEvent;
	private JCheckBox chkMatchRequest = new JCheckBox("delete error log");
	private JCheckBox chkDeleteCustomer = new JCheckBox("clear all logs");

	TD_PaneAlerts viewAllAlertsTableData = new TD_PaneAlerts();
	TableTemplate viewAllAlertsTable = new TableTemplate(viewAllAlertsTableData, viewAllAlertsTableData.getCOLUMN_PERCENTAGES(), "");

	
	public AlertsPane() {
        initializeUI();
    }

    private void initializeUI() {
    	
		chkMatchRequest.setFont(UI_Settings.getComponentsFontPlain());
		chkMatchRequest.setForeground(UI_Settings.getComponentsFontColorLight());
		
		chkDeleteCustomer.setFont(UI_Settings.getComponentsFontPlain());
		chkDeleteCustomer.setForeground(UI_Settings.getComponentsFontColorLight());
    	
		btnDeleteEvent = new JButton("Perform Action");
		btnDeleteEvent.setPreferredSize(new Dimension(200,UI_Settings.getJbuttonSize().height));
		btnDeleteEvent.setMinimumSize(new Dimension(200,UI_Settings.getJbuttonSize().height));

		btnDeleteEvent.setFont(UI_Settings.getComponentInputFontSize());

    	setLayout(new BorderLayout());
        setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, java.awt.Toolkit.getDefaultToolkit().getScreenSize().height));

        UIManager.put("Label.font", UI_Settings.getComponentsFontPlain());
    	UIManager.put("Label.foreground", UI_Settings.getComponentsFontColorDark());
    	
    	
        //OK
        UIManager.put("TabbedPane.selected", new ColorUIResource(UI_Settings.getBottomTabColor()));
        UIManager.put("TabbedPane.unselectedTabBackground", UI_Settings.getCmsGray());       
        
       // pane.setForeground(Color.WHITE);
        pane.setFocusable(false);
        pane.setBorder(new EmptyBorder(0, 0, 0, 0));


        //OK
        UIManager.getDefaults().put("TabbedPane.tabAreaInsets", new Insets(0,0,0,0));
        UIManager.put("TabbedPane.contentBorderInsets", new Insets(0, 0, 0, 0)); 
        

        //Sets the JPanel container to black
        setBackground(UI_Settings.getCmsTabSecondLvlGrey());
        pane.addTab("<html><body><table width='50' style='font-size:11'><td style='text-align:center'>Alerts</td></table></body></html>", showAlerts());		//0
        
        //Set the text color for each tab
        pane.setForeground(Color.WHITE);

        pane.setBackgroundAt(0, UI_Settings.getCmsGray());	//0

    
        changeUI(UI_Settings.getBottomTabColor());

    }

    public void changeUI( Color bottomTabColor) {
        pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
            @Override protected int calculateTabHeight(
              int tabPlacement, int tabIndex, int fontHeight) {
            	
    	       highlight = UI_Settings.getCmsTabSecondLvlGrey();
    	       lightHighlight = UI_Settings.getCmsTabSecondLvlGrey();
    	       shadow = UI_Settings.getCmsTabSecondLvlGrey();
    	       darkShadow = UI_Settings.getCmsTabSecondLvlGrey();
    	       focus = UI_Settings.getCmsTabSecondLvlGrey();
            	
              return 27;
            }
            
            
            @Override protected void paintTab(
              Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
              Rectangle iconRect, Rectangle textRect) {
        
               rects[tabIndex].height = 25 + 1;
               rects[tabIndex].y = 20 - rects[tabIndex].height + 7;
              
              super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
            }
          });
        
        //Add the tab to the canvas
        this.add(pane, BorderLayout.CENTER);		
	}

	public static void showFrame() {
        JPanel panel = new AlertsPane();
        panel.setOpaque(true);

        JFrame frame = new JFrame("CMS Test Screen");
        JFrame.setDefaultLookAndFeelDecorated(false);
        frame.setPreferredSize(UI_Settings.getMinimumScreenSize());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(panel);
        frame.pack();
        frame.setVisible(true);
    }
    
    public void changeTheme(Color c) {
      UIManager.put("TabbedPane.selected",new ColorUIResource(c));
		 
      pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
          @Override protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
        	  
            return 27;
          }
      });
      
      pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
	    @Override protected int calculateTabHeight(
	      int tabPlacement, int tabIndex, int fontHeight) {
	    	
	       highlight = UI_Settings.getCmsTabSecondLvlGrey();
	       lightHighlight = UI_Settings.getCmsTabSecondLvlGrey();
	       shadow = UI_Settings.getCmsTabSecondLvlGrey();
	       darkShadow = UI_Settings.getCmsTabSecondLvlGrey();
	       focus = UI_Settings.getCmsTabSecondLvlGrey();
	    	
	      return 27;
	    }
	    
	    
	    @Override protected void paintTab(
	      Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
	      Rectangle iconRect, Rectangle textRect) {
	
	       rects[tabIndex].height = 25 + 1;
	       rects[tabIndex].y = 20 - rects[tabIndex].height + 7;
	      
	      super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
	    }
	  });
	}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                AlertsPane.showFrame();
            }
        });
    }
    
	public Component showAlerts()
		{
			JPanel canvas;
			JPanel centerPanel;
			JButton btnSort;
			
			
			/*****************************************************************************************************************************/
			btnSort = new JButton("Sort");
			btnSort.setCursor(new Cursor(Cursor.HAND_CURSOR));
			btnSort.setPreferredSize(UI_Settings.getJbuttonSize());
			btnSort.setFont(UI_Settings.getComponentInputFontSize());
			
			JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
			failedMessage.setForeground(UI_Settings.getFailedMessageColor());
	
			failedMessage.setVisible(false);
			
			/******************************************************Add the north panel************************************************/
	
			addNorthPanel();
			addSouthPanel();
			
			
			JLabel[] labels = new JLabel[4];
	
			labels[0]= new JLabel("delete alert");
			labels[1] = new JLabel("clear all");
			labels[2] = new JLabel("Select From");
			labels[3] = new JLabel("reset fields");
			
			
			labels[3].setCursor(UI_Settings.getJlabelCursor());
	
			
			for(int i = 0; i < 4; i++){
				labels[i].setFont(UI_Settings.getComponentsFontPlain());
				labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
			}
			
			
			JComboBox cmbSort = new JComboBox(UI_Settings.getSortByAlertLevel());
			
			cmbSort.setPreferredSize(new Dimension(100, UI_Settings.getComboBoxHeight()));
			cmbSort.setFont(UI_Settings.getComponentInputFontSize());
			cmbSort.setMinimumSize(cmbSort.getPreferredSize());
			//AutoCompletion.enable(cmbSort, 100, UI_Settings.getComboBoxHeight());
	
			/****************************Create the canvas**************************/
			canvas = new JPanel();
			canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
			/**********************Create the components panel***********************/
			detailsPanel = new JPanel();
			detailsPanel.setBackground(Color.WHITE);
			detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()));
			detailsPanel.setLayout(new GridBagLayout());
			
			/***************************************************Add action listeners********************************************/
			labels[3].addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e){
					
			       int action = JOptionPane.showConfirmDialog(AlertsPane.this, UI_Settings.getClearAlerts(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
			       
			       if(action == JOptionPane.OK_OPTION){
			    	   
			    	   cmbSort.setSelectedIndex(0);
			    	   
			    	   viewAllAlertsTable.setRowSelected(0, 0);
			    	   
			       }
				}
			});
			
			/******************************************************Add the Buttons Panel************************************************/
	
			
			JPanel buttonPanel = new JPanel();
			buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
			buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
			buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
			buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
			buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
	
			
			JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
			leftPanel.setBackground(Color.WHITE);
			leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			leftPanel.add(failedMessage);
			
			JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
			rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
			rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			rightPanel.add(labels[3]);
			//rightPanel.add(btnSort);
	
			
			leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
			buttonPanel.add(leftPanel);
			
			rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
			buttonPanel.add(rightPanel);
			
			
			/*************************************************Report Top Edit Button Panel*******************************************************/
			JPanel alertsButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 5));
			alertsButtonPanel.setBackground(UI_Settings.getButtonPanelColor());
			alertsButtonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 30));
			alertsButtonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 30));
			
			alertsButtonPanel.add(chkMatchRequest);
			alertsButtonPanel.add(chkDeleteCustomer);
			
			
			
			
	
			/********************************************************Set the Table Objects Sizes**************************************************/
	
			viewAllAlertsTable.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*18)));
			viewAllAlertsTable.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*18)));
			
			/******************************************************Create the Table Data Panel************************************************/
			centerPanel = new JPanel();
			centerPanel.setBackground(UI_Settings.getButtonPanelColor());
	        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
	        
	        viewAllAlertsTable.setAlignmentY(Component.LEFT_ALIGNMENT);
	        centerPanel.add(viewAllAlertsTable);
	        
	        alertsButtonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
	        centerPanel.add(alertsButtonPanel);
	        
	        pnlSaveInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
	        centerPanel.add(pnlSaveInformation);
	        
			/*********************************************************************************************************************************/
			/////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
			canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 750));
			canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 750));
			JScrollPane scroller = new JScrollPane(canvas);
			//Change the width of the scroll-bar
			scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
			scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
			//Change the visibility of the scroll-bar
			scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			scroller.setBorder(BorderFactory.createEmptyBorder());		
			
			//Add the details section and table sections to the canvas.
			canvas.add(headerMessagePanel, BorderLayout.NORTH);
			canvas.add(centerPanel, BorderLayout.CENTER);
			
			scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());
			
			return scroller;
		}//END viewAlerts

		private void addSouthPanel() {
			//Begin Nested Details Panels (lowest panel on screen)
			pnlSaveInformation = new JPanel();
			pnlSaveInformation.setBackground(Color.WHITE);
			pnlSaveInformation.setLayout(new GridBagLayout());
			pnlSaveInformation.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
			pnlSaveInformation.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
			pnlSaveInformation.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
			
			//Begin Nested Details Panels (lowest panel on screen)
			JPanel pnlSaveRow = new JPanel();
			pnlSaveRow.setBackground(Color.WHITE);
			pnlSaveRow.setLayout(new GridBagLayout());
			pnlSaveRow.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
			pnlSaveRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
			pnlSaveRow.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));

				//Create the far left container for the group details information
				JPanel pnlSaveLeftPane = new JPanel(new GridBagLayout());
				pnlSaveLeftPane.setBackground(Color.WHITE);
				pnlSaveLeftPane.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
				pnlSaveLeftPane.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
				pnlSaveLeftPane.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
				
				//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,0,0,0);
				
					//Add the nested panels to the container panel (information panel)
				
					JPanel panel3 = new JPanel(new GridBagLayout());
					panel3.setBackground(Color.WHITE);
					panel3.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
					panel3.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
					panel3.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
					
					
					JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
					row1.setBackground(Color.WHITE);
					row1.add(new JLabel("Table updated:"));
					row1.add(lblDate);
					
					JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
					row2.setBackground(Color.WHITE);
					row2.add(new JLabel("Connected to: " /*+ controller.getDBname()*/));
					
					JPanel row3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
					row3.setBackground(Color.WHITE);
					row3.add(new JLabel("Connection: Secure"));
					
					gc.gridx = 0;
					gc.gridy = 0;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(5,5,0,5);
				
					panel3.add(row1, gc);
					
					gc.gridx = 0;
					gc.gridy = 1;
					gc.insets = new Insets(0,5,0,5);
				
					panel3.add(row2, gc);
					
					gc.gridx = 0;
					gc.gridy = 2;
					gc.insets = new Insets(0,5,45,5);
				
					panel3.add(row3, gc);
					
					gc.gridx = 0;
					gc.gridy = 0;
					gc.insets = new Insets(0,5,20,5);
				
					pnlSaveLeftPane.add(panel3, gc);
			
			pnlSaveRow.add(pnlSaveLeftPane, gc);
				
			//Create the second panel from the left (comments panel)
			JPanel pnlSaveRight = new JPanel(new GridBagLayout());
			pnlSaveRight.setBackground(Color.WHITE);
			pnlSaveRight.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
			pnlSaveRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
			pnlSaveRight.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));

				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHEAST;
				gc.insets = new Insets(0,0,0,0);
				pnlSaveRight.add(btnDeleteEvent, gc);
				
				pnlSaveRow.add(pnlSaveRight, gc);
			
			pnlSaveInformation.add(pnlSaveRow, gc);
		}

	private void addNorthPanel() {
		JPanel heading = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		JLabel lblHeading = new JLabel("View your error log activity");
		heading.setBackground(Color.WHITE);
		lblHeading.setFont(lblHeading.getFont().deriveFont(16.0f));
		heading.add(lblHeading);
		
		JPanel headingMessage = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		headingMessage.setBackground(Color.WHITE);
		JLabel lblHeadingMessage = new JLabel("All errors in this application our logged and displayed in the table below");
		
		headingMessage.add(lblHeadingMessage);

		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-30));
		detailsPanel.setLayout(new GridBagLayout());
		
		headerMessagePanel = new JPanel(new GridBagLayout());
		setPanelSize(headerMessagePanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 100));
		headerMessagePanel.setBackground(Color.WHITE);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		headerMessagePanel.add(heading,gc);
		
		gc.gridy = 1;
		gc.insets = new Insets(-15,0,0,0);
		headerMessagePanel.add(headingMessage, gc);
	
		gc.gridy = 2;
		gc.insets = new Insets(-30,0,0,0);
		headerMessagePanel.add(detailsPanel, gc);
		
		JPanel firstRow = new JPanel();
		firstRow.setBackground(UI_Settings.getButtonPanelColor());
		firstRow.setLayout(new BoxLayout(firstRow, BoxLayout.X_AXIS));
		
		JPanel fieldcontainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		fieldcontainer.setBackground(Color.WHITE);
		fieldcontainer.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 50));
		fieldcontainer.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 50));
		fieldcontainer.add(new JLabel("You can delete or clear the error logs by selecting the error message and hitting delete or clear from the buttons below the table"));
		
		fieldcontainer.setAlignmentX(Component.LEFT_ALIGNMENT);
		firstRow.add(fieldcontainer);
		
		firstRow.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,30));
		firstRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 30));

		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(17,0,0,0);
		detailsPanel.add(firstRow, gc);
		
	}
	
	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}
}