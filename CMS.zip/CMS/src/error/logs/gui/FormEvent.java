package error.logs.gui;

import java.util.EventObject;

public class FormEvent extends EventObject {

	private int id;
	private String description;
	private String alertDate;
	private int alertLvl;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAlertDate() {
		return alertDate;
	}

	public void setAlertDate(String alertDate) {
		this.alertDate = alertDate;
	}

	public int getAlertLvl() {
		return alertLvl;
	}

	public void setAlertLvl(int alertLvl) {
		this.alertLvl = alertLvl;
	}

	public FormEvent(Object source, int id, String description, String alertDate, int alertLvl) {
		super(source);

		this.id = id;
		this.description = description;
		this.alertDate = alertDate;
		this.alertLvl = alertLvl;
		
	}
}
