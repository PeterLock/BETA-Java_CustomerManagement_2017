package error.logs.gui;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import error.logs.model.ErrorLog;

public class ErrorLogTableModel extends AbstractTableModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<ErrorLog>db;
	
	
	int id;
	String description;
	String alertDate;
	int alertLvl;
	
	
	private String[] colNames = {"Alert ID", "Alert Description", "Alert Date", "Alert Level"};

	@Override
	public int getRowCount() {
		return db.size();
	}

	@Override
	public int getColumnCount() {
		return 4;
	}
	
	@Override
	public String getColumnName(int column) {
		return colNames[column];
	}

	@Override
	public Object getValueAt(int row, int col) {
		
		ErrorLog errorlog = db.get(row);
		
		switch(col){
		case 0: 
			if(errorlog.getId() == 0){
				return null;
			}else{
				return errorlog.getId();
			}
		case 1:
			return errorlog.getDescription();
		case 2:
			return errorlog.getAlertDate();
		case 3:{
			if(errorlog.getAlertLvl() == 0){
				return null;
			}else{
				return errorlog.getAlertLvl();
			}
		}
		
		default:
			return null;
		}
	}

	public void setData(List<ErrorLog> db) {
		this.db = db;
	}
}
