package error.logs.gui;

public interface ErrorLogTableListener {
	public void rowDeleted(int row);
}
