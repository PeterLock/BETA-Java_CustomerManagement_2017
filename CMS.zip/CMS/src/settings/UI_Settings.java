package settings;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.border.Border;

public class UI_Settings {
	
	
	public UI_Settings(){
		
		intialize();
		
	}
	
	
	private void intialize() {
		
	}


	private static int tableRowNumber = 6;
	
	public void UI_CustomSettings(){
	}
	public String getMenuFont(){
		return MENU_FONT_NAME;
	}
	public int getMenuFontSize(){
		return MENU_FONT_SIZE;
	}
	public Color getMenuBarColor(){
		return MENUBAR_COLOR;
	}
	public Color getToolBarColor(){
		return TOOLBAR_COLOR;
	}
	public void setToolBarColor(Color c){
		TOOLBAR_COLOR = c;
	}
	public static int getToolbarHeight() {
		return TOOLBAR_HEIGHT;
	}
	public static int getMinMenuWidth() {
		return MIN_MENU_WIDTH;
	}
	public static int getMinMenuHeight() {
		return MIN_MENU_HEIGHT;
	}
	public static Color getCmsTopTabColor() {
		return CMS_TOP_TAB_COLOR;
	}
	public static Color getCmsBottomTabColor(){
		return CMS_BOTTOM_TAB_COLOR;
	}
	
	public static Color getCmsGray() {
		
		return CMS_TOP_TAB_PANEL_COLOR;
	}	
	/***********Start Font Getters*******/
	public static Font getComponentsFontPlain() {
		return COMPONENTS_FONT_PLAIN;
	}
	/**********End Font Getter***********/
	
	public static Color getBottomTabColor() {
		return CMS_BOTTOM_TAB_COLOR;
	}
	public static Color getCmsTabSecondLvlGrey() {
		return CMS_BOTTOM_TAB_PANEL_COLOR;
	}
	public static Border getBorderpadding() {
		return BORDER_PADDING;
	}
	public static Border getBorderoutline() {
		return BORDER_OUTLINE;
	}	
	public static Color getComponentfillcolor() {
		return COMPONENT_FILL_COLOR;
	}
	public static Color getComponentpanefillcolor() {
		return COMPONENT_PANE_FILL_COLOR;
	}
	public static Color getComponentsFontColorLight() {
		return COMPONENTS_FONT_COLOR_LIGHT;
	}
	public static Color getComponentsFontColorDark() {
		return COMPONENTS_FONT_COLOR_DARK;
	}
	public static Dimension getMinimumScreenSize() {
		return MINIMUM_SCREEN_SIZE;
	}
	public static int getScrollbarWidth() {
		return SCROLLBAR_WIDTH;
	}
	public static Dimension getJbuttonSize() {
		return JBUTTON_SIZE;
	}
	public static Cursor getJlabelCursor() {
		return JLABEL_CURSOR;
	}
	public static Font getComponentsFontBold() {
		return COMPONENTS_FONT_BOLD;
	}
	public static Font getComponentInputFontSize() {
		return COMPONENT_INPUT_FONT_SIZE;
	}
	public static String getResetPrompt() {
		return RESET_PROMPT;
	}
	public static String getResetHeader() {
		return RESET_HEADER;
	}
	
	/***********************************************************APPLICATION CONTROL SETTINGS*************************************************************
	 *****************************************************************************************************************************************************
	 *****************************************************************************************************************************************************
	 *****************************************************************************************************************************************************
	 *****************************************************************************************************************************************************
	 *****************************************************************************************************************************************************
	 *****************************************************************************************************************************************************
	 */
	
	public static int getComboBoxHeight() {
		return COMBO_BOX_HEIGHT;
	}

	public static Color getButtonPanelColor() {
		return BUTTON_PANEL_COLOR;
	}

	public static String getClearAlerts() {
		return CLEAR_ALERTS;
	}

	public static String getClearPossibleClasses() {
		return CLEAR_POSSIBLE_CLASSES;
	}

	public static Color getTableGridLineColor() {
		return TABLE_GRID_LINE_COLOR;
	}

	public static Color getTableHeaderColor() {
		return TABLE_HEADER_COLOR;
	}

	public static Color getTableSelectedRowColor() {
		return TABLE_SELECTED_ROW_COLOR;
	}

	public static int getTableRowHeight() {
		return TABLE_ROW_HEIGHT;
	}

	public static int getTableHeaderHeight() {
		return TABLE_HEADER_HEIGHT;
	}
	public static Font getTableFont() {
		return TABLE_FONT;
	}
	public static int getTableScrollBarWidth() {
		return TABLE_SCROLL_BAR_WIDTH;
	}
	public static Color getTableTitleColor() {
		return TABLE_TITLE_COLOR;
	}
	public static Border getTableTitlePaddingBorder() {
		return TABLE_TITLE_PADDING_BORDER;
	}
	public static Border getTableTitleBorder() {
		return TABLE_TITLE_BORDER;
	}
	public static int getTableTitleHeight() {
		return TABLE_TITLE_HEIGHT;
	}
	public static int getTableTabtextInnerLeftrightPadding() {
		return TABLE_TABTEXT_INNER_LEFTRIGHT_PADDING;
	}
	public static int getTableButtonsPanelHeight() {
		return TABLE_BUTTONS_PANEL_HEIGHT;
	}
	public static String getFooterMessage() {
		return FOOTER_MESSAGE;
	}
	public static Font getFooterFontPlain() {
		return FOOTER_FONT_PLAIN;
	}
	public static String getOk() {
		return OK;
	}
	public static String getHelp() {
		return HELP;
	}
	public static int getReportCommentTextareaHeight() {
		return REPORT_COMMENT_TEXTAREA_HEIGHT;
	}
	public static int getSmallPanelHeight() {
		return SMALL_PANEL_HEIGHT;
	}
	public static int getRegularPanelHeight() {
		return REGULAR_PANEL_HEIGHT;
	}
	public static String[] getGroups() {
		return GROUPS;
	}
	public static String[] getDays() {
		return DAYS;
	}
	public static String[] getBooks() {
		return BOOKS;
	}
	public static String[] getLessonType() {
		return LESSON_TYPE;
	}
	public static String[] getGroupTime() {
		return GROUP_TIME;
	}
	public static String[] getLevels() {
		return LEVELS;
	}
	public static Integer[] getClassSizes() {
		return CLASS_SIZES;
	}
	public static Integer[] getClassSizesAllowed() {
		return CLASS_SIZES_ALLOWED;
	}
	public static String[] getMonths() {
		return MONTHS;
	}
	public static String[] getEmployeeNames() {
		return EMPLOYEE_NAMES;
	}
	public static String[] getTrainingToBeCompletedBy() {
		return TRAINING_TO_BE_COMPLETED_BY;
	}
	public static String[] getOrderBy() {
		return ORDER_BY;
	}
	public static String[] getReportType() {
		return REPORT_TYPE;
	}
	public static String[] getCertificateType() {
		return CERTIFICATE_TYPE;
	}
	public static String[] getStudentAge() {
		return STUDENT_AGE;
	}
	public static String[] getWaitingFrom() {
		return WAITING_FROM;
	}
	public static String[] getStatus() {
		return STATUS;
	}
	public static String[] getBaseLc() {
		return BASE_LC;
	}
	public static int getCanvasSize700() {
		return CANVAS_SIZE_700;
	}
	public static String[] getSortStudentsWaitingBy() {
		return SORT_STUDENTS_WAITING_BY;
	}
	public static String[] getSortByAlertLevel() {
		return SORT_BY_ALERT_LEVEL;
	}
	public static Integer[] getNumberOfKidsClassrooms() {
		return NUMBER_OF_KIDS_CLASSROOMS;
	}
	public static String[] getMaterialEdition() {
		return MATERIAL_EDITION;
	}
	public static String getDlgAddNewStudentToGroupFail() {
		return DLG_ADD_NEW_STUDENT_TO_GROUP_FAIL;
	}
	public static String getDlgAddStudentToGroupSuccess() {
		return DLG_ADD_STUDENT_TO_GROUP_SUCCESS;
	}
	public static String getDlgAddNewGroupSuccess() {
		return DLG_ADD_NEW_GROUP_SUCCESS;
	}
	public static String getDlgAddNewGroupFail() {
		return DLG_ADD_NEW_GROUP_FAIL;
	}
	public static String getDlgAddNewGroupNameTooShortFail() {
		return DLG_ADD_NEW_GROUP_NAME_TOO_SHORT_FAIL;
	}
	public static String getDlgSearchGroupFail() {
		return DLG_SEARCH_GROUP_FAIL;
	}
	public static String getDlgSearchSuccess() {
		return DLG_SEARCH_SUCCESS;
	}
	public static String getDlgSearchStudentFail() {
		return DLG_SEARCH_STUDENT_FAIL;
	}
	public static String getDlgSearchNameTooShortFail() {
		return DLG_SEARCH_NAME_TOO_SHORT_FAIL;
	}
	public static String getDlgStudentSaveFail() {
		return DLG_STUDENT_SAVE_FAIL;
	}
	public static String getDlgAddNewStudentSuccess() {
		return DLG_ADD_NEW_STUDENT_SUCCESS;
	}
	public static String getDlgAddNewCustomerBothNamesTooShortFail() {
		return DLG_ADD_NEW_CUSTOMER_BOTH_NAMES_TOO_SHORT_FAIL;
	}
	public static String getDlgSearchExistingStudentFail() {
		return DLG_SEARCH_EXISTING_STUDENT_FAIL;
	}
	public static String getDlgMovestudentToanotherGroupNoselectionmadeFail() {
		return DLG_MOVESTUDENT_TOANOTHER_GROUP_NOSELECTIONMADE_FAIL;
	}
	public static String getDlgMovestudentToanotherGroupNoselectionmadeMovetoFail() {
		return DLG_MOVESTUDENT_TOANOTHER_GROUP_NOSELECTIONMADE_MOVETO_FAIL;
	}
	public static String getDlgMovestudentToanotherGroupNoselectionmadeMovefromFail() {
		return DLG_MOVESTUDENT_TOANOTHER_GROUP_NOSELECTIONMADE_MOVEFROM_FAIL;
	}
	public static String getDlgMaterialSaveFail() {
		return DLG_MATERIAL_SAVE_FAIL;
	}
	public static String getDlgAddNewCustomerFirstNamesTooShortFail() {
		return DLG_ADD_NEW_CUSTOMER_FIRST_NAMES_TOO_SHORT_FAIL;
	}
	public static String getDlgAddNewCustomerLastNamesTooShortFail() {
		return DLG_ADD_NEW_CUSTOMER_LAST_NAMES_TOO_SHORT_FAIL;
	}
	public static int getScrollBarSpeed() {
		return SCROLL_BAR_SPEED;
	}
	public static Color getComponentErrorColor() {
		return COMPONENT_ERROR_COLOR;
	}
	public static String getFailedMessage() {
		return FAILED_MESSAGE;
	}
	public static int getDetailsButtonPanelHeight() {
		return DETAILS_BUTTON_PANEL_HEIGHT;
	}
	public static Color getFailedMessageColor() {
		return FAILED_MESSAGE_COLOR;
	}
	public static String getDlgMovestudentToanotherGroupSamegroupFail() {
		return DLG_MOVESTUDENT_TOANOTHER_GROUP_SAMEGROUP_FAIL;
	}
	public static String getDlgMovestudentToanotherGroupNogroupselectedFail() {
		return DLG_MOVESTUDENT_TOANOTHER_GROUP_NOGROUPSELECTED_FAIL;
	}
	public static String getDlgAddExistingStudentToGroupNoSelectionFromTableFail() {
		return DLG_ADD_EXISTING_STUDENT_TO_GROUP_NOSELECTION_FROMTABLE_FAIL;
	}
	public static String getDlgAddExistingStudentToGroupNogroupselectedFail() {
		return DLG_ADD_EXISTING_STUDENT_TO_GROUP_NOGROUPSELECTED_FAIL;
	}

	public static String getDlgMaterialNameandPublishernameTooShortfail() {
		return DLG_MATERIAL_NAMEAND_PUBLISHERNAME_TOO_SHORTFAIL;
	}
	public static String getDlgMaterialNameTooshortFail() {
		return DLG_MATERIAL_NAME_TOOSHORT_FAIL;
	}
	public static String getDlgPublisherNameTooshortFail() {
		return DLG_PUBLISHER_NAME_TOOSHORT_FAIL;
	}
	public static String getWarningMessageWebsiteUrlFail() {
		return WARNING_MESSAGE_WEBSITE_URL_FAIL;
	}
	public static Color getWarningMessageWebsiteUrlFailColor() {
		return WARNING_MESSAGE_WEBSITE_URL_FAIL_COLOR;
	}
	public static String getDlgMaterialWebsiteaddressValidFail() {
		return DLG_MATERIAL_WEBSITEADDRESS_VALID_FAIL;
	}
	public static String getManagersName() {
		return managersName;
	}
	public void setManagersName(String managersName) {
		UI_Settings.managersName = managersName;
	}
	public static String getDlgReportsViewallNoselectionFail() {
		return DLG_REPORTS_VIEWALL_NOSELECTION_FAIL;
	}
	public static String getDlgCertificatesSearchStudentFail() {
		return DLG_CERTIFICATES_SEARCH_STUDENT_FAIL;
	}
	public static String getDlgOhSaveFail() {
		return DLG_OH_SAVE_FAIL;
	}
	public static String getDlgOhStartdateAfterEnddate() {
		return DLG_OH_STARTDATE_AFTER_ENDDATE;
	}
	public static Integer[] getDates() {
		return DATES;
	}
	public static String[] getPosition() {
		return POSITION;
	}
	public static Color getComponentInputFontColor() {
		return COMPONENT_INPUT_FONT_COLOR;
	}
	public static int getPopupHeaderHeight() {
		return POPUP_HEADER_HEIGHT;
	}
	public static Color getPopupHeaderColor() {
		return POPUP_HEADER_COLOR;
	}
	public static Font getHeadingFont() {
		return HEADING_FONT;
	}
	/******************************Menu and TabPanes*******************************/
	private static final String MENU_FONT_NAME = "Helvetica";
	private static final int MENU_FONT_SIZE = 12;
	

	
	private static Color MENUBAR_COLOR = new Color(0, 14, 0);
    private static Color TOOLBAR_COLOR = new Color(23,29,44);
    

    private static final int TOOLBAR_HEIGHT = 24;
    
	private final static int MIN_MENU_WIDTH = 200;
	private final static int MIN_MENU_HEIGHT = 25;
	
    private static Color CMS_TOP_TAB_COLOR = new Color(35, 150, 85);
    private static final Color CMS_TOP_TAB_PANEL_COLOR = new Color(59,63,67);

	private static  Color CMS_BOTTOM_TAB_COLOR = new Color(32,137,42);
    private static final Color CMS_BOTTOM_TAB_PANEL_COLOR = new Color(26,32,38);

    
	/***************************************************************Font Settings******************************************************************************/
    /*
     * NOTE: Tab font settings are coded as in-line HTML in order to set the width of each tab.
     * To change the font size and type you will need to change that code in TabPane.java
     */
    private static final Font COMPONENTS_FONT_PLAIN = new Font("Arial", Font.PLAIN, 11);
    private static final Font COMPONENTS_FONT_BOLD = new Font("Arial", Font.BOLD, 11);
    private static final Font COMPONENT_INPUT_FONT_SIZE = new Font("Arial", Font.PLAIN, 11);
    private static final Color COMPONENT_INPUT_FONT_COLOR = new Color(59,63,67);
    
	private static final Color COMPONENTS_FONT_COLOR_DARK = new Color(59,63,67);
	private static final Color COMPONENTS_FONT_COLOR_LIGHT = new Color(22,130,251);
	
	
	/***********************************************************Table Settings*********************************************************************************/
	
	private static final Color TABLE_GRID_LINE_COLOR = new Color(228,228,228);
	private static final Color TABLE_HEADER_COLOR = new Color(180,180,180);
	private static final Color TABLE_SELECTED_ROW_COLOR = new Color(25,125,178);
	//private static final Color TABLE_SELECTED_ROW_COLOR = new Color(128,153,156);
	//private static final Color TABLE_HEADER_COLOR = new Color(59,63,67);


	private static final int TABLE_ROW_HEIGHT = 25;
	private static final int TABLE_HEADER_HEIGHT = 30;
	private static final Font TABLE_FONT = new Font("Arial", Font.PLAIN, 11);
	private static final Font HEADING_FONT = new Font("Arial", Font.PLAIN, 16);

	
	private static final Color TABLE_TITLE_COLOR = new Color(225,225,225);
	private static final Border TABLE_TITLE_PADDING_BORDER = BorderFactory.createEmptyBorder(0, 0, 0, 0);
	private static final Border TABLE_TITLE_BORDER = BorderFactory.createLineBorder(new Color (169,169,169));
	private static final int TABLE_TITLE_HEIGHT = 24;
	
	private static final int TABLE_TABTEXT_INNER_LEFTRIGHT_PADDING = 50;
	private static final int TABLE_BUTTONS_PANEL_HEIGHT = 20;
	
	/*******************************************************************Footer Message*************************************************************************/
	@SuppressWarnings("unused")
	private static final String SM_SYMBOL = "\u2120";
	private static final String FOOTER_MESSAGE = "All rights reserved ";
    private static final Font FOOTER_FONT_PLAIN = new Font("Arial", Font.PLAIN, 10);
	/**************************************************************Component Settings**************************************************************************/

	//Padding to go around the components
	private static final Border BORDER_PADDING = BorderFactory.createEmptyBorder(0,-5,0,-6);
	private static final Border BORDER_OUTLINE = BorderFactory.createLineBorder(Color.LIGHT_GRAY);
	private static final Color COMPONENT_FILL_COLOR = Color.CYAN;
	private static final Color COMPONENT_PANE_FILL_COLOR = Color.WHITE;
	
	private static final int SCROLLBAR_WIDTH = 12;
	private static final int TABLE_SCROLL_BAR_WIDTH = 10;
	private static final int SCROLL_BAR_SPEED = 16;
	
	private static final Dimension JBUTTON_SIZE = new Dimension(110,30);
	private static final Color BUTTON_PANEL_COLOR = Color.WHITE;
	
	private static final int COMBO_BOX_HEIGHT = 27;
	
	private static Cursor JLABEL_CURSOR = new Cursor(Cursor.HAND_CURSOR);
	
	
	private static final int REPORT_COMMENT_TEXTAREA_HEIGHT = 80;
	
	
	
	///Error Component background color////
	
	private static final Color COMPONENT_ERROR_COLOR = new Color(249,249,249);
	
	/////////////////////////////////////////////////////////////ComboBox data fields//////////////////////////////////////////////////////////////////////////
	
	private static final String[] GROUPS = new String[]{"", "Koala", "Kangaroo", "Lanchester", "London", "Melbourne", "Oklahoma", "Seattle", "Portsmith", "Duffy"};
	private static final String[] DAYS = new String[]{"","Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
	private static final String[] BOOKS = new String[]{"", "Book 1", "Book 2", "Book 3", "Book 4", "Book 5", "Book 6", "Book 7"};
	
	
	private static final String[] LESSON_TYPE = new String[]{"", "Private", "Semi-Private", "Charter" };
	private static final String[] GROUP_TIME = new String[]{"","Morning", "Before Noon", "Afternoon", "Evening"};
	
	
	private static final String[] LEVELS = new String[]{"", "NBE-1","NBE-2","NBE-3","NBE-4","NBE-5","NBE-6","NBE-7"};
	private static final Integer[] CLASS_SIZES = new Integer[]{null, 0,1,2,3,4,5,6};
	private static final Integer[] CLASS_SIZES_ALLOWED = new Integer[]{null, 1,2,3,4,5,6};
	private static final Integer[] NUMBER_OF_KIDS_CLASSROOMS = new Integer[]{null, 1,2,3,4,5};
	
	
	private static final String[] MONTHS = new String[]{"", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
	
	private static final Integer[] DATES = new Integer[]{null, 1,2,3,4,5,6,7,8,9,10,
														11,12,13,14,15,16,17,18,19,20,
														21,22,23,24,25,26,27,28,29,30,
														31};
	
	private static final String[] POSITION = new String[] {"", "Counselor", "Langauge Instructor", "Branch Manager/Japanese", "Branch Manager/Non-Japanese", "Area Manager"};
	
	private static final String[] EMPLOYEE_NAMES = new String[]{"", "Kate Smith", "Kate Hops", "Candy Chow", "Leah Fitx", "Lin Who", "Chi LaAx", "Amy Chang" };
	private static final String[] TRAINING_TO_BE_COMPLETED_BY = new String[]{"", "the end of the week", "the end of next week", "the end of the month"};
	private static final String[] ORDER_BY = new String[]{"", "Sender", "Request Made To", "Request Made By"};
	private static final String[] SORT_STUDENTS_WAITING_BY = new String[]{"", "Name", "Age", "Preferred Day 1", "Preferred Day 2", "Possible Group", "Group Day", "Group Time" };
	private static final String[] SORT_BY_ALERT_LEVEL = new String[]{"", "Alert Date", "Alert Level" };

	
	private static final String[] REPORT_TYPE = new String[]{"", "Progress", "Final"};
	private static final String[] CERTIFICATE_TYPE = new String[]{"", "Achievement", "Completion", "Graduation"};

	private static final String[] WAITING_FROM = new String[]{"","1 week", "2 weeks", "3 weeks", "1 month"};

	private static final String[] STUDENT_AGE = new String[]{"", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15","16","16 ~"};
	private static final String[] STATUS = new String[]{"","Unavailable", "Available"};
	private static final String[] BASE_LC = new String[]{"", "Wellington", "Ascot", "Denver", "Cambridge"};
	
	private static final String[] MATERIAL_EDITION = new String[]{"","1st Edition", "2nd Edition", "3rd Edition", "4th Edition"};
	

	/***********************************************************Screen and panel sizes*************************************************************************/
	private static final int MINIMUM_SCREEN_WIDTH = 1020;
	private static final int SMALL_PANEL_HEIGHT = 90;
	private static final int REGULAR_PANEL_HEIGHT = 150;
	private static final int DETAILS_BUTTON_PANEL_HEIGHT = 32;
	private static final Dimension MINIMUM_SCREEN_SIZE = new Dimension(MINIMUM_SCREEN_WIDTH, java.awt.Toolkit.getDefaultToolkit().getScreenSize().height);
	/********************************************************Dialog Prompts, footer text***********************************************************************/
	
	private static final String RESET_PROMPT = "Welcome User. Resetting the table will clear all rows of data.\nDo you want to continue?";
	private static final String RESET_HEADER = "";
	private static final String CLEAR_ALERTS = "Welcome User. Are you sure you want to clear the alerts table?";
	private static final String CLEAR_POSSIBLE_CLASSES = "Welcome User. Are you sure you want to clear the possible classes table?";
	
	
	/********************************************************Pop Up Panel Specifications***********************************************************************/
	private static final int POPUP_HEADER_HEIGHT = 27;
	private static final Color POPUP_HEADER_COLOR = new Color(59,63,67);
	
	
	///////////////////Customer Tab////////////////
	private static final String DLG_ADD_NEW_CUSTOMER_BOTH_NAMES_TOO_SHORT_FAIL =
			
			"<html><b>Save was not successful as both the \"first name\" and \"last name\" were too short.</b></html>"
					+ "\n\nWhen adding a new customer the first and last name need to be more than 1 letter long."
					+ "\nIf you want to add a new customer you will need to add longer names.";
	
	private static final String DLG_ADD_NEW_CUSTOMER_FIRST_NAMES_TOO_SHORT_FAIL =
			
			"<html><b>Save was not successful as the first name was too short.</b></html>"
					+ "\n\nThe first name needs to be more than 1 character long. If you want"
					+ "\nto add a new customer you will need to add a longer name.";
	
	
	private static final String DLG_ADD_NEW_CUSTOMER_LAST_NAMES_TOO_SHORT_FAIL =
			
			"<html><b>Save was not successful as the last name was too short.</b></html>"
					+ "\n\nThe last name needs to be more than 1 character long. If you want"
					+ "\nto add a new customer you will need to add a longer name.";
	

	
	private static final String DLG_SEARCH_STUDENT_FAIL =
			
			"<html><b>\"Search\" was not successful as required information was not given.</b></html>"
				+ "\n\nTo search for a customer you need to select at least 1 search option from"
				+ "\nthe dropdown boxes above.";
	
	private static final String DLG_SEARCH_EXISTING_STUDENT_FAIL =
			
			"<html><b>\"Search\" was not successful as required information was not given.</b></html>"
				+ "\n\nTo search for an existing customer you need to select at least 1 search option"
				+ "\nfrom the dropdown boxes above.";
	
	private static final String DLG_STUDENT_SAVE_FAIL =
			
			"<html><b>\"Save\" was not successful as required information was not given.</b></html>" 
					+ "\n\nWhen adding a new customer all of the fields need to be completed. In this case that did not"
					+ "\nhappen. If you want to save a new customer make sure you have entered everything correctly.";
	
	private static final String DLG_SEARCH_SUCCESS = "Search criteria contained the following: ";
	
	private static final String DLG_SEARCH_NAME_TOO_SHORT_FAIL =
			
			"<html><b>\"Search\" was not sucessful as the name was too short.</b></html>"
				+ "\n\nWhen searching for a customer the name needs to be more than 2 characters in length. In this"
				+ "\ncase it was not. If you want to search for a customer you need to enter more than 2 characters.";
	
	/////////////////////////////////////////////////////////////Group Tab///////////////////////////////////////////////////////////////
	
	private static final String DLG_ADD_NEW_GROUP_FAIL = 
			
			"<html><b>\"Add New Group\" was not successful as required information was not given.</b></html>" 
					+ "\n\nWhen adding a new group all of the fields need to be completed. In this case that did"
					+ "\nnot happen. If you want to add a new group make sure you have entered everything \ncorrectly.";
	
	
	private static final String DLG_ADD_NEW_STUDENT_TO_GROUP_FAIL = 
			
			"<html><b>\"Add New Student To Group\" was not successful as required information was not given.</b></html>" 
					+ "\n\nWhen adding a new customer to a group all of the fields need to be completed. In this case that"
					+ "\ndid not happen. If you want to add a new customer make sure you have entered everything \ncorrectly.";
	
	
	private static final String DLG_ADD_EXISTING_STUDENT_TO_GROUP_NOSELECTION_FROMTABLE_FAIL =
			
			"<html><b>\"Add Existing Student To Group\" was not successful as required information was not given.</b></html>"
					+ "\n\nWhen adding an existing customer to a group you need to first select a customer from the table."
					+ "\nIn this case that did not happen. If you want to add an existing customer to a group first select"
					+ "\nthe customers name from the table.";
	
	private static final String DLG_ADD_EXISTING_STUDENT_TO_GROUP_NOGROUPSELECTED_FAIL =
			
			"<html><b>\"Add Existing Student to Group\" was not successful.</b></html>"
					+ "\nThe Group Name has not been selected.";
	
	
	private static final String DLG_SEARCH_GROUP_FAIL =

			"<html><b>\"Search\" was not successful as required information was not given.</b></html>"
					+ "\n\nTo search for a group you need to select at least 1 search option from"
					+ "\nthe dropdown boxes above.";
	
	private static final String DLG_ADD_NEW_GROUP_NAME_TOO_SHORT_FAIL =
			
			"<html><b>\"Add New Group\" was not successful as the Group Name was too short.</b></html>"
				+ "\n\nWhen adding new groups the Group Name needs to be 5 or more characters long. In this case"
				+ "\nit was not. If you want to add a new group you will need to make the group name longer.";
	
	private static final String DLG_MOVESTUDENT_TOANOTHER_GROUP_NOSELECTIONMADE_FAIL =
			
			"<html><b>\"Move Student to Another Group\" was not successful as the required information was not given.</b></html>"
					+ "\n\nTo move a student to another group you need to choose the group the student is currently in [Move from]"
					+ "\nand the group you want to move the student into [Move to].";
	
	private static final String DLG_MOVESTUDENT_TOANOTHER_GROUP_NOSELECTIONMADE_MOVETO_FAIL =
			
			"<html><b>\"Move Student to Another Group\" was not successful.</b></html>"
					+ "\nThe [Move to] field has not been selected.";
	
	private static final String DLG_MOVESTUDENT_TOANOTHER_GROUP_NOSELECTIONMADE_MOVEFROM_FAIL =
			
			"<html><b>\"Move Student to Another Group\" was not successful.</b></html>"
					+ "\nThe [Move from] field has not been selected.";
	
	private static final String DLG_MOVESTUDENT_TOANOTHER_GROUP_SAMEGROUP_FAIL =
			
			"<html><b>\"Move Student to Another Group\" was not successful.</b></html>"
			+ "\nThe \'Move from\' and \'Move to\' Group Names need to be different.";
	
	private static final String DLG_MOVESTUDENT_TOANOTHER_GROUP_NOGROUPSELECTED_FAIL =
			
			"<html><b>\"Move Student to Another Group\" was not successful.</b></html>"
			+ "\nYou need to select which group to add the student to.";
	
	
	private static final String DLG_ADD_STUDENT_TO_GROUP_SUCCESS = "<html><b>\"Add Student to Group\" was successful.<b></html>\n";

	private static final String DLG_ADD_NEW_GROUP_SUCCESS = "<html><b>\"Add New Group\" was successful.<b></html>\n";
	
	private static final String DLG_ADD_NEW_STUDENT_SUCCESS = "<html><b>\"Save\" was successful.<b></html>\n";
	
	//////////////////////////////////////////////////////////////Material Tab///////////////////////////////////////////////////////////////////////////
	private static final String DLG_MATERIAL_NAME_TOOSHORT_FAIL =
			
			"<html><b>\"Save\" was not successful as the Material Name is too short.</b></html>"
					+ "\n\nWhen adding new materials the Material Name needs to be 5 or more characters long. In this case"
					+ "\nit was not. If you want to add a new material you will need to make the material name longer.";
	
	private static final String DLG_PUBLISHER_NAME_TOOSHORT_FAIL =
			
			"<html><b>\"Save\" was not successful as the Publisher Name is too short.</b></html>"
					+ "\n\nWhen adding new materials the Publisher Name needs to be 5 or more characters long. In this case"
					+ "\nit was not. If you want to add a new material you will need to make the publishers name longer.";
	
	private static final String DLG_MATERIAL_SAVE_FAIL =
			
			"<html><b>\"Save\" was not successful as required information was not given.</b></html>" 
					+ "\n\nWhen adding a new material all of the fields need to be completed. In this case that did not"
					+ "\nhappen. If you want to save a new material make sure you have entered everything correctly.";
	
	
	private static final String DLG_MATERIAL_NAMEAND_PUBLISHERNAME_TOO_SHORTFAIL =
			
			"<html><b>Save was not successful as both the \"material name\" and \"publisher name\" were too short.</b></html>"
					+ "\n\nWhen adding a new customer the material and publisher names need to be more than 5 letters long."
					+ "\nIf you want to add a new material you will need to add longer names.";
	
	
	private static final String DLG_MATERIAL_WEBSITEADDRESS_VALID_FAIL =
			
			"<html><b>The url given for the web-site address has failed a validity test.</b></html>"
				+ "\n\nThe address must begin with http:// For Example: \"http://www.myaddress.com\" and \"http://myaddress.com\" are both"
				+ "\nvalid website addresses. In this case that did not happen. You will need to check the website address and try again.";
	
	//////////////////////////////////////////////////////////////Reports Tab///////////////////////////////////////////////////////////////////////////

	private static final String DLG_REPORTS_VIEWALL_NOSELECTION_FAIL =
			
			"<html><b>\"Search\" was not successful as required information was not given.</b></html>"
					+ "\n\nTo search for a report you need to select at least 1 search option from"
					+ "\nthe dropdown boxes above.";	
	
	
	///////////////////////////////////////////////////////////Certificates Tab////////////////////////////////////////////////////////////////////////

	private static final String DLG_CERTIFICATES_SEARCH_STUDENT_FAIL =
			
			"<html><b>\"Search\" was not successful as required information was not given.</b></html>"
					+ "\n\nTo search for a customer you need to select at least 1 search option from"
					+ "\nthe dropdown boxes above.";
	
	
	////////////////////////////////////////////////////////////Open House Tab/////////////////////////////////////////////////////////////////////////
	
	private static final String DLG_OH_SAVE_FAIL =
			
			"<html><b>\"Save\" was not successful as required information was not given.</b></html>" 
					+ "\n\nWhen adding a new open house all of the fields need to be completed. In this case that did not"
					+ "\nhappen. If you want to save a new open house make sure you have entered everything correctly.";
	
	private static final String DLG_OH_STARTDATE_AFTER_ENDDATE =
			
			"<html><b>Date Mismatch</b></html>" 
					+ "\n\nThe Open House start date must comes before the end date. In this case that did not happen. "
					+ "\nIf you want to add a new open house you will need to enter the dates correctly and try again.";
		
	
	
	
	
	private static final String FAILED_MESSAGE = "Oops, something hasn't been entered correctly";
	private static final Color FAILED_MESSAGE_COLOR = Color.RED;

	private static final String WARNING_MESSAGE_WEBSITE_URL_FAIL = "Warning, the website address entered has failed the validation test";
	private static final Color WARNING_MESSAGE_WEBSITE_URL_FAIL_COLOR = new Color(32, 137, 42 );
	/********************************************************Password Settings***********************************************************************/
	private static final String OK = "ok";
	private static final String HELP = "help";
	/******************************************************************************************************************************/
	private static final int CANVAS_SIZE_700 = 700;
	
	/******************************************************************************************************************************/
	/******************************************************************************************************************************/
	/******************************************************************************************************************************/
	/******************************************************************************************************************************/
	
	private static String managersName = "David Cooper";

	public static void setNumberOfRowsPerTable(int x) {
		tableRowNumber = x;		
	}
	
	public static int getNumberOfRowsPerTable() {
		return tableRowNumber;		
	}


	public static String[] getGroupDaysList() {
		String[] days = new String[]{"Mon", "Tue", "Wed", "Thu","Fri", "Sat", "Sun"};
		return days;
	}


	public static String[] getGroupTimesList() {
		String[] time = new String[] {"Morning", "Before Noon", "Afternoon", "Evening"};
		return time;
	}
	
}
