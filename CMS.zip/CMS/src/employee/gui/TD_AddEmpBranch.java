package employee.gui;

import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.table.AbstractTableModel;

public class TD_AddEmpBranch extends AbstractTableModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public final static int INSTRUCTOR_NAME = 0;
	public final static int INSTRUCTOR_STATUS = 1;
	public final static int BASE_LC = 2;
	public final static int MI_NAME = 3;
	public final static int LC_EMAIL = 4;
	public final static int LC_EXTENSION_NUMBER = 5;

	
	
	public Object[][]values =
		{
				{"Tom Jones", "Active", "Wellington", "David Cooper", "d_cooper@LC.email.com", new Integer(123)},
				{"", "", "", "", "", ""},
		};
	
	public final static String[] COLUMN_NAMES = {"Instructor Name", "Instructor Status",
			"Base LC", "MI Name", "LC e-mail", "LC Extension Number"};


	
	public String getColumnName(int column){
		return COLUMN_NAMES[column];
	}
	
	@Override
	public int getRowCount() {
		return values.length;
	}
	
	
	@Override
	public int getColumnCount() {
		return values[0].length;
	}
	
	
	@Override
	public Object getValueAt(int row, int column) {
		return values[row][column];
	}
	public ArrayList<Integer> getCOLUMN_PERCENTAGES() {
		return COLUMN_PERCENTAGES;
	}

	public static void setCOLUMN_PERCENTAGES(ArrayList<Integer> cOLUMN_PERCENTAGES) {
		COLUMN_PERCENTAGES = cOLUMN_PERCENTAGES;
	}
	private static ArrayList<Integer> COLUMN_PERCENTAGES = new ArrayList<>(Arrays.asList(15, 15, 10, 15, 20, 15));

}
