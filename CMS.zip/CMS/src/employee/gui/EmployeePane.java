package employee.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ColorUIResource;

import control.build.TableTemplate;
import settings.UI_Settings;
import utilities.AutoCompletion;
import utilities.TextPrompt;
import utilities.UniqueIDGenerator;

public class EmployeePane extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static JTabbedPane pane = new JTabbedPane();
	UniqueIDGenerator idGenerator = new UniqueIDGenerator();
	TextPrompt textPrompt;
	
	/**********************************************************************************************************************************/

	////////////Add Employee Tab
	TD_AddEmployee addEmployeeTableData = new TD_AddEmployee();
	TableTemplate addEmployeeTable = new TableTemplate(addEmployeeTableData, addEmployeeTableData.getCOLUMN_PERCENTAGES(), "");

	TD_AddEmpBranch addBranchDetailsTableData = new TD_AddEmpBranch();
	TableTemplate addEmployeeBranchDetailsTable = new TableTemplate(addBranchDetailsTableData, addBranchDetailsTableData.getCOLUMN_PERCENTAGES(), "Instructor LC details");
	
	///////////View All Tab
	TD_EmployeeDetails viewEmployeeDetailsTableData = new TD_EmployeeDetails();
	TableTemplate viewEmployeeDetails = new TableTemplate(viewEmployeeDetailsTableData, viewEmployeeDetailsTableData.getCOLUMN_PERCENTAGES(), "");
	
	TD_BranchDetails viewEmployeeBranchDetailsTableData = new TD_BranchDetails();
	TableTemplate viewEmployeeBranchDetailsTable = new TableTemplate(viewEmployeeBranchDetailsTableData, viewEmployeeBranchDetailsTableData.getCOLUMN_PERCENTAGES(), "Instructor LC Details");

	/**********************************************************************************************************************************/

	public EmployeePane() {
        initializeUI();
    }

    private void initializeUI() {
    	
      	UIManager.put("Label.font", UI_Settings.getComponentsFontPlain());
    	UIManager.put("Label.foreground", UI_Settings.getComponentsFontColorDark());
    	
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(1000, 100));

        //OK
        UIManager.put("TabbedPane.selected", new ColorUIResource(UI_Settings.getBottomTabColor()));
        UIManager.put("TabbedPane.unselectedTabBackground", UI_Settings.getCmsGray());       
        
        pane.setForeground(Color.WHITE);
        pane.setFocusable(false);
        pane.setBorder(new EmptyBorder(0, 0, 0, 0));


        //OK
        UIManager.getDefaults().put("TabbedPane.tabAreaInsets", new Insets(0,0,0,0));
        UIManager.put("TabbedPane.contentBorderInsets", new Insets(0, 0, 0, 0)); 
        

        //Sets the JPanel container to black
        setBackground(UI_Settings.getCmsTabSecondLvlGrey());
        pane.addTab("<html><body><table width='60' style='font-size:11'><td style='text-align:center'>View All</td></table></body></html>", viewEmployees());		//0
        pane.addTab("<html><body><table width='100' style='font-size:11'><td style='text-align:center'>Add Employee</td></table></body></html>", addEmployee());		//1

        //Set the text color for each tab
        pane.setForeground(Color.WHITE);

        pane.setBackgroundAt(0, UI_Settings.getCmsGray());	//0
        pane.setBackgroundAt(1, UI_Settings.getCmsGray());	//1
    
        changeUI(UI_Settings.getBottomTabColor());

    }

    public void changeUI( Color bottomTabColor) {
        pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
            @Override protected int calculateTabHeight(
              int tabPlacement, int tabIndex, int fontHeight) {
            	
    	       highlight = UI_Settings.getCmsTabSecondLvlGrey();
    	       lightHighlight = UI_Settings.getCmsTabSecondLvlGrey();
    	       shadow = UI_Settings.getCmsTabSecondLvlGrey();
    	       darkShadow = UI_Settings.getCmsTabSecondLvlGrey();
    	       focus = UI_Settings.getCmsTabSecondLvlGrey();
            	
              return 27;
            }
            
            
            @Override protected void paintTab(
              Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
              Rectangle iconRect, Rectangle textRect) {
        
               rects[tabIndex].height = 25 + 1;
               rects[tabIndex].y = 20 - rects[tabIndex].height + 7;
              
              super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
            }
          });
        
        //Add the tab to the canvas
        this.add(pane, BorderLayout.CENTER);		
	}

	public static void showFrame() {
        JPanel panel = new EmployeePane();
        panel.setOpaque(true);

        JFrame frame = new JFrame("CMS Test Screen");
        JFrame.setDefaultLookAndFeelDecorated(false);
        frame.setPreferredSize(UI_Settings.getMinimumScreenSize());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(panel);
        frame.pack();
        frame.setVisible(true);
    }
    
    public void changeTheme(Color c) {
      UIManager.put("TabbedPane.selected",new ColorUIResource(c));
		 
      pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
          @Override protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
            return 27;
          }
      });
      
	pane.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
	    @Override protected int calculateTabHeight(
	      int tabPlacement, int tabIndex, int fontHeight) {
	    	
	       highlight = UI_Settings.getCmsTabSecondLvlGrey();
	       lightHighlight = UI_Settings.getCmsTabSecondLvlGrey();
	       shadow = UI_Settings.getCmsTabSecondLvlGrey();
	       darkShadow = UI_Settings.getCmsTabSecondLvlGrey();
	       focus = UI_Settings.getCmsTabSecondLvlGrey();
	    	
	      return 27;
	    }
	    
	    
	    @Override protected void paintTab(
	      Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
	      Rectangle iconRect, Rectangle textRect) {
	
	       rects[tabIndex].height = 25 + 1;
	       rects[tabIndex].y = 20 - rects[tabIndex].height + 7;
	      
	      super.paintTab(g, tabPlacement, rects, tabIndex, iconRect, textRect);
	    }
	  });
	}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                EmployeePane.showFrame();
            }
        });
    }
    /**
     * Method name: viewEmployees()
     * ====================================================================================================================================
     * This method creates the viewEmployees pane and returns it to the calling method.
     * Precondition: Must be invoked.
     * Postcondition: Returns the viewEmployees pane.
     * 
     * @return Returns the viewEmployees details pane to the calling method.
     */
	public Component viewEmployees()
	{
		JPanel canvas;
		JPanel detailsPanel;
		JPanel centerPanel;
		JPanel alertsButtonPanel;
		JButton btnSave;
		
		JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());

		failedMessage.setVisible(true);

		JLabel labels[] = new JLabel[4];
		
		labels[0] = new JLabel("reset fields");
		labels[1] = new JLabel("generate");
		labels[2] = new JLabel("edit");
		labels[3] = new JLabel("print");
		
		for(int i = 0; i < 4; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
		}

		/*********************************************************Create Combo Boxes*********************************************************/
		JComboBox cmbBranch = new JComboBox(UI_Settings.getBaseLc());
		
		cmbBranch.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbBranch.setFont(UI_Settings.getComponentInputFontSize());
		cmbBranch.setMinimumSize(cmbBranch.getPreferredSize());
		//AutoCompletion.enable(cmbBranch, 150, UI_Settings.getComboBoxHeight());
		
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		
		labels[0].setCursor(UI_Settings.getJlabelCursor());
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
		       int action = JOptionPane.showConfirmDialog(EmployeePane.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		       
		       if(action == JOptionPane.OK_OPTION){
		       }
			}
		});
		/*****************************************************************************************************************************/
		btnSave = new JButton("Save");
		btnSave.setPreferredSize(UI_Settings.getJbuttonSize());
		btnSave.setFont(UI_Settings.getComponentInputFontSize());
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/**********************Create the components panel***********************/
		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()));
		detailsPanel.setLayout(new GridBagLayout());
		
		GridBagConstraints gc = new GridBagConstraints();
		JPanel firstRow = new JPanel();
		firstRow.setBackground(UI_Settings.getButtonPanelColor());
		firstRow.setLayout(new BoxLayout(firstRow, BoxLayout.X_AXIS));
		
		JPanel container = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 5));
		container.setBackground(UI_Settings.getButtonPanelColor());
		container.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 50));
		container.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 50));
		container.add(new JLabel("Branch Office"));//Branch office label
		container.add(cmbBranch);//Branch combo
		
		container.setAlignmentX(Component.LEFT_ALIGNMENT);
		firstRow.add(container);
		
		firstRow.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,30));
		firstRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 30));

		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(15,0,0,0);
		detailsPanel.add(firstRow, gc);

		/******************************************************Add the Buttons Panel************************************************/

		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(labels[0]);
		//rightPanel.add(btnSave);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		/*************************************************Report Top Edit Button Panel*******************************************************/
		alertsButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 5));
		alertsButtonPanel.setBackground(UI_Settings.getButtonPanelColor());
		alertsButtonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 30));
		alertsButtonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 30));
		
		alertsButtonPanel.add(labels[2]);
		alertsButtonPanel.add(labels[3]);

		/********************************************************Set the Table Objects Sizes**************************************************/

		viewEmployeeDetails.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*10)));
		viewEmployeeDetails.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*10)));
		
		viewEmployeeBranchDetailsTable.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		viewEmployeeBranchDetailsTable.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*6)));
		
		
		/******************************************************Create the Table Data Panel************************************************/
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(buttonPanel);
        
        viewEmployeeDetails.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(viewEmployeeDetails);
        
        viewEmployeeBranchDetailsTable.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(viewEmployeeBranchDetailsTable);
        
        alertsButtonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(alertsButtonPanel);
        
		/*********************************************************************************************************************************/

		
		//Add the details section and table sections to the canvas.
		canvas.add(detailsPanel, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
		
		/////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 750));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 750));

		
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(canvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());

		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());

		return scroller;
	}//END viewEmployee
	
	   /**
     * Method name: addEmployee()
     * ====================================================================================================================================
     * This method creates the addEmployee pane and returns it to the calling method.
     * Precondition: Must be invoked.
     * Postcondition: Returns the addEmployee pane.
     * 
     * @return Returns the addEmployee details pane to the calling method.
     */
	public Component addEmployee()
	{
		JPanel canvas;
		JPanel detailsPanel;
		JPanel centerPanel;
		JButton btnSave;

		JTextField txtFirstName;
		JTextField txtLastName;
		JTextField txtEmpID;
		JTextField txtManagerName;
		JCheckBox chkReadExplorer;
		JCheckBox chkTimezones;
		JCheckBox chkEikon;
		JCheckBox chkToeic;
		JCheckBox chkMimi;
		JCheckBox chkBGA;
		JCheckBox chkClock;
		JCheckBox chkPhonics;

		/***********************Initialize Fields******************************/
		JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());

		failedMessage.setVisible(true);
		
		JLabel labels[] = new JLabel[3];
		
		labels[0] = new JLabel("reset fields");
		labels[1] = new JLabel("edit");
		labels[2] = new JLabel("delete");

		for(int i = 0; i < 3; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		
		JComboBox cmbScheduleStatus = new JComboBox(UI_Settings.getStatus());
		JComboBox cmbBaseLC = new JComboBox(UI_Settings.getBaseLc());
		/****************************************************Create ComboBoxes**************************************************************/

		cmbBaseLC.setFont(UI_Settings.getComponentInputFontSize());
		cmbBaseLC.setPreferredSize(new Dimension(132, UI_Settings.getComboBoxHeight()));
		cmbBaseLC.setMinimumSize(cmbBaseLC.getPreferredSize());
		//AutoCompletion.enable(cmbBaseLC, 132, UI_Settings.getComboBoxHeight());
		/**************************************************Create TextFields************************************************************/
		txtFirstName = new JTextField(10);
		txtFirstName.setMinimumSize(txtFirstName.getPreferredSize());
		
		txtLastName = new JTextField(10);
		txtLastName.setMinimumSize(txtLastName.getPreferredSize());

		txtEmpID = new JTextField(8);
		txtEmpID.setMinimumSize(txtEmpID.getPreferredSize());
		txtEmpID.setEditable(false);

		txtManagerName = new JTextField(10);
		txtManagerName.setMinimumSize(txtManagerName.getPreferredSize());
		txtManagerName.setEditable(true);
		
		textPrompt = new TextPrompt("-", txtEmpID);
		txtEmpID.setHorizontalAlignment(JTextField.CENTER);
		/**************************************************Create CheckBoxes************************************************************/
		chkReadExplorer = new JCheckBox("Reading Explorer");
		chkReadExplorer.setFont(UI_Settings.getComponentsFontPlain());
		chkReadExplorer.setForeground(UI_Settings.getComponentsFontColorLight());
		
		chkTimezones = new JCheckBox("Timezones");
		chkTimezones.setFont(UI_Settings.getComponentsFontPlain());
		chkTimezones.setForeground(UI_Settings.getComponentsFontColorLight());
		
		chkEikon = new JCheckBox("Eikon");
		chkEikon.setFont(UI_Settings.getComponentsFontPlain());
		chkEikon.setForeground(UI_Settings.getComponentsFontColorLight());
		
		chkToeic = new JCheckBox("TOEIC");
		chkToeic.setFont(UI_Settings.getComponentsFontPlain());
		chkToeic.setForeground(UI_Settings.getComponentsFontColorLight());
		
		chkMimi = new JCheckBox("Mimi and Me");
		chkMimi.setFont(UI_Settings.getComponentsFontPlain());
		chkMimi.setForeground(UI_Settings.getComponentsFontColorLight());
		
		chkBGA = new JCheckBox("BGA");
		chkBGA.setFont(UI_Settings.getComponentsFontPlain());
		chkBGA.setForeground(UI_Settings.getComponentsFontColorLight());
		
		chkClock = new JCheckBox("Clockwise");
		chkClock.setFont(UI_Settings.getComponentsFontPlain());
		chkClock.setForeground(UI_Settings.getComponentsFontColorLight());
		
		chkPhonics = new JCheckBox("Phonics Jump");
		chkPhonics.setFont(UI_Settings.getComponentsFontPlain());
		chkPhonics.setForeground(UI_Settings.getComponentsFontColorLight());
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		
		labels[0].setCursor(UI_Settings.getJlabelCursor());
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
		       int action = JOptionPane.showConfirmDialog(EmployeePane.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		       
		       if(action == JOptionPane.OK_OPTION){
		   		txtFirstName.setText("");
				txtLastName.setText("");
				txtEmpID.setText("");
				txtManagerName.setText("");
				cmbBaseLC.setSelectedIndex(0);
				cmbScheduleStatus.setSelectedIndex(0);
				chkReadExplorer.setSelected(false);
				chkTimezones.setSelected(false);
				chkEikon.setSelected(false);
				chkToeic.setSelected(false);
				chkMimi.setSelected(false);
				chkBGA.setSelected(false);
				chkClock.setSelected(false);
				chkPhonics.setSelected(false);
				
		       }
			}
		});
		/*****************************************************************************************************************************/
		btnSave = new JButton("Save");
		btnSave.setPreferredSize(UI_Settings.getJbuttonSize());
		btnSave.setFont(UI_Settings.getComponentInputFontSize());
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/**********************Create the components panel***********************/
		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()));
		detailsPanel.setLayout(new GridBagLayout());
		
		GridBagConstraints gc = new GridBagConstraints();
		//////////////////////////////////////////Begin Column 1 ///////////////////////////////////////////
		gc.gridx = 0;
		gc.gridy = 3;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(25,26,0,10);
		detailsPanel.add(new JLabel("Employee Name"), gc); //Employee name label
		
		gc.gridx = 0;
		gc.gridy = 4;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.NONE;
		gc.insets = new Insets(15,26,0,10);
		detailsPanel.add(new JLabel("Can Teach"), gc); //Can Teach label
		
		//////////////////////////////////////////Begin Column 2 ///////////////////////////////////////////
		gc.gridx = 1;
		gc.gridy = 2;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(24,-14,-24,18);
		detailsPanel.add(new JLabel("First Name"), gc); //FirstName label

		gc.gridx = 1;
		gc.gridy = 3;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.insets = new Insets(22,-17,-22,17);
		detailsPanel.add(txtFirstName, gc); //FirstName TextField
		
		gc.gridx = 1;
		gc.gridy = 4;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.insets = new Insets(15,-17,0,17);
		detailsPanel.add(chkReadExplorer, gc); 
		
		//////////////////////////////////////////Begin Column 3 ///////////////////////////////////////////
		gc.gridx = 2;
		gc.gridy = 2;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.insets = new Insets(24,-31,-24,31);
		detailsPanel.add(new JLabel("Last Name"), gc); //Last Name label
		
		gc.gridx = 2;
		gc.gridy = 3;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.insets = new Insets(22,-34,-22,34);
		detailsPanel.add(txtLastName, gc); //Last Name TextField
		
		gc.gridx = 2;
		gc.gridy = 4;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.insets = new Insets(15,-34,0,34);
		detailsPanel.add(chkToeic, gc); 
		
		//////////////////////////////////////////Begin Column ? ///////////////////////////////////////////
		gc.gridx = 3;
		gc.gridy = 3;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.insets = new Insets(24,-34,-24,34);
		detailsPanel.add(new JLabel("Branch"), gc); //Branch label
		
		gc.gridx = 3;
		gc.gridy = 4;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(15,-80,0,20);
		detailsPanel.add(chkEikon, gc); 
		//////////////////////////////////////////Begin Column ? ///////////////////////////////////////////
		gc.gridx = 4;
		gc.gridy = 3;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.insets = new Insets(8,-34,-8,34);
		detailsPanel.add(cmbBaseLC, gc); //BaseLC ComboBox
		
		gc.gridx = 4;
		gc.gridy = 4;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.insets = new Insets(15,-34,0,34);
		detailsPanel.add(chkClock, gc); 
		//////////////////////////////////////////Begin Column ? ///////////////////////////////////////////
		gc.gridx = 5;
		gc.gridy = 3;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.insets = new Insets(24,-34,-24,34);
		JLabel grid1 = new JLabel("MAKE GRID");
		grid1.setForeground(UI_Settings.getComponentpanefillcolor());
		detailsPanel.add(grid1, gc); //MAKE GRID
		
		gc.gridx = 5;
		gc.gridy = 4;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.insets = new Insets(15,-70,0,20);
		detailsPanel.add(chkPhonics, gc); 
		//////////////////////////////////////////Begin Column ? ///////////////////////////////////////////
		gc.gridx = 7;
		gc.gridy = 3;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.insets = new Insets(5,-34,-5,34);
		JLabel grid2 = new JLabel("MAKE GRID");
		grid2.setForeground(UI_Settings.getButtonPanelColor());
		detailsPanel.add(grid2, gc); //MAKE GRID		
		
		gc.gridx = 7;
		gc.gridy = 4;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.insets = new Insets(15,-34,0,34);
		detailsPanel.add(chkTimezones, gc); 
		
		
		//////////////////////////////////////////Begin Column ? ///////////////////////////////////////////
		gc.gridx = 8;
		gc.gridy = 3;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.insets = new Insets(5,-34,-5,34);
		JLabel grid3 = new JLabel("MAKE GRID");
		grid3.setForeground(UI_Settings.getComponentpanefillcolor());
		detailsPanel.add(grid3, gc); //MAKE GRID
		
		gc.gridx = 8;
		gc.gridy = 4;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 1;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(15,-34,0,34);
		detailsPanel.add(chkBGA, gc); 
		/******************************************************Add the Buttons Panel************************************************/

		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 2));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(labels[0]);
		rightPanel.add(btnSave);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		
		
		
		/*************************************************Report Top Edit Button Panel*******************************************************/
		JPanel editDeleteButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 5));
		editDeleteButtonPanel.setBackground(UI_Settings.getButtonPanelColor());
		editDeleteButtonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 30));
		editDeleteButtonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 30));
		
		editDeleteButtonPanel.add(labels[1]);
		editDeleteButtonPanel.add(labels[2]);

		/********************************************************Set the Table Objects Sizes**************************************************/

		addEmployeeTable.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*10)));
		addEmployeeTable.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*10)));
		
		addEmployeeBranchDetailsTable.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*3)));
		addEmployeeBranchDetailsTable.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*3)));
	
		/******************************************************Create the Table Data Panel************************************************/
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(buttonPanel);
        
        
        addEmployeeTable.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(addEmployeeTable);
        
        centerPanel.add(Box.createVerticalStrut(30));

        addEmployeeBranchDetailsTable.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(addEmployeeBranchDetailsTable);
        
        editDeleteButtonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(editDeleteButtonPanel);
        
		/*********************************************************************************************************************************/
    	/////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 750));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 750));

		//Add the details section and table sections to the canvas.
		canvas.add(detailsPanel, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
	
		
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(canvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());
		
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());

		return scroller;
	}//END addEmployee
	
}