package utilities;

import java.util.Random;

public class UniqueIDGenerator {
	
	public UniqueIDGenerator(){ 
	}

	public int getUniqueCustomerID(){
		int number = (new Random().nextInt(9999-1000)+1000);
		//int number = (new Random().nextInt(10-1)+1);

		return number;
	}
}
