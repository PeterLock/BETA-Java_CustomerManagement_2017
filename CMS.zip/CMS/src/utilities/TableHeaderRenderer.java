package utilities;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.border.MatteBorder;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

import settings.UI_Settings;


/*******************************************************************Header Renderer************************************************/

public class TableHeaderRenderer extends JLabel implements TableCellRenderer{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6194381589507935826L;
	private Color fgColor = UIManager.getColor("TableHeader.foreground");
	private Color bgColor = UIManager.getColor("TableHeaader.background");
	
	public TableHeaderRenderer(){
		setOpaque(true);
	}
	
	public void setForegroundColor(Color fgColor){
		this.fgColor = fgColor;
	}
	
	public Color getForegroundColor(){
		return fgColor;
	}
	
	public void setBackgroundColor(Color bgColor){
		this.bgColor = bgColor;
	}
	
	public Color getBackgroundColor(){
		return bgColor;
	}

	public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
			int row, int column) {
		
		JLabel label = this;
		label.setText((value == null)? "":(""+value.toString()));
		label.setMinimumSize(label.getPreferredSize());
		label.setPreferredSize(label.getPreferredSize());

		MatteBorder matte = new MatteBorder(0, 0, 1, 1, Color.WHITE);
		label.setBorder(matte);
		
		//increase the height of the table header
		JTableHeader th = table.getTableHeader();
		th.setPreferredSize(new Dimension(th.getWidth(), UI_Settings.getTableHeaderHeight()));

		label.setFont(UI_Settings.getComponentsFontPlain());
		return label;
	}
}
