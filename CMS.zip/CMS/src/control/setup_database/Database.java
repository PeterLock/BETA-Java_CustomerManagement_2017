package control.setup_database;

import java.io.File;

/* Use this class to load or setup a new database with the table structures required*/
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Database {
	
	private Connection con;
	
	public Database(){
		
		File file = new File ("CMS_DB.db");

		if(file.exists())
		 {
		    System.out.print("This database name already exists\n");
		 }
		 else{
			try {
				connect();
			} catch (Exception e) {
				e.printStackTrace();
			}
		 }
	}
	
	public void connect() throws Exception{
	    con = null;
	    try {
	      Class.forName("org.sqlite.JDBC");
	      con = DriverManager.getConnection("jdbc:sqlite:CMS_DB.db");
	      
	      create_CustomerTable();
	      create_GroupTable();
	      create_GroupMemberListTable();
	      create_MaterialListTable();
	      create_EventsTable();
	      create_WaitingListTable();
	      create_AlertsListTable();
	      
	    } catch ( Exception e ) {
	      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
	      System.exit(0);
	    }
	    System.out.println("Created a new database successfully");	  
		con.close();
	}
	
	private void create_AlertsListTable() {
		java.sql.Statement stmt;
		
		try{
			stmt = con.createStatement();
			String sql = "CREATE TABLE AlertsList " +
						" (id INT PRIMARY KEY			NOT NULL, " +
						" alertDescription				CHAR(100), " +
						" alertDate						CHAR(50), " +
						" alertLevel					INT) ";
			stmt.executeUpdate(sql);
			stmt.close();
		} catch(Exception e){
		      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
		      System.exit(0);
		}
		System.out.println("Alert List Table created successfully");

	}

	private void create_WaitingListTable() {
		java.sql.Statement stmt;
		
		try{
			stmt = con.createStatement();
			String sql = "CREATE TABLE WaitingList " +
					" (id INT PRIMARY KEY				NOT NULL, " +
					" firstName							CHAR(50), " +
					" lastName							CHAR(50), " +
					" age								int, " +
					" recommendedLevel					CHAR(50), " +
					" comments							CHAR(250)," +
					" waitingFromDate					CHAR(100))";
			stmt.executeUpdate(sql);
			stmt.close();
		} catch(Exception e){
		      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
		      System.exit(0);
		}
		System.out.println("Waiting List Table created successfully");

	}

	private void create_EventsTable() {
		java.sql.Statement stmt;
		
		try{
			stmt = con.createStatement();
			String sql = "CREATE TABLE EventsList " +
						" (id INT PRIMARY KEY			NOT NULL, " +
						" eventName						CHAR(50), " +
						" groupName						CHAR(50), " +
						" startDate						CHAR(50), " +
						" endDate						CHAR(50), " +
						" description					CHAR(250), " +
						" preference1					CHAR(50), " +
						" preference2					CHAR(50), " +
						" preference3					CHAR(50))";
			stmt.executeUpdate(sql);
			stmt.close();
		} catch(Exception e){
		      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
		      System.exit(0);
		}
		System.out.println("Events Table created successfully");
	}

	private void create_MaterialListTable() {
		java.sql.Statement stmt;
		
		try{
			stmt = con.createStatement();
			String sql = " CREATE TABLE MaterialList " +
						" (id INT PRIMARY KEY 			NOT NULL, " +
						" materialName					CHAR(50), " +
						" publisherName					CHAR(50), " +
						" edition						TEXT, " +
						" numberLevels					TEXT, " +
						" numberChapters				TEXT, " +
						" hasReport						TEXT, " +
						" hasDVD						TEXT, " +
						" hasReader 					TEXT, " +
						" hasTest						TEXT, " +
						" testInformation				CHAR(250), " +
						" comments 						CHAR(250), " +
						" description 					CHAR(250))";
			stmt.executeUpdate(sql);
			stmt.close();
		}catch(Exception e){
			System.out.println( e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Material List Table created successfully");
	}

	private void create_GroupMemberListTable() {
		java.sql.Statement stmt;
		
		try{
			stmt = con.createStatement();
			String sql = "CREATE TABLE GroupMemberList " +
						" (group_id INT PRIMARY KEY		NOT NULL, " +
						" group_name					TEXT NOT NULL, " +
						" member1_id 					INT,	" +
						" member2_id 					INT,	" +
						" member3_id 					INT,	" +
						" member4_id 					INT,	" +
						" member5_id 					INT,	" +
						" member6_id 					INT,	" +
						" member7_id 					INT,	" +
						" member8_id 					INT,	" +
						" member9_id 					INT,	" +
						" member10_id 					INT	)";
			stmt.executeUpdate(sql);
			stmt.close();
		}catch(Exception e){
			System.err.println( e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Group Member List Table created successfully");
	}

	private void create_GroupTable() {
		java.sql.Statement stmt;
		
		try{
			stmt = con.createStatement();
			String sql = "CREATE TABLE GroupList " +
						" (id INT PRIMARY KEY	NOT NULL, " +
						" name					TEXT NOT NULL, " +
						" material				TEXT, " +
						" level					TEXT, " +
						" class_size			TEXT, " +
						" max_class_size		TEXT, " +
						" day					TEXT, " +
						" time					TEXT) ";	
			
			stmt.executeUpdate(sql);
			stmt.close();
		} catch(Exception e){
			System.err.println( e.getClass().getName() + ": " + e.getMessage() );
			System.exit(0);
		}
		System.out.println("Group Table created successfully");
	}

	private void create_CustomerTable() {
		
		java.sql.Statement stmt;
		
		 try {
		      stmt = con.createStatement();
		      String sql = "CREATE TABLE Customers " +
		                   "(id INT PRIMARY KEY     NOT NULL," +
		                   " firstName           	TEXT    NOT NULL, " +
		                   " lastName 				TEXT	NOT NULL, " +
		                   " month					TEXT, " +
		                   " material				TEXT, " +
		                   " level					INT, " +
		                   " age					INT, " +
		                   " listening				INT, " +
		                   " speaking				INT, " +
		                   " reading				INT, " +
		                   " participation			INT, " +
		                   " cooperation			INT, " +
		                   " interests				CHAR(50), " +
		                   " comments				CHAR(50)) ";
		      stmt.executeUpdate(sql);
		      stmt.close();
		    } catch ( Exception e ) {
		      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
		      System.exit(0);
		    }
		    System.out.println("Customer Table created successfully");
		
		
	}

	public void disconnect(){
		if(con != null){
			try {
				con.close();
				System.out.println("Closed setup database connection");
			} catch (SQLException e) {
				System.out.println("Can't close the connection");
			}
		}
	}
}
