package control.setup_database;

import java.io.File;

/* Use this class to load or setup a new database with the table structures required*/

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Statement;

public class Database {
	
	private Connection con;
	
	public Database(){
		
		File file = new File ("CMS_DB.db");

		if(file.exists())
		 {
		    System.out.print("This database name already exists\n");
		 }
		 else{
			try {
				connect();
			} catch (Exception e) {
				e.printStackTrace();
			}
		 }
	}
	
	public void connect() throws Exception{
	    con = null;
	    try {
	      Class.forName("org.sqlite.JDBC");
	      con = DriverManager.getConnection("jdbc:sqlite:CMS_DB.db");
	      
	      create_CustomerTable();
	      
	      
	    } catch ( Exception e ) {
	      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
	      System.exit(0);
	    }
	    System.out.println("Created a new database successfully");	    
	}
	
	private void create_CustomerTable() {
		
		java.sql.Statement stmt;
		
		 try {
		      stmt = con.createStatement();
		      String sql = "CREATE TABLE Customers " +
		                   "(id INT PRIMARY KEY     NOT NULL," +
		                   " firstName           	TEXT    NOT NULL, " +
		                   " lastName 				TEXT	NOT NULL, " +
		                   " month					TEXT, " +
		                   " material				TEXT, " +
		                   " level					INT, " +
		                   " age					INT, " +
		                   " listening				INT, " +
		                   " speaking				INT, " +
		                   " reading				INT, " +
		                   " participation			INT, " +
		                   " cooperation			INT, " +
		                   " interests				CHAR(50), " +
		                   " comments				CHAR(50)) ";
		      stmt.executeUpdate(sql);
		      stmt.close();
		      con.close();
		    } catch ( Exception e ) {
		      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
		      System.exit(0);
		    }
		    System.out.println("Table created successfully");
		
		
	}

	public void disconnect(){
		if(con != null){
			try {
				con.close();
				System.out.println("Closed database successfully");
			} catch (SQLException e) {
				System.out.println("Can't close the connection");
			}
		}
	}
}
