package product.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerListModel;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;

import control.build.FormListener;
import group.gui.FormEventMemberList;
import product.controller.Controller;
import settings.UI_Settings;
import utilities.JTextFieldLimit;
import utilities.SentryModule;
import utilities.TextPrompt;
import utilities.UniqueIDGenerator;

public class ViewProductPanel extends JPanel {
	
	private UniqueIDGenerator idGenerator = new UniqueIDGenerator();
	private TextPrompt textPrompt;
	private control.build.FormListener formListener;
	
	private JPasswordField passwordField;
	private JFrame controllingFrame; 
	
	private Calendar c = Calendar.getInstance();
	private JLabel lblDate = new JLabel(c.getTime().toString());
	
	private Border lightBorder = BorderFactory.createLineBorder(new Color(192,192,192));

	
	private JCheckBox chkDVDYes;
	private JCheckBox chkReaderYes;
	private JCheckBox chkTestYes;
	private JCheckBox chkReportYes;

	private JCheckBox chkDVDNo;
	private	JCheckBox chkReaderNo;
	private JCheckBox chkTestNo;
	private JCheckBox chkReportNo;
	
	private JTextArea txtAreaTestInformation;
	private JTextField txtNewMaterialName;
	private JTextField txtPublisherName;
	private JTextField txtEdition;
	private JTextField txtLevels;
	private JTextField txtChapters;
	private JTextField txtNeedsReport;
	private JTextField txtDVD;
	private JTextField txtReader;
	private JTextField txtTest;
	
	private JTextArea txtareaMaterialDescription;
	private JTextArea txtareaTeachingComments;
	
	private SpinnerListModel levelModel;
	private SpinnerListModel chapterModel;
	
	private JPanel threeDotsPanel;
    private JPanel container;
	private JPanel container_left;
	private JPanel container_right;
	private JPanel canvas;
	private JPanel detailsPanel;
	private JPanel centerPanel;
	
	
	private JLabel lblCloseWindow = new JLabel("close panel group [x]");
	private JLabel lblCloseWindow2 = new JLabel("close panel group [x]");

	JComboBox cmbProductName = new JComboBox(UI_Settings.getBooks());
	List<JTextField> materialTextFields = new ArrayList<JTextField>();
	
	private List <JCheckBox> checkboxes = new ArrayList<JCheckBox>();
	private product.controller.Controller controller;
	private TablePanel addMaterialTablePanel = new TablePanel();
	
	
	private JPanel optionalDetailsPanel;
	
	public ViewProductPanel(){

	}
	
	public Component run(){
		JScrollPane scroller = initialize();
		return scroller;
	}

	private JScrollPane initialize() {
		
		cmbProductName.setPreferredSize(new Dimension(250, UI_Settings.getComboBoxHeight()));
		cmbProductName.setFont(UI_Settings.getComponentInputFontSize());
		cmbProductName.setMinimumSize(cmbProductName.getPreferredSize());
		
		int tableWindowHeight = 0;
		int tableRowNumber = 0;
		
		tableWindowHeight = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height/9;
		tableRowNumber = tableWindowHeight/UI_Settings.getTableRowHeight();
		
		this.setFormListener(new FormListener(){
			
			@Override
			public void formEventOccurred(customer.gui.FormEvent e) {
			}
			
			public void formEventOccurred(group.gui.FormEvent ev){
			}

			public void formEventOccurred(product.gui.FormEvent ev) {
				controller.addMaterial(ev);
			}

			public void formEventOccurred(FormEventMemberList e) {
				// TODO Auto-generated method stub
				
			}
		});

		lblCloseWindow.setCursor(new Cursor(Cursor.HAND_CURSOR));
		
		lblCloseWindow2.setForeground(Color.BLACK);
		lblCloseWindow2.setCursor(new Cursor(Cursor.HAND_CURSOR));
		
		threeDotsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
		threeDotsPanel.setVisible(false);
		
		/***********************Initialize Fields******************************/
		JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());
		failedMessage.setVisible(false);
		
		JPasswordField passwordField;
        passwordField = new JPasswordField(10);
        passwordField.setActionCommand(UI_Settings.getOk());
		
		JLabel labels[] = new JLabel[11];
		labels[0] = new JLabel("reset fields");
		labels[1] = new JLabel("...");
		labels[2] = new JLabel("delete");
		labels[3] = new JLabel("edit");
		labels[4] = new JLabel("delete");
		labels[5] = new JLabel("edit");
		labels[6] = new JLabel("delete");
		labels[7] = new JLabel("edit");
		labels[8] = new JLabel("Administrator password");
		labels[9] = new JLabel("help");
		labels[10] = new JLabel("delete material");
		
		for(int i = 0; i< 11; i++ ) {
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		
		txtareaMaterialDescription = new JTextArea(7, 20);
		txtareaMaterialDescription.setEditable(true);
		txtareaMaterialDescription.setBorder(UI_Settings.getBorderoutline());
		txtareaMaterialDescription.setWrapStyleWord(true);
		txtareaMaterialDescription.setLineWrap(true);
		txtareaMaterialDescription.setDocument(new JTextFieldLimit(250));
		txtareaMaterialDescription.setMinimumSize(txtareaMaterialDescription.getPreferredSize());
		TextPrompt textPrompt = new TextPrompt("<no material description entered>", txtareaMaterialDescription);
		
		txtareaTeachingComments = new JTextArea(7, 20);
		txtareaTeachingComments.setEditable(true);
		txtareaTeachingComments.setBorder(UI_Settings.getBorderoutline());
		txtareaTeachingComments.setWrapStyleWord(true);
		txtareaTeachingComments.setLineWrap(true);
		txtareaTeachingComments.setDocument(new JTextFieldLimit(250));
		txtareaTeachingComments.setMinimumSize(txtareaTeachingComments.getPreferredSize());
		textPrompt = new TextPrompt("no teaching comments entered", txtareaTeachingComments);
		
		JButton btnDeleteMaterial = new JButton("Delete Material");
		btnDeleteMaterial.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnDeleteMaterial.setPreferredSize(UI_Settings.getJbuttonSize());
		btnDeleteMaterial.setFont(UI_Settings.getComponentInputFontSize());
		
		JButton btnAddCustomerToGroup = new JButton("Add Material");
		btnAddCustomerToGroup.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnAddCustomerToGroup.setFont(UI_Settings.getComponentInputFontSize());
		btnAddCustomerToGroup.setPreferredSize(new Dimension(160,UI_Settings.getJbuttonSize().height));
		btnAddCustomerToGroup.setMinimumSize(new Dimension(160,UI_Settings.getJbuttonSize().height));
		
		btnAddCustomerToGroup.addMouseListener(new MouseAdapter(){
			
			String material_name = "";
			String publisher_name = "";
			String edition = "";
			int num_levels = 0;
			int num_chapters = 0;
			String has_report = "";
			String has_dvd = "";
			String has_reader = "";
			String has_test = "";
			String test_information = "";
			String material_description = "";
			String material_comments = "";
			

			int id = 0;
			
			FormEvent ev;
			
			
			
			public void mousePressed(MouseEvent e){
				ev = getDataFromScreen();
				try {
					controller.connect();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
			
			public void mouseReleased(MouseEvent e){
				if(formListener != null){
					formListener.formEventOccurred(ev);
					controller.disconnect();
				}else{
					System.err.println("FormListener is NULL");
				}
			}



			private FormEvent getDataFromScreen() {
				
				material_name = txtNewMaterialName.getText();
				publisher_name = txtPublisherName.getText();
				edition = txtEdition.getText();
				num_levels = (int)levelModel.getValue();
				num_chapters = (int)chapterModel.getValue();

				has_report = getCheckValues(chkReaderYes.isSelected());
				has_dvd = getCheckValues(chkDVDYes.isSelected());
				has_reader = getCheckValues(chkReaderYes.isSelected());
				has_test = getCheckValues(chkTestYes.isSelected());

				test_information = txtAreaTestInformation.getText();
				material_description = txtareaMaterialDescription.getText();
				material_comments = txtareaTeachingComments.getText();
				
				int temp = idGenerator.getUniqueCustomerID();
				id=temp;
				
				ev = new FormEvent(this, material_name, publisher_name, edition, num_levels, num_chapters, has_report, has_dvd, has_reader, has_test,
						test_information, material_description, material_comments, id);

				return ev;
			}



			private String getCheckValues(boolean value) {
				
				if(value)return "Yes";
				else return "No";
				
			}
			
		});
		
		optionalDetailsPanel = addOptionalDetailsPanel();

		
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		int size = 12;
		txtPublisherName = new JTextField(size);
		txtPublisherName.setMinimumSize(txtPublisherName.getPreferredSize());
		txtPublisherName.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtPublisherName); 
		
		txtEdition = new JTextField(size);
		txtEdition.setMinimumSize(txtEdition.getPreferredSize());
		txtEdition.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtEdition); 
		
		txtLevels = new JTextField(size);
		txtLevels.setMinimumSize(txtLevels.getPreferredSize());
		txtLevels.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtLevels); 
		
		txtChapters = new JTextField(size);
		txtChapters.setMinimumSize(txtChapters.getPreferredSize());
		txtChapters.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtChapters); 
		
		txtNeedsReport = new JTextField(size);
		txtNeedsReport.setMinimumSize(txtNeedsReport.getPreferredSize());
		txtNeedsReport.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtNeedsReport); 
		
		txtDVD = new JTextField(size);
		txtDVD.setMinimumSize(txtDVD.getPreferredSize());
		txtDVD.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtDVD); 
		
		txtReader = new JTextField(size);
		txtReader.setMinimumSize(txtReader.getPreferredSize());
		txtReader.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtReader); 
		
		txtTest = new JTextField(size);
		txtTest.setMinimumSize(txtTest.getPreferredSize());
		txtTest.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtTest); 
		
		/***************************************************Create textAreas********************************************************************/

		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
			   int action = JOptionPane.showConfirmDialog(ViewProductPanel.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		      
			   if(action == JOptionPane.OK_OPTION){
					cmbProductName.setSelectedIndex(0);
		       }
			}
		});
		
		labels[1].setFont(labels[1].getFont().deriveFont(18.0f));
		labels[1].addMouseListener(new MouseAdapter(){
			
			public void mousePressed(MouseEvent e){
				
				container.setVisible(true);
				threeDotsPanel.setVisible(false);
				
			}
			
		});
		
		chkDVDYes = new JCheckBox("Yes");
		chkDVDYes.setFont(UI_Settings.getComponentsFontPlain());
		chkDVDYes.setForeground(UI_Settings.getComponentsFontColorLight());
		checkboxes.add(chkDVDYes);
		
		chkReaderYes = new JCheckBox("Yes");
		chkReaderYes.setFont(UI_Settings.getComponentsFontPlain());
		chkReaderYes.setForeground(UI_Settings.getComponentsFontColorLight());
		checkboxes.add(chkReaderYes);
		
		chkTestYes = new JCheckBox("Yes");
		chkTestYes.setFont(UI_Settings.getComponentsFontPlain());
		chkTestYes.setForeground(UI_Settings.getComponentsFontColorLight());
		checkboxes.add(chkTestYes);
		
		chkReportYes = new JCheckBox("Yes");
		chkReportYes.setFont(UI_Settings.getComponentsFontPlain());
		chkReportYes.setForeground(UI_Settings.getComponentsFontColorLight());
		checkboxes.add(chkReportYes);
		
		chkDVDNo = new JCheckBox("No");
		chkDVDNo.setSelected(true);
		chkDVDNo.setFont(UI_Settings.getComponentsFontPlain());
		chkDVDNo.setForeground(UI_Settings.getComponentsFontColorLight());
		checkboxes.add(chkDVDNo);
		
		chkReaderNo = new JCheckBox("No");
		chkReaderNo.setSelected(true);
		chkReaderNo.setFont(UI_Settings.getComponentsFontPlain());
		chkReaderNo.setForeground(UI_Settings.getComponentsFontColorLight());
		checkboxes.add(chkReaderNo);
		
		chkTestNo = new JCheckBox("No");
		chkTestNo.setSelected(true);
		chkTestNo.setFont(UI_Settings.getComponentsFontPlain());
		chkTestNo.setForeground(UI_Settings.getComponentsFontColorLight());
		checkboxes.add(chkTestNo);
		
		chkReportNo = new JCheckBox("No");
		chkReportNo.setSelected(true);
		chkReportNo.setFont(UI_Settings.getComponentsFontPlain());
		chkReportNo.setForeground(UI_Settings.getComponentsFontColorLight());
		checkboxes.add(chkReportNo);
		
		ItemListener listener = new ItemListener(){

			@Override
			public void itemStateChanged(ItemEvent e) {
				
				if(e.getStateChange() == ItemEvent.SELECTED) {
				    /////////////////////////////////////////////////
				    if(e.getItem() == chkDVDYes) {
				    	chkDVDYes.setSelected(true);
				    	chkDVDNo.setSelected(false);
				    } 
				    if(e.getItem() == chkDVDNo){
				    	chkDVDNo.setSelected(true);
				    	chkDVDYes.setSelected(false);
				    }
				    /////////////////////////////////////////////////
				    if(e.getItem() == chkReaderYes){
				    	chkReaderYes.setSelected(true);
				    	chkReaderNo.setSelected(false);
				    }
				    if(e.getItem() == chkReaderNo){
				    	chkReaderNo.setEnabled(true);
				    	chkReaderYes.setSelected(false);
				    }
				    /////////////////////////////////////////////////
				    if(e.getItem() == chkTestYes){
				    	chkTestYes.setSelected(true);
				    	chkTestNo.setSelected(false);
				    }
				    if(e.getItem() == chkTestNo){
				    	chkTestNo.setSelected(true);
				    	chkTestYes.setSelected(false);
				    }
				    /////////////////////////////////////////////////
				    if(e.getItem() == chkReportYes){
				    	chkReportYes.setSelected(true);
				    	chkReportNo.setSelected(false);
				    }
				    if(e.getItem() == chkReportNo){
				    	chkReportNo.setSelected(true);
				    	chkReportYes.setSelected(false);
				    }
				}
			}
		};
		
		for(int i = 0; i < checkboxes.size(); i++){
			
			checkboxes.get(i).addItemListener(listener);
			
		}
		JButton btnSave = new JButton("Add New Material");
		btnSave.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnSave.setFont(UI_Settings.getComponentInputFontSize());
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		txtPublisherName = new JTextField(size);
		txtPublisherName.setMinimumSize(txtPublisherName.getPreferredSize());
		txtPublisherName.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtPublisherName); 
		
		txtEdition = new JTextField(size);
		txtEdition.setMinimumSize(txtEdition.getPreferredSize());
		txtEdition.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtEdition); 
		
		Integer[] materialLevels = getLevels();
		levelModel = new SpinnerListModel(materialLevels);
		JSpinner spinnerLevels = new JSpinner(levelModel);
		
		Component materialLevelsEditor = spinnerLevels.getEditor();
		JFormattedTextField jftf1 = ((JSpinner.DefaultEditor)
				materialLevelsEditor).getTextField();
		
		jftf1.setColumns(size);
		jftf1.setAlignmentX(CENTER_ALIGNMENT);
		
		Integer[] materialChapters = getChapterCount();
		chapterModel = new SpinnerListModel(materialChapters);
		JSpinner spinnerChapters = new JSpinner(chapterModel);
		
		Component materialChapterEditor = spinnerChapters.getEditor();
		JFormattedTextField jftf2 = ((JSpinner.DefaultEditor)
				materialChapterEditor).getTextField();
		
		jftf2.setColumns(size);
		jftf2.setAlignmentX(CENTER_ALIGNMENT);
		
		txtNeedsReport = new JTextField(size);
		txtNeedsReport.setMinimumSize(txtNeedsReport.getPreferredSize());
		txtNeedsReport.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtNeedsReport); 
		
		txtDVD = new JTextField(size);
		txtDVD.setMinimumSize(txtDVD.getPreferredSize());
		txtDVD.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtDVD); 
		
		txtReader = new JTextField(size);
		txtReader.setMinimumSize(txtReader.getPreferredSize());
		txtReader.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtReader); 
		
		txtTest = new JTextField(size);
		txtTest.setMinimumSize(txtTest.getPreferredSize());
		txtTest.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtTest); 
		
		txtNewMaterialName = new JTextField(20);
		txtNewMaterialName.setMinimumSize(txtNewMaterialName.getPreferredSize());
		txtNewMaterialName.setHorizontalAlignment(JTextField.LEFT);
		materialTextFields.add(txtNewMaterialName); 
		
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
			   int action = JOptionPane.showConfirmDialog(ViewProductPanel.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		      
			   if(action == JOptionPane.OK_OPTION){
					txtNewMaterialName.setText("");
		       }
			}
		});
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/**********************Create the messages panel***********************/
		GridBagConstraints gc = new GridBagConstraints();

		JPanel heading = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		JLabel lblHeading = new JLabel("Viewing product details");
		heading.setBackground(Color.WHITE);
		lblHeading.setFont(lblHeading.getFont().deriveFont(16.0f));
		heading.add(lblHeading);
		
		JPanel headingMessage = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		headingMessage.setBackground(Color.WHITE);
		JLabel lblHeadingMessage = new JLabel("Viewing product details is simple. Choose the product name from the dropdown box below.\n"
				+ "If you want to delete a product you will need to enter the administritive password.");
		
		headingMessage.add(lblHeadingMessage);

		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-30));
		detailsPanel.setLayout(new GridBagLayout());
		
		JPanel headerMessagePanel = new JPanel(new GridBagLayout());
		setPanelSize(headerMessagePanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 100));
		headerMessagePanel.setBackground(Color.WHITE);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		headerMessagePanel.add(heading,gc);
		
		gc.gridy = 1;
		gc.insets = new Insets(-15,0,0,0);
		headerMessagePanel.add(headingMessage, gc);
	
		gc.gridy = 2;
		gc.insets = new Insets(-30,0,0,0);
		headerMessagePanel.add(detailsPanel, gc);
		
		JPanel firstRow = new JPanel();
		firstRow.setBackground(UI_Settings.getButtonPanelColor());
		firstRow.setLayout(new BoxLayout(firstRow, BoxLayout.X_AXIS));
		
		JPanel fieldcontainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		fieldcontainer.setBackground(Color.WHITE);
		fieldcontainer.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 50));
		fieldcontainer.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 50));
		fieldcontainer.add(new JLabel("Select the product you want view:"));
		fieldcontainer.add(cmbProductName);
		
		fieldcontainer.setAlignmentX(Component.LEFT_ALIGNMENT);
		firstRow.add(fieldcontainer);
		
		firstRow.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,30));
		firstRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 30));

		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(17,0,0,0);
		detailsPanel.add(firstRow, gc);
		/******************************************************Add the Buttons Panel************************************************/
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(labels[0]);

		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		/*****************************************************Add the group details and member list panel***********************************/
		////////Initialize local fields here for convenience/////////
		txtAreaTestInformation = new JTextArea(6, 20);
		txtAreaTestInformation.setEditable(true);
		txtAreaTestInformation.setBorder(UI_Settings.getBorderoutline());
		txtAreaTestInformation.setWrapStyleWord(true);
		txtAreaTestInformation.setLineWrap(true);
		txtAreaTestInformation.setDocument(new JTextFieldLimit(150));
		
		Border line = BorderFactory.createLineBorder(new Color(224,224,224));
		Border empty = new EmptyBorder(5, 5, 5, 5);
		CompoundBorder border = new CompoundBorder(line, empty);
		txtAreaTestInformation.setBorder(border);
		
		txtAreaTestInformation.setPreferredSize(txtAreaTestInformation.getPreferredSize());
		textPrompt = new TextPrompt("<no test information entered>", txtAreaTestInformation);
		
		//Make the material information panel
		JPanel pnlMaterialInformation = new JPanel(new GridBagLayout());
		
		pnlMaterialInformation.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()+10));
		pnlMaterialInformation.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()+10));
		pnlMaterialInformation.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()+10));
		pnlMaterialInformation.setBackground(Color.WHITE);
		
		////////////////////DONE///////////////////
		//Make the member list panel
		JPanel pnlMaterialDetails = new JPanel(new GridBagLayout());
		
		pnlMaterialDetails.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
		pnlMaterialDetails.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
		pnlMaterialDetails.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
		
		pnlMaterialDetails.setBackground(Color.WHITE);
	
			JPanel panel2 = new JPanel(new GridBagLayout());
			panel2.setBackground(new Color(246,246,246));
			Border panel1border = BorderFactory.createLineBorder(Color.LIGHT_GRAY);

			panel2.setBorder(panel1border);
			panel2.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
			panel2.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
			panel2.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3)*2, UI_Settings.getRegularPanelHeight()+10));
			
				///Add the material details contents to the panel////
				//////////////Col 1///////////
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridwidth = 1;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(17,20,0,0);
				panel2.add(new JLabel("Publisher Name:"), gc);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.insets = new Insets(7,20,0,0);
				panel2.add(new JLabel("Edition:"), gc);
				
				gc.gridx = 0;
				gc.gridy = 2;
				gc.insets = new Insets(7,20,0,0);
				panel2.add(new JLabel("Number of Levels:"), gc);
				
				gc.gridx = 0;
				gc.gridy = 3;
				gc.insets = new Insets(7,20,0,0);
				panel2.add(new JLabel("Number of Chapters:"), gc);
				/////////Col 2////////
				gc.gridx = 1;
				gc.gridy = 0;
				gc.insets = new Insets(10,20,0,0);
				panel2.add(txtPublisherName, gc);
				
				gc.gridx = 1;
				gc.gridy = 1;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(txtEdition, gc);
				
				gc.gridx = 1;
				gc.gridy = 2;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(spinnerLevels, gc);
				
				
				gc.gridx = 1;
				gc.gridy = 3;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(spinnerChapters, gc);
				/////////Col 3////////
				gc.gridx = 2;
				gc.gridy = 0;
				gc.insets = new Insets(17,20,0,0);
				panel2.add(new JLabel("Need Customer Report:"), gc);
				
				gc.gridx = 2;
				gc.gridy = 1;
				gc.insets = new Insets(7,20,0,0);
				panel2.add(new JLabel("DVD Lessons:"), gc);
				
				gc.gridx = 2;
				gc.gridy = 2;
				panel2.add(new JLabel("Has a Reader:"), gc);
				
				gc.gridx = 2;
				gc.gridy = 3;
				panel2.add(new JLabel("Has a Test:"), gc);
				////////Col 4///////
				gc.gridx = 3;
				gc.gridy = 0;
				gc.insets = new Insets(10,20,0,0);
				panel2.add(chkReportYes, gc);
				
				gc.gridx = 3;
				gc.gridy = 1;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(chkDVDYes, gc);
				
				gc.gridx = 3;
				gc.gridy = 2;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(chkReaderYes, gc);
				
				gc.gridx = 3;
				gc.gridy = 3;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(chkTestYes, gc);
				////////Col 5///////
				gc.gridx = 4;
				gc.gridy = 0;
				gc.insets = new Insets(10,20,0,0);
				panel2.add(chkReportNo, gc);
				
				gc.gridx = 4;
				gc.gridy = 1;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(chkDVDNo, gc);
				
				gc.gridx = 4;
				gc.gridy = 2;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(chkReaderNo, gc);
				
				gc.gridx = 4;
				gc.gridy = 3;
				gc.insets = new Insets(0,20,0,0);
				panel2.add(chkTestNo, gc);
			
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridwidth = 1;
				gc.gridheight = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(5,5,5,5);
				pnlMaterialDetails.add(panel2,gc);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridwidth = 1;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,5);
		
		pnlMaterialInformation.add(pnlMaterialDetails, gc);
		
			//Make the member list panel
			JPanel pnlTestInfo = new JPanel(new GridBagLayout());
			pnlTestInfo.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()+10));
			pnlTestInfo.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()+10));
			pnlTestInfo.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()+10));
			pnlTestInfo.setBackground(Color.WHITE);
		
				JPanel panel1 = new JPanel(new GridBagLayout());
				panel1.setBackground(Color.WHITE);
				panel1.setBorder(panel1border);
				panel1.setPreferredSize(new Dimension((int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()));
				panel1.setMinimumSize(new Dimension((int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()));
				panel1.setMaximumSize(new Dimension((int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()));
				
					//Add the contents to the member list panel
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(10,13,-10,0);
					panel1.add(new JLabel("Test Information:"), gc);
					
					gc.gridx = 0;
					gc.gridy = 1;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(10,10,5,10);
					panel1.add(txtAreaTestInformation, gc);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.insets = new Insets(5,5,0,10);
				
				pnlTestInfo.add(panel1,gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		
		pnlMaterialInformation.add(pnlTestInfo, gc);
		
		/***********************************Create the material and comments description TextAreas**********************************************/
		
		setPanelSize(threeDotsPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 20));
		threeDotsPanel.add(labels[1]);
		threeDotsPanel.setBackground(Color.WHITE);
		
		///////////////////////////////////////////////////////////////////////////////////////
		JPanel pnlInformation = new JPanel();
		pnlInformation.setBackground(Color.WHITE);
		pnlInformation.setLayout(new GridBagLayout());
		pnlInformation.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlInformation.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlInformation.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		//////////////////////////////////////////////////////////////////////////////////////////////////////////
		//Begin Nested Details Panels (lowest panel on screen)
		JPanel pnlSaveRow = new JPanel();
		pnlSaveRow.setBackground(Color.WHITE);
		pnlSaveRow.setLayout(new GridBagLayout());
		pnlSaveRow.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));

			//Create the far left container for the group details information
			JPanel pnlSaveLeftPane = new JPanel(new GridBagLayout());
			pnlSaveLeftPane.setBackground(Color.WHITE);
			pnlSaveLeftPane.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			
			//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,0,0,0);
			
				//Add the nested panels to the container panel (information panel)
			
				JPanel panel3 = new JPanel(new GridBagLayout());
				panel3.setBackground(Color.WHITE);
				panel3.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				
				
				JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row1.setBackground(Color.WHITE);
				row1.add(new JLabel("Table updated:"));
				row1.add(lblDate);
				
				JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row2.setBackground(Color.WHITE);
				row2.add(new JLabel("Connected to: ")); //+ controller.getDBname()));
				
				JPanel row3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row3.setBackground(Color.WHITE);
				row3.add(new JLabel("Connection: Secure"));
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(5,5,0,5);
			
				panel3.add(row1, gc);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,0,5);
			
				panel3.add(row2, gc);
				
				gc.gridx = 0;
				gc.gridy = 2;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,45,5);
			
				panel3.add(row3, gc);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,20,5);
			
				pnlSaveLeftPane.add(panel3, gc);
		
		pnlSaveRow.add(pnlSaveLeftPane, gc);
			
		//////////////////////////////////////////Main Column 2 ///////////////////////////////////////////
		//Create the second panel from the left (comments panel)

		JPanel pnlSaveRight = new JPanel(new GridBagLayout());
		pnlSaveRight.setBackground(Color.WHITE);
		pnlSaveRight.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));

		

		
			//Add the nested panels to the container panel (comments panel)
			
			JPanel pblButtons = new JPanel(new GridBagLayout());
			pblButtons.setBackground(Color.WHITE);
			pblButtons.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-40));
			pblButtons.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-40));
			pblButtons.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-40));
			
			JPanel panel4 = new JPanel(new GridBagLayout());
			panel4.setBackground(Color.WHITE);
			panel4.setPreferredSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()-20));
			panel4.setMinimumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()-20));
			panel4.setMaximumSize(new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), UI_Settings.getSmallPanelHeight()-20));
			
			labels[8].setCursor(UI_Settings.getJlabelCursor());
			labels[8].addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e){
					JOptionPane.showMessageDialog(controllingFrame,
			                "The administrator password can be found with the \"Kids Coordinator\"\n"
			              + "or by contacting your \"Branch Manager\".", "Information Message", JOptionPane.WARNING_MESSAGE);
				}
			});
			
			JPanel adminPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
			adminPanel.setBackground(Color.WHITE);
			adminPanel.add(new JLabel("Administrator password:"));
			adminPanel.add(passwordField);
			adminPanel.add(labels[9]);
			adminPanel.add(btnDeleteMaterial);


			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,1,0,1);
			
			panel4.add(adminPanel, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHEAST;
			gc.insets = new Insets(-10,0,0,10);
			
			pblButtons.add(panel4, gc);
			
			//Add the comments panel	
			gc.gridx = 1;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,-5,0,0);
			
			pnlSaveRight.add(pblButtons, gc);
			
			//Add the nested panels to the container panel (information panel)
			pnlSaveRow.add(pnlSaveRight, gc);
		
		//Add the nested panels to the container panel (information panel)
		pnlInformation.add(pnlSaveRow, gc);
		
		/******************************************************Create the Table Data Panel************************************************/
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());

        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
   
        buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(buttonPanel);
        
        pnlMaterialInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlMaterialInformation);
        
        centerPanel.add(Box.createVerticalStrut(5));
        
        threeDotsPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(threeDotsPanel);
        
        centerPanel.add(Box.createVerticalStrut(5));

        optionalDetailsPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(optionalDetailsPanel);
        
        centerPanel.add(Box.createVerticalStrut(15));

        pnlInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlInformation);
        /////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 350));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 350));
		/*********************************************************************************************************************************/
		//Add the details section and table sections to the canvas.
		canvas.add(headerMessagePanel, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
		///////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly///////////////////
		canvas.setMaximumSize(UI_Settings.getMinimumScreenSize());
		canvas.setPreferredSize(UI_Settings.getMinimumScreenSize());

		
		//Create the scroll-bar, add the canvas to it and return the scroll-bar.
		JScrollPane scroller = new JScrollPane(canvas);
		//Change the width of the scroll-bar
		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		//Change the visibility of the scroll-bar
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());
		
		scroller.getVerticalScrollBar().setUnitIncrement(32);
		return scroller;
	}

	private JPanel addOptionalDetailsPanel() {
		
		GridBagConstraints gc = new GridBagConstraints();
		
		int container_height = 200;
		int header_height = UI_Settings.getPopupHeaderHeight();
		
		container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, container_height));
		container.setBackground(Color.WHITE);
		
		container_left = new JPanel(new GridBagLayout());
		setPanelSize(container_left, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, container_height));
		container_left.setBorder(lightBorder);
		container_left.setBackground(Color.WHITE);
		
		container_right = new JPanel(new GridBagLayout());
		setPanelSize(container_right, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, container_height));
		container_right.setBorder(lightBorder);
		container_right.setBackground(Color.WHITE);
		
		//For Header//
		Dimension dimension = new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, header_height);
		
		JPanel header = getHeader(dimension);
		header.add(lblCloseWindow);
		
		JPanel header2 = getHeader(dimension);
		header2.add(lblCloseWindow2);
		
		JPanel containerLeftBody = new JPanel(new GridBagLayout());
		setPanelSize(containerLeftBody, new Dimension(dimension.width/2, container_height-header_height));
		containerLeftBody.setBackground(Color.WHITE);
		
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(10,20,0,0);
			containerLeftBody.add(new JLabel("Material Description: "), gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.BOTH;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(10,10,10,10);
			containerLeftBody.add(txtareaMaterialDescription, gc);
		
		JPanel containerRightBody = new JPanel(new GridBagLayout());
		setPanelSize(containerRightBody, new Dimension(dimension.width/2, container_height-header_height));
		containerRightBody.setBackground(Color.WHITE);
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(10,20,0,0);
			containerRightBody.add(new JLabel("Material Comments: "), gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.BOTH;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(10,10,10,10);
			containerRightBody.add(txtareaTeachingComments, gc);

		
			
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,0,0,0);
		container_left.add(header, gc);
		
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.7;
		gc.weighty = 0.7;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,0,1,0);
		container_left.add(containerLeftBody, gc);
		
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.1;
		gc.weighty = 0.1;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		container_right.add(header2, gc);
		
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.7;
		gc.weighty = 0.7;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,0,1,0);
		container_right.add(containerRightBody, gc);

		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,5,10,0);
		container.add(container_left, gc);
		
		gc.gridx = 1;
		gc.insets = new Insets(0,5,10,10);
		container.add(container_right, gc);


		
		////////////////////////////////
		lblCloseWindow.addMouseListener(new MouseAdapter(){
			
			public void mouseReleased(MouseEvent e){
				container.setVisible(false);
				threeDotsPanel.setVisible(true);
			}
			
		});
		
		lblCloseWindow2.addMouseListener(new MouseAdapter(){
			
			public void mouseReleased(MouseEvent e){
				container.setVisible(false);
				threeDotsPanel.setVisible(true);
			}
			
		});

		return container;
	}

	private JPanel getHeader(Dimension dimension) {
		JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 6));
		panel.setBorder(new EmptyBorder(0,0,0,0));
		panel.setBackground(new Color(191,210,236));
		setPanelSize(panel, dimension);
		return panel;
	}

	private Integer[] getChapterCount() {
		Integer[] chapters = new Integer[]{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
		return chapters;
	}

	private Integer[] getLevels() {
		
		Integer[] levels = new Integer[]{1,2,3,4};
		
		return levels;
	}
	
	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}

	public void resetPanels() {
		container.setVisible(true);
		threeDotsPanel.setVisible(false);
	}
	
	public void setFormListener(FormListener listener){
		this.formListener = listener;
	}

	public void setController(Controller controller) {
		this.controller = controller;
	}
	
	private final static int GET_VIEWALL_TABLE_MATERIAL_LIST = 1;
	private final static int GET_ADDNEW_TABLE_MATERIAL_LIST = 2;

}
