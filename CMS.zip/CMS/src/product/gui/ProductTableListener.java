package product.gui;

public interface ProductTableListener {
	public void rowDeleted(int row);
}
