package product.controller;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.swing.JComboBox;

import product.gui.FormEvent;
import product.model.Database;
import product.model.Material;

public class Controller {
	
	static Database db = new Database();
	
	public Controller(){
	}
	
	public void showMaterialControllerMessage(){
	}
	
	public void addMaterial(product.gui.FormEvent ev) {
		
		String material_name = ev.getMaterial_name();
		String publisher_name = ev.getPublisher_name();
		String edition = ev.getEdition();
		int num_levels = ev.getNum_levels();
		int num_chapters = ev.getNum_chapters();
		String has_report = ev.getHas_report();
		String has_dvd = ev.getHas_dvd();
		String has_reader = ev.getHas_reader();
		String has_test = ev.getHas_test();
		String test_information = ev.getTest_information();
		String material_description = ev.getMaterial_description();
		String material_comments = ev.getMaterial_comments();
		int id = ev.getId();
		
		
   		Material material = new Material(material_name, publisher_name, edition, num_levels,
   				num_chapters,has_report, has_dvd, has_reader, has_test, test_information,material_description,
   				material_comments, id );


		db.addNewMaterial(material);
	}

	public void save() throws SQLException {
		db.save();
	}

	public void load() throws SQLException {
		db.load();
	}

	public void connect() throws Exception {
		db.connect();
	}

	public void saveToFile(File file) throws IOException {
	}
	
	public void loadFromFile(File file) throws IOException {
	}

	public void removeMaterial(int row, int i) {
		db.removeMaterial(row, i);
		
	}

	public void setNumberOfRows(int tableRowNumber) {
		db.setAddNewRowNumber(tableRowNumber);
	}

	public static List<Material> getMaterial(int value) {
		
		if(value == 1){
			return db.getMaterial();
		}else{
			return db.getEmptyMaterial();
		}
	}
	
	public static List<Material> getEmptyMaterial() {
		return db.getEmptyMaterial();
	}

	public void addEmptyMaterial(FormEvent ev) {
		
		String material_name = ev.getMaterial_name();
		String publisher_name = ev.getPublisher_name();
		String edition = ev.getEdition();
		int num_levels = ev.getNum_levels();
		int num_chapters = ev.getNum_chapters();
		String has_report = ev.getHas_report();
		String has_dvd = ev.getHas_dvd();
		String has_reader = ev.getHas_reader();
		String has_test = ev.getHas_test();
		String test_information = ev.getTest_information();
		String material_description = ev.getMaterial_description();
		String material_comments = ev.getMaterial_comments();
		int id = ev.getId();
		
		
   		Material material = new Material(material_name, publisher_name, edition, num_levels,
   				num_chapters,has_report, has_dvd, has_reader, has_test, test_information,material_description,
   				material_comments, id );


		db.addEmptyMaterial(material);
	}

	public String getDBname() {
		return db.getName();
	}

	public static Material searchMaterial(String materialName) {
		return db.searchMaterial(materialName);
	}

	@SuppressWarnings("rawtypes")
	public void deleteMaterial(JComboBox cmbMaterialListComboBox, int i, String materialName) {
		db.deleteMaterial(cmbMaterialListComboBox, i, materialName);
	}

	public void setMaterialRowNumber(int rows) {
		db.addNewMaterialRowNumber(rows);
	}

	public void disconnect() {
		db.disconnect();
	}
}
