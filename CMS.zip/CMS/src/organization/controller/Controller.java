package organization.controller;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import organization.model.Database;
import organization.model.Waiting;

public class Controller {
	
	static Database db = new Database();
	
	public Controller(){
	}
	
	public void showWaitingControllerMessage(){
	}
	
	public void addWaiting(organization.gui.FormEvent ev) throws SQLException {
		
		
		int id = ev.getId();
		String firstName = ev.getFirstName();
		String lastName = ev.getLastName();
		int age = ev.getAge();
		String recommendedLevel = ev.getRecommendedLevel();
		String comments = ev.getComments();
		String waitingFromDate = ev.getWaitingFrom();
		
		
   		Waiting waiting = new Waiting(id, firstName, lastName, age, recommendedLevel, comments, waitingFromDate);

		db.addNewWaiting(waiting);
		db.save();
	}

	public void save() throws SQLException {
		db.save();
	}

	public void load() throws SQLException {
		db.load();
	}

	public void connect() throws Exception {
		db.connect();
	}

	public void saveToFile(File file) throws IOException {
	}
	
	public void loadFromFile(File file) throws IOException {
	}

	public void removeWaiting(int row, int i) {
		db.removeWaiting(row, i);
		
	}

	public void setNumberOfRows(int tableRowNumber) {
		db.setAddNewRowNumber(tableRowNumber);
	}

	public static List<Waiting> getWaiting(int value) {
		
		if(value == 1){
			return db.getWaiting();
		}else{
			return db.getEmptyWaiting();
		}
	}
	
	public static List<Waiting> getEmptyWaiting() {
		return db.getEmptyWaiting();
	}

	public void addEmptyWaiting() {

   		Waiting waiting = new Waiting(0, "", "", 0, "", "", "");


		db.addEmptyWaiting(waiting);
	}

	public String getDBname() {
		return db.getName();
	}


	public void setWaitingRowNumber(int rows) {
		db.addNewWaitingRowNumber(rows);
	}

	public void disconnect() {
		db.disconnect();
	}

	public static List<Waiting> getWaitingFrom(int getAddnewTableWaitingList) {
		// TODO Auto-generated method stub
		return null;
	}

}
