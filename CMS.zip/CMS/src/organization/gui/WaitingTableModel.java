package organization.gui;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import organization.model.Waiting;

public class WaitingTableModel extends AbstractTableModel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<Waiting>db;
	
	
	int id;
	String firstName;
	String lastName;
	int age;
	String recommendedLevel;
	String comments;
	String waitingFrom;
	
	
	
	private String[] colNames = {"First Name", "Last Name", "Age", "Recommended Level", "Comments", "Waiting From"};

	@Override
	public int getRowCount() {
		return db.size();
	}

	@Override
	public int getColumnCount() {
		return 6;
	}
	
	@Override
	public String getColumnName(int column) {
		return colNames[column];
	}

	@Override
	public Object getValueAt(int row, int col) {
		
		Waiting waiting = db.get(row);
		
		switch(col){
		case 0: 
			return waiting.getFirstName();
		case 1:
			return waiting.getLastName();
		case 2:
			if(waiting.getAge() == 0){
				return null;
			}else{
				return waiting.getAge();
			}
		case 3:{
			return waiting.getRecommendedLevel();
		}
		case 4:
			return waiting.getComments();

		case 5: 
			return waiting.getWaitingFrom();
		
		default:
			return null;
		}
	}

	public void setData(List<Waiting> db) {
		this.db = db;
	}
}
