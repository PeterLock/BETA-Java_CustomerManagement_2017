package organization.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;

import settings.UI_Settings;
import utilities.TextPrompt;
import utilities.UniqueIDGenerator;

public class PossibleClasses extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static JTabbedPane pane = new JTabbedPane();
	@SuppressWarnings("unused")
	private TextPrompt textPrompt;
	@SuppressWarnings("unused")
	private UniqueIDGenerator idGenerator = new UniqueIDGenerator();
    private JPasswordField passwordField;
	private JPanel headerMessagePanel;
	private JPanel detailsPanel;
    private int centerTopHeight = 50;
	private JPanel pnlSaveInformation;
	private Calendar c = Calendar.getInstance();
	private JLabel lblDate = new JLabel(c.getTime().toString());
	private JComboBox<?> cmbGroupName = new JComboBox<Object>(UI_Settings.getGroups());
	private JComboBox<?> cmbRequestBy = new JComboBox<Object>(UI_Settings.getEmployeeNames());
	private JComboBox<?> cmbEventMonth = new JComboBox<Object>(UI_Settings.getMonths());
	private JComboBox<?> cmbWeeks = new JComboBox<Object>(UI_Settings.getWaitingFrom());
	private JButton btnDeleteEvent;
	private GridBagConstraints gc = new GridBagConstraints();
    @SuppressWarnings("unused")
	private JFrame controllingFrame; //needed for dialogs

	
	public PossibleClasses(){
	}

	public Component run(){
		JScrollPane scroller = initialize();
		return scroller;
	}

	@SuppressWarnings("unused")
	private JScrollPane initialize() {
		JPanel canvas;
		JPanel detailsPanel;
		JPanel centerPanel;
		
		final JTextArea txtAreaComments;
		JTextArea txtAreaEventList;
		JTextArea txtAreaEmail;

		btnDeleteEvent = new JButton("Perform Action");
		btnDeleteEvent.setPreferredSize(new Dimension(200,UI_Settings.getJbuttonSize().height));
		btnDeleteEvent.setMinimumSize(new Dimension(200,UI_Settings.getJbuttonSize().height));

		btnDeleteEvent.setFont(UI_Settings.getComponentInputFontSize());
		
		JCheckBox chkMatchRequest = new JCheckBox("send match alert");
		JCheckBox chkDeleteCustomer = new JCheckBox("delete waiting customer");
		
		chkMatchRequest.setFont(UI_Settings.getComponentsFontPlain());
		chkMatchRequest.setForeground(UI_Settings.getComponentsFontColorLight());
		
		chkDeleteCustomer.setFont(UI_Settings.getComponentsFontPlain());
		chkDeleteCustomer.setForeground(UI_Settings.getComponentsFontColorLight());
		
		/******************************************************Add the north panel************************************************/

		addNorthPanel();
		addSouthPanel();

		
		/***************************************************Create textAreas********************************************************************/
		Border line = BorderFactory.createLineBorder(new Color(224,224,224));
		Border empty = new EmptyBorder(5, 5, 5, 5);
		CompoundBorder border = new CompoundBorder(line, empty);
		
		txtAreaComments = new JTextArea(6, 40);
		txtAreaComments.setPreferredSize(txtAreaComments.getPreferredSize());
		txtAreaComments.setMinimumSize(txtAreaComments.getPreferredSize());
		txtAreaComments.setEditable(true);
		txtAreaComments.setBorder(border);
		txtAreaComments.setWrapStyleWord(true);
		txtAreaComments.setLineWrap(true);
		textPrompt = new TextPrompt("<no comments found>", txtAreaComments);
		txtAreaComments.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaComments.setMargin( new Insets(2,2,2,2) );
		
		
		txtAreaEventList = new JTextArea(5, 35);
		txtAreaEventList.setMinimumSize(txtAreaEventList.getPreferredSize());
		txtAreaEventList.setEditable(true);
		txtAreaEventList.setBorder(border);
		txtAreaEventList.setWrapStyleWord(true);
		txtAreaEventList.setLineWrap(true);
		textPrompt = new TextPrompt("<no events found>", txtAreaEventList);
		txtAreaEventList.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaEventList.setMargin( new Insets(5,5,5,5) );
		
		txtAreaEmail = new JTextArea(5, 35);
		txtAreaEmail.setMinimumSize(txtAreaEventList.getPreferredSize());
		txtAreaEmail.setEditable(true);
		txtAreaEmail.setBorder(border);
		txtAreaEmail.setWrapStyleWord(true);
		txtAreaEmail.setLineWrap(true);
		textPrompt = new TextPrompt("<notfiy staff of a possible class for this customer>", txtAreaEmail);
		txtAreaEmail.setFont(UI_Settings.getComponentInputFontSize());
		txtAreaEmail.setMargin( new Insets(5,5,5,5) );
		
		/***********************Initialize Fields******************************/
		final JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());

		failedMessage.setVisible(false);
		
		final JLabel failedMessage1 = new JLabel(UI_Settings.getFailedMessage());
		failedMessage1.setForeground(UI_Settings.getFailedMessageColor());

		failedMessage1.setVisible(false);
		
		JLabel labels[] = new JLabel[10];
		
		labels[0] = new JLabel("reset fields");
		labels[1] = new JLabel("delete");
		labels[2] = new JLabel("edit email");
		labels[3] = new JLabel("reset calendar");
		labels[4] = new JLabel("hint");
		labels[5] = new JLabel("edit event description");
		labels[6] = new JLabel("refresh event list");
		labels[7] = new JLabel("generate");
		labels[8] = new JLabel("view details");
		labels[9] = new JLabel("possible match found");


		for( int i = 0; i < 10; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
		
        passwordField = new JPasswordField(10);
        passwordField.setActionCommand(UI_Settings.getOk());
		
		
        List<JTextField> textfields = new ArrayList<JTextField>();
        @SuppressWarnings("rawtypes")
		List<JComboBox> comboboxes = new ArrayList<JComboBox>();
		
        
        final JTextField txtPrefDay = new JTextField(8);
        final JTextField txtRecomDay = new JTextField(8);
		final JTextField txtStartDate = new JTextField(12);
		JTextField txtStudentName = new JTextField(7);

        textfields.add(txtPrefDay);
        textfields.add(txtRecomDay);
        textfields.add(txtStartDate);
        textfields.add(txtStudentName);

		//textPrompt = new TextPrompt("0 / 5", txtListen);

        for(int i = 0; i < textfields.size(); i++){
        	
        	textfields.get(i).setEditable(true);
        	textfields.get(i).setMinimumSize(textfields.get(i).getPreferredSize());
        	textfields.get(i).setHorizontalAlignment(JTextField.LEFT);
        	
    		textPrompt = new TextPrompt("-", textfields.get(i));

        }
        
        
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		List<JTextField> textfieldsGroupDetails = new ArrayList<JTextField>();
		List<TextPrompt> textprompts = new ArrayList<TextPrompt>();

        
        int size = 13;
		
		JTextField txtGroupName = new JTextField(size);
		JTextField txtGroupID = new JTextField(size);
		JTextField txtGroupPos = new JTextField(size);
		JTextField txtGroupLev = new JTextField(size);
		JTextField txtGroupDay = new JTextField(size);
		JTextField txtGroupTime = new JTextField(size);
		JTextField txtGroupMax = new JTextField(size);
		JTextField txtGroupMat = new JTextField(size);

		
		textfieldsGroupDetails.add(txtGroupName); 
		textfieldsGroupDetails.add(txtGroupID); 
		textfieldsGroupDetails.add(txtGroupPos); 
		textfieldsGroupDetails.add(txtGroupLev); 
		textfieldsGroupDetails.add(txtGroupDay); 
		textfieldsGroupDetails.add(txtGroupTime); 
		textfieldsGroupDetails.add(txtGroupMax); 
		textfieldsGroupDetails.add(txtGroupMat); 

		
		for(int i = 0; i < textfieldsGroupDetails.size(); i++){
			
			textfieldsGroupDetails.get(i).setMinimumSize(textfieldsGroupDetails.get(i).getPreferredSize());
			textfieldsGroupDetails.get(i).setHorizontalAlignment(JTextField.LEFT);
			
			textPrompt = new TextPrompt("-", textfieldsGroupDetails.get(i));

		}
		/*********************************************************Create Combo Boxes*********************************************************/
		cmbWeeks.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbWeeks.setFont(UI_Settings.getComponentInputFontSize());
		cmbWeeks.setMinimumSize(cmbWeeks.getPreferredSize());
		//AutoCompletion.enable(cmbPreferredEmp_1, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbWeeks);

		cmbRequestBy.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbRequestBy.setFont(UI_Settings.getComponentInputFontSize());
		cmbRequestBy.setMinimumSize(cmbRequestBy.getPreferredSize());
		//AutoCompletion.enable(cmbPreferredEmp_1, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbRequestBy);
		
		cmbEventMonth.setPreferredSize(new Dimension(120, 27));
		cmbEventMonth.setFont(UI_Settings.getComponentInputFontSize());
		cmbEventMonth.getEditor().getEditorComponent().setBackground(Color.WHITE);
		//AutoCompletion.enable(cmbStartMonth, 120, 28);
		
		cmbGroupName.setPreferredSize(new Dimension(150, UI_Settings.getComboBoxHeight()));
		cmbGroupName.setFont(UI_Settings.getComponentInputFontSize());
		cmbGroupName.setMinimumSize(cmbGroupName.getPreferredSize());
		//AutoCompletion.enable(cmbGroupName, 150, UI_Settings.getComboBoxHeight());
		comboboxes.add(cmbGroupName);
		
		/****************************Create the canvas**************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/**********************Create the components panel***********************/
		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 120));
		detailsPanel.setLayout(new GridBagLayout());
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
		       int action = JOptionPane.showConfirmDialog(PossibleClasses.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		       
		       if(action == JOptionPane.OK_OPTION){
		    	   
		    	   cmbGroupName.setSelectedIndex(0);
				   failedMessage.setVisible(false);
				   failedMessage1.setVisible(false);
				   
				   txtAreaComments.setText("");
				   
				   txtStartDate.setText("");
				   txtPrefDay.setText("");
				   txtRecomDay.setText("");
				   passwordField.setText("");
				   
		       }
			}
		});
		/******************************************************Add the Reset Panel************************************************/
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(UI_Settings.getButtonPanelColor());
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		
		buttonPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		buttonPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 26, 10));
		leftPanel.setBackground(Color.WHITE);
		leftPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		leftPanel.add(failedMessage);
		
		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
		rightPanel.setBackground(UI_Settings.getComponentpanefillcolor());
		rightPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
		rightPanel.add(labels[0]);//Reset label
		
		leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		buttonPanel.add(leftPanel);
		
		rightPanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		buttonPanel.add(rightPanel);
		/******************************************************Add The Central Components************************************************/
		int containerHght = (int) (java.awt.Toolkit.getDefaultToolkit().getScreenSize().getHeight()/3*1.5);
		
		JPanel container = new JPanel(new GridBagLayout());
		setPanelSize(container, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, containerHght));
		container.setBackground(Color.WHITE);

			JPanel containerLeft = new JPanel(new GridBagLayout());
			setPanelSize(containerLeft, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, containerHght));
			containerLeft.setBackground(new Color(246,246,246));
			containerLeft.setBorder(border);
			
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(20,10,0,0);
				containerLeft.add(new JLabel("Click on the customers name to select:"),gc);
			
				gc.gridx = 0;
				gc.gridy = 0;
				gc.fill = GridBagConstraints.BOTH;
				gc.insets = new Insets(50,10,10,10);
				containerLeft.add(txtAreaEventList,gc);
			
				JPanel containerRight = new JPanel(new GridBagLayout());
				setPanelSize(containerRight, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, containerHght));
				containerRight.setBackground(new Color(251,248,202));
					
					int datesoffset = 20;
					int conRightWidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2;

					JPanel scheduleDatesContainer = new JPanel(new GridBagLayout());
					setPanelSize(scheduleDatesContainer, new Dimension(conRightWidth, centerTopHeight));
					scheduleDatesContainer.setBackground(Color.WHITE);

					JPanel datesLeft = new JPanel(new GridBagLayout());
					setPanelSize(datesLeft, new Dimension(conRightWidth/3, centerTopHeight));
					datesLeft.setBackground(Color.WHITE);
					datesLeft.setBorder(border);
				
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 0.1;
					gc.weighty = 0.1;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(0,5,0,5);
					datesLeft.add(new JLabel("Student Name:"), gc);
					
					gc.gridx = 1;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.insets = new Insets(0,-5,0,5);
					datesLeft.add(txtStudentName, gc);

					JPanel datesRight = new JPanel(new GridBagLayout());
					setPanelSize(datesRight, new Dimension(conRightWidth/3*2, centerTopHeight));
					datesRight.setBackground(new Color(246,246,246));
					datesRight.setBorder(border);
				
					gc.gridx = 0;
					gc.gridy = 0;
					gc.weightx = 0.1;
					gc.weighty = 0.1;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(0,2,0,20);
					datesRight.add(new JLabel("Preferred Day:"), gc);
					
					gc.gridx = 1;
					gc.weightx = 0.6;
					gc.weighty = 0.6;
					gc.insets = new Insets(0,-20,0,10);
					datesRight.add(txtPrefDay, gc);

					gc.gridx = 2;
					gc.weightx = 0.1;
					gc.weighty = 0.1;
					gc.insets = new Insets(0,0,0,15);
					datesRight.add(new JLabel("Recommended Level:"), gc);
					gc.gridx = 3;
					
					gc.weightx = 0.8;
					gc.weighty = 0.8;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.insets = new Insets(0,0,0,3);
					datesRight.add(txtRecomDay, gc);
					
			
					gc.gridx = 0;
					gc.gridy = 0;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(0,5,5,5);
					container.add(containerLeft, gc);
					
					gc.gridx = 0;
					scheduleDatesContainer.add(datesLeft, gc);
					
					gc.gridx = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.insets = new Insets(0,5,5,10);
					scheduleDatesContainer.add(datesRight, gc);
					
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridwidth = 2;
					gc.fill = GridBagConstraints.NONE;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(0,0,0,0);
					containerRight.add(scheduleDatesContainer, gc);
					
					//Add the lower components to containerRight - comments, possible match found, and find another match button//
					
					JPanel comments = new JPanel(new GridBagLayout());
					
					
					setPanelSize(comments, new Dimension(conRightWidth, centerTopHeight*2));
					comments.setBackground(new Color(246,246,246));
					comments.setBorder(border);
					
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 0.5;
					gc.weighty = 0.5;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(5,5,5,5);
					comments.add(new JLabel("Comments:"),gc);
					
					gc.gridx = 1;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(0,-10,0,2);
					comments.add(txtAreaComments, gc);
					
					int firstPanelHeight = UI_Settings.getSmallPanelHeight()-datesoffset;

					gc.insets = new Insets(firstPanelHeight-15,5,0,10);
					gc.gridwidth = 1;
					containerRight.add(comments, gc);
					
					////////////////////////////////////////////////////Add the group details panel////////////////////////////////////////////////////
					int topFrameHeight = 210;
					int centerTopHeight = 50;
					
					JPanel pnlCenterBottomRight = new JPanel(new GridBagLayout());
					
					setPanelSize(pnlCenterBottomRight, new Dimension((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3), topFrameHeight));
					pnlCenterBottomRight.setBackground(Color.WHITE);
					
							JPanel groupDetailsInfoTopButtons = new JPanel(new GridBagLayout());
							groupDetailsInfoTopButtons.setBackground(UI_Settings.getButtonPanelColor());
							setPanelSize(groupDetailsInfoTopButtons, new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
							
							groupDetailsInfoTopButtons.setBackground(Color.WHITE);

								JPanel lft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10,15));
								
								setPanelSize(lft, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getDetailsButtonPanelHeight()));
								
								lft.setBackground(Color.WHITE);
								lft.add(new JLabel("Possible Match Found:"));
								
								JPanel rght = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10,15));
								
								setPanelSize(rght, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getDetailsButtonPanelHeight()));
								rght.setBackground(Color.WHITE);
								rght.add(labels[9]);
								
							gc.gridx = 0;
							gc.gridy = 0;
							gc.gridheight = 1;
							gc.gridwidth = 1;
							gc.weightx = 1;
							gc.weighty = 1;
							gc.fill = GridBagConstraints.NONE;
							gc.anchor = GridBagConstraints.NORTHWEST;
							gc.insets = new Insets(0,0,0,0);	

							groupDetailsInfoTopButtons.add(lft, gc);	
							
							gc.gridx = 2;
							gc.gridy = 0;
							gc.gridheight = 1;
							gc.gridwidth = 1;
							gc.weightx = 1;
							gc.weighty = 1;
							gc.fill = GridBagConstraints.NONE;
							gc.anchor = GridBagConstraints.NORTHWEST;
							gc.insets = new Insets(0,0,0,0);	
							groupDetailsInfoTopButtons.add(rght, gc);	


		gc.gridx = 0;
		gc.gridy = 0;
		gc.weightx = 0.4;
		gc.weighty = 0.4;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(0,2,0,2);
		container.add(containerLeft,gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.weightx = 1;
		gc.weighty = 1;
		container.add(containerRight,gc);
		
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		/******************************************Generate request panel***************************************/
		
		JPanel trainingRequestsSavedPanel = new JPanel();
		trainingRequestsSavedPanel.setBackground(Color.WHITE);
		trainingRequestsSavedPanel.setLayout(new BoxLayout(trainingRequestsSavedPanel, BoxLayout.X_AXIS));
		
		trainingRequestsSavedPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		trainingRequestsSavedPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
		trainingRequestsSavedPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

		
		JPanel pnlGenLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
		pnlGenLeft.setBackground(Color.WHITE);
		pnlGenLeft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3*2, UI_Settings.getTableButtonsPanelHeight()));
		pnlGenLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getTableButtonsPanelHeight()));
		pnlGenLeft.add(new JLabel("Request made for: "));
		pnlGenLeft.add(cmbRequestBy);
		pnlGenLeft.add(labels[7]);

		
		JPanel pnlGenRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
		pnlGenRight.setBackground(Color.WHITE);
		pnlGenRight.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
		pnlGenRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
		pnlGenRight.add(chkMatchRequest);
		pnlGenRight.add(chkDeleteCustomer);

		
		pnlGenLeft.setAlignmentX(Component.LEFT_ALIGNMENT);
		trainingRequestsSavedPanel.add(pnlGenLeft);
		
		pnlGenRight.setAlignmentX(Component.RIGHT_ALIGNMENT);
		trainingRequestsSavedPanel.add(pnlGenRight);
		
		/*******************************************Message panel*************************************************************/
		//Begin Nested Details Panels (lowest panel on screen)
		JPanel pnlInformation = new JPanel();
		pnlInformation.setBackground(Color.WHITE);
		pnlInformation.setLayout(new GridBagLayout());
		
		setPanelSize(pnlInformation, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		

			//Create the far left container for the group details information
			JPanel pnlMessageContainer = new JPanel(new GridBagLayout());
			pnlMessageContainer.setBackground(Color.WHITE);
			
			setPanelSize(pnlMessageContainer, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-20));
			
			//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,0,0,0);
			
				//Add the nested panels to the container panel (information panel)
			
				JPanel pnlMessageArea = new JPanel(new GridBagLayout());
				pnlMessageArea.setBackground(Color.WHITE);
				Border informationBorder = BorderFactory.createLineBorder(Color.LIGHT_GRAY);
				//pnlMessageArea.setBorder(informationBorder);
				
				setPanelSize(pnlMessageArea, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-20));
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.BOTH;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,0,0,0);
				
				pnlMessageArea.add(txtAreaEmail, gc);
				
					int offset = 10;
				
					JPanel messageButtons = new JPanel();
					messageButtons.setBackground(UI_Settings.getButtonPanelColor());
					messageButtons.setLayout(new BoxLayout(messageButtons, BoxLayout.X_AXIS));
					
					setPanelSize(messageButtons, new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-offset));
					
					JPanel messageText = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 10));
					messageText.setBackground(Color.WHITE);
					messageText.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
					messageText.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
					messageText.add(new JLabel("Notifications for staff are automatically saved"));
					
					JPanel editButton = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
					editButton.setBackground(Color.WHITE);
					editButton.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
					editButton.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
					editButton.add(labels[2]);
	
					
					messageText.setAlignmentX(Component.LEFT_ALIGNMENT);
					messageButtons.add(messageText);
					
					editButton.setAlignmentX(Component.RIGHT_ALIGNMENT);
					messageButtons.add(editButton);
					
				gc.gridx = 0;
				gc.gridy = 1;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(-10,0,0,0);
				
				pnlMessageArea.add(messageButtons, gc);
				
				/////////////////////////////////////////
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(0,5,17,5);
			
				pnlMessageContainer.add(pnlMessageArea, gc);
				
		
		pnlInformation.add(pnlMessageContainer, gc);
		
		/////////////////////////////////////////
		gc.gridx = 0;
		gc.gridy = 0;
		gc.insets = new Insets(0,5,0,5);
	
		pnlMessageContainer.add(pnlMessageArea, gc);

				
		/******************************************************Create the Table Data Panel*******************************************/
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        buttonPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(buttonPanel);
        
        container.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(container);
        
        trainingRequestsSavedPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(trainingRequestsSavedPanel);
        
        centerPanel.add(Box.createVerticalStrut(5));
        
        pnlInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlInformation);
        
        pnlSaveInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
        centerPanel.add(pnlSaveInformation);
		
        /*********************************************************************************************************************************/
    	/////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 800));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 800));

		//Add the details section and table sections to the canvas.
		canvas.add(headerMessagePanel, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
		
		JScrollPane scroller = new JScrollPane(canvas);

		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());

		return scroller;
	}
	
	private void addNorthPanel() {
		JPanel heading = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		JLabel lblHeading = new JLabel("View customers on the waiting list");
		heading.setBackground(Color.WHITE);
		lblHeading.setFont(lblHeading.getFont().deriveFont(16.0f));
		heading.add(lblHeading);
		
		JPanel headingMessage = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		headingMessage.setBackground(Color.WHITE);
		JLabel lblHeadingMessage = new JLabel("Viewing waiting customers is simple. Select how far back to view from the combo to the right,\n"
				+ "click on the students name in the display area below and check for possible matches to the right of that.");
		
		headingMessage.add(lblHeadingMessage);

		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-30));
		detailsPanel.setLayout(new GridBagLayout());
		
		headerMessagePanel = new JPanel(new GridBagLayout());
		setPanelSize(headerMessagePanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 100));
		headerMessagePanel.setBackground(Color.WHITE);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		headerMessagePanel.add(heading,gc);
		
		gc.gridy = 1;
		gc.insets = new Insets(-15,0,0,0);
		headerMessagePanel.add(headingMessage, gc);
	
		gc.gridy = 2;
		gc.insets = new Insets(-30,0,0,0);
		headerMessagePanel.add(detailsPanel, gc);
		
		JPanel firstRow = new JPanel();
		firstRow.setBackground(UI_Settings.getButtonPanelColor());
		firstRow.setLayout(new BoxLayout(firstRow, BoxLayout.X_AXIS));
		
		JPanel fieldcontainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		fieldcontainer.setBackground(Color.WHITE);
		fieldcontainer.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 50));
		fieldcontainer.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 50));
		fieldcontainer.add(new JLabel("Select how far back you would like to view waiting customers:"));
		fieldcontainer.add(cmbWeeks);
		
		fieldcontainer.setAlignmentX(Component.LEFT_ALIGNMENT);
		firstRow.add(fieldcontainer);
		
		firstRow.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,30));
		firstRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 30));

		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(17,0,0,0);
		detailsPanel.add(firstRow, gc);
		
	}

	private void setPanelSize(JPanel container, Dimension dimension) {
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
	}
	
	private void addSouthPanel() {
		//Begin Nested Details Panels (lowest panel on screen)
		pnlSaveInformation = new JPanel();
		pnlSaveInformation.setBackground(Color.WHITE);
		pnlSaveInformation.setLayout(new GridBagLayout());
		pnlSaveInformation.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveInformation.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveInformation.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		
		//Begin Nested Details Panels (lowest panel on screen)
		JPanel pnlSaveRow = new JPanel();
		pnlSaveRow.setBackground(Color.WHITE);
		pnlSaveRow.setLayout(new GridBagLayout());
		pnlSaveRow.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));

			//Create the far left container for the group details information
			JPanel pnlSaveLeftPane = new JPanel(new GridBagLayout());
			pnlSaveLeftPane.setBackground(Color.WHITE);
			pnlSaveLeftPane.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			
			//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,0,0,0);
			
				//Add the nested panels to the container panel (information panel)
			
				JPanel panel3 = new JPanel(new GridBagLayout());
				panel3.setBackground(Color.WHITE);
				panel3.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				
				
				JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row1.setBackground(Color.WHITE);
				row1.add(new JLabel("Table updated:"));
				row1.add(lblDate);
				
				JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row2.setBackground(Color.WHITE);
				row2.add(new JLabel("Connected to: " /*+ controller.getDBname()*/));
				
				JPanel row3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row3.setBackground(Color.WHITE);
				row3.add(new JLabel("Connection: Secure"));
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(5,5,0,5);
			
				panel3.add(row1, gc);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.insets = new Insets(0,5,0,5);
			
				panel3.add(row2, gc);
				
				gc.gridx = 0;
				gc.gridy = 2;
				gc.insets = new Insets(0,5,45,5);
			
				panel3.add(row3, gc);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.insets = new Insets(0,5,20,5);
			
				pnlSaveLeftPane.add(panel3, gc);
		
		pnlSaveRow.add(pnlSaveLeftPane, gc);
			
		//Create the second panel from the left (comments panel)
		JPanel pnlSaveRight = new JPanel(new GridBagLayout());
		pnlSaveRight.setBackground(Color.WHITE);
		pnlSaveRight.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));

			gc.gridx = 1;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHEAST;
			gc.insets = new Insets(0,0,0,0);
			pnlSaveRight.add(btnDeleteEvent, gc);
			
			pnlSaveRow.add(pnlSaveRight, gc);
		
		pnlSaveInformation.add(pnlSaveRow, gc);
	}
	
}
