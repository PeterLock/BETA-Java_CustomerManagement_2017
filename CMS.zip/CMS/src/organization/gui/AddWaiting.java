package organization.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;

import control.build.TableTemplate;
import settings.UI_Settings;
import utilities.JTextFieldLimit;
import utilities.SentryModule;
import utilities.TextPrompt;
import utilities.UniqueIDGenerator;

@SuppressWarnings("serial")
public class AddWaiting extends JPanel {
	
	static JTabbedPane pane = new JTabbedPane();
	private TextPrompt textPrompt;
    private JPasswordField passwordField;	private JPanel headerMessagePanel;
	private JPanel detailsPanel;
    private int centerTopHeight = 50;
	private JComboBox<?> cmbAge = new JComboBox<Object>(UI_Settings.getStudentAge());
	private JComboBox<?> cmbPrefDay1 = new JComboBox<Object>(UI_Settings.getDays());
	private JComboBox<?> cmbRecommendLvl = new JComboBox<Object>(UI_Settings.getBooks());
	private JComboBox<?> cmbUpperLvl = new JComboBox<Object>(UI_Settings.getBooks());
	private JButton btnAddWaitingCustomer = new JButton("Add Waiting Customer");

	
	private JComboBox<?> cmbMonth1 = new JComboBox<Object>(UI_Settings.getMonths());
	private JComboBox<?> cmbMonth2 = new JComboBox<Object>(UI_Settings.getMonths());
	private JComboBox<?> cmbDate1 = new JComboBox<Object>(UI_Settings.getDates());
	private JComboBox<?> cmbDate2 = new JComboBox<Object>(UI_Settings.getDates());
	
	private JPanel pnlSaveInformation;
	private Calendar c = Calendar.getInstance();
	private JLabel lblDate = new JLabel(c.getTime().toString());
	private JTextField txtFirstName = new JTextField(10);
	private JTextField txtLastName = new JTextField(10);
	private List <JTextField> regular_textfields = new ArrayList<JTextField>();
	private GridBagConstraints gc = new GridBagConstraints();


    JFrame controllingFrame; //needed for dialogs
    
	/**********************************************************************************************************************************/
	////////////Add Student Waiting to Join Table////////////////////
	TD_Waiting TD_AddStudentWaiting = new TD_Waiting();
	TableTemplate waitingTable = new TableTemplate(TD_AddStudentWaiting, TD_AddStudentWaiting.getCOLUMN_PERCENTAGES(), "");
	
	/**********************************************************************************************************************************/

	
	public AddWaiting(){
		
	}
	
	public Component run(){
		JScrollPane scroller = initialize();
		return scroller;
	}

	private JScrollPane initialize() {
		JPanel canvas;
		JPanel detailsPanel;
		JPanel centerPanel;
		JPanel trainingRequestsSavedPanel;
		JPanel pnlGenLeft;
		JPanel pnlGenRight;
		
		/******************************************************Add the north panel************************************************/

		addNorthPanel();
		addSouthPanel();
		
		btnAddWaitingCustomer.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnAddWaitingCustomer.setFont(UI_Settings.getComponentInputFontSize());

		/******************************************************Initialize Fields**************************************************/
		regular_textfields.add(txtFirstName);
		regular_textfields.add(txtLastName);

		for(int i = 0; i < regular_textfields.size(); i++){
			regular_textfields.get(i).setMinimumSize(regular_textfields.get(i).getPreferredSize());
		}
		
		JLabel failedMessage = new JLabel(UI_Settings.getFailedMessage());
		failedMessage.setForeground(UI_Settings.getFailedMessageColor());
		
        passwordField = new JPasswordField(10);
        passwordField.setActionCommand(UI_Settings.getOk());
	
		failedMessage.setVisible(false);
		
		JLabel[] labels = new JLabel[3];
		
		labels[0] = new JLabel("reset fields");
		labels[1] = new JLabel("delete customer waiting");
		labels[2] = new JLabel("hint");
	
		for(int i = 0; i < 3; i++){
			labels[i].setForeground(UI_Settings.getComponentsFontColorLight());
			labels[i].setCursor(UI_Settings.getJlabelCursor());
		}
	
		JButton btnSave = new JButton("Save");
		btnSave.setPreferredSize(UI_Settings.getJbuttonSize());
		btnSave.setFont(UI_Settings.getComponentInputFontSize());
		
		/******************************************************Create TextFields*************************************************************/
		JTextField txtFirstName = new JTextField(10);
		JTextField txtLastName = new JTextField(10);
		
		JTextField txtWaitingID = new JTextField(10);
		JTextField dateTextField = new JTextField(10);
		
		txtFirstName.setEnabled(true);
		txtFirstName.setMinimumSize(txtFirstName.getPreferredSize());
		txtFirstName.setHorizontalAlignment(JTextField.CENTER);
		//textPrompt = new TextPrompt("<first name>", txtFirstName);

		txtLastName.setEnabled(true);
		txtLastName.setMinimumSize(txtLastName.getPreferredSize());
		txtLastName.setHorizontalAlignment(JTextField.CENTER);
		//textPrompt = new TextPrompt("<last name>", txtLastName);
		
		Border border = BorderFactory.createLineBorder(new Color(224,224,224));
		/******************************************************Create TextAreas*************************************************************/
	
		
		JTextArea txtAreaComments = new JTextArea(4, 33);
		txtAreaComments.setMinimumSize(txtAreaComments.getPreferredSize());
		txtAreaComments.setEditable(true);
		txtAreaComments.setBorder(border);
		txtAreaComments.setWrapStyleWord(true);
		txtAreaComments.setLineWrap(true);
		txtAreaComments.setDocument(new JTextFieldLimit(150));
		textPrompt = new TextPrompt("<add comments for this customer>", txtAreaComments);
		
		/****************************************************Create ComboBoxes**************************************************************/
		
		cmbAge.setPreferredSize(new Dimension(120, UI_Settings.getComboBoxHeight()));
		cmbAge.setFont(UI_Settings.getComponentInputFontSize());
		cmbAge.setMinimumSize(cmbAge.getPreferredSize());
		//AutoCompletion.enable(cmbAge, 120, UI_Settings.getComboBoxHeight());
	
		cmbPrefDay1.setPreferredSize(new Dimension(120, UI_Settings.getComboBoxHeight()));
		cmbPrefDay1.setFont(UI_Settings.getComponentInputFontSize());
		cmbPrefDay1.setMinimumSize(cmbPrefDay1.getPreferredSize());
		//AutoCompletion.enable(cmbPrefDay1, 120, UI_Settings.getComboBoxHeight());
	
		cmbRecommendLvl.setFont(UI_Settings.getComponentInputFontSize());
		cmbRecommendLvl.setPreferredSize(new Dimension(120, UI_Settings.getComboBoxHeight()));
		cmbRecommendLvl.setMinimumSize(cmbRecommendLvl.getPreferredSize());
		//AutoCompletion.enable(cmbRecommendLvl, 120, UI_Settings.getComboBoxHeight());
		
		cmbUpperLvl.setFont(UI_Settings.getComponentInputFontSize());
		cmbUpperLvl.setPreferredSize(new Dimension(120, UI_Settings.getComboBoxHeight()));
		cmbUpperLvl.setMinimumSize(cmbUpperLvl.getPreferredSize());
		//AutoCompletion.enable(cmbUpperLvl, 120, UI_Settings.getComboBoxHeight());
		
		/***********************************************************************************************************************************/
		canvas = new JPanel();
		canvas.setLayout( new BorderLayout(0,0) ); //0,0 sets the margins between panels
		/**********************Create the components panel***********************/
		int offset = 25;

		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()+offset*2));
		detailsPanel.setLayout(new GridBagLayout());
		
			JPanel leftTopPanel = new JPanel(new GridBagLayout());
			setPanelSize(leftTopPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()));
			leftTopPanel.setBackground(Color.WHITE);
			
			
			JPanel custInfo = new JPanel(new GridBagLayout());
			setPanelSize(custInfo, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getSmallPanelHeight()-offset));
			custInfo.setBorder(border);
			custInfo.setBackground(new Color(246,246,246));
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,0);
				custInfo.add(new JLabel("First Name:"),gc);
				
				gc.gridx = 1;
				gc.gridy = 0;
				gc.weightx = 0.5;
				gc.weighty = 0.5;
				gc.insets = new Insets(0,0,0,0);
				custInfo.add(txtFirstName,gc);
				
				gc.gridx = 2;
				gc.gridy = 0;
				gc.insets = new Insets(0,10,0,0);
				custInfo.add(new JLabel("Last Name:"),gc);
				
				gc.gridx = 3;
				gc.gridy = 0;
				custInfo.add(txtLastName,gc);
				
				gc.gridx = 4;
				gc.gridy = 0;
				gc.insets = new Insets(0,10,0,0);
				custInfo.add(new JLabel("Preferred Day 1:"),gc);
				
				gc.gridx = 5;
				gc.gridy = 0;
				gc.insets = new Insets(0,0,0,5);
				custInfo.add(cmbPrefDay1,gc);
			
			
			JPanel waitLeft = new JPanel(new GridBagLayout());
			setPanelSize(waitLeft, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getSmallPanelHeight()-offset));
			waitLeft.setBorder(border);
			waitLeft.setBackground(Color.WHITE);
			
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,0);
				waitLeft.add(new JLabel("Waiting From:"),gc);
				
				gc.gridx = 2;
				gc.gridy = 0;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,0,0,0);
				waitLeft.add(cmbMonth1,gc);
				
				gc.gridx = 3;
				gc.gridy = 0;
				gc.insets = new Insets(0,0,0,0);
				waitLeft.add(cmbDate1,gc);
				
			
			JPanel waitRight = new JPanel(new GridBagLayout());
			setPanelSize(waitRight, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getSmallPanelHeight()-offset));
			waitRight.setBorder(border);
			waitRight.setBackground(Color.WHITE);
			
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,0);
				waitRight.add(new JLabel("Waiting Until:"),gc);
				
				gc.gridx = 2;
				gc.gridy = 0;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,0,0,0);
				waitRight.add(cmbMonth2,gc);
				
				gc.gridx = 3;
				gc.gridy = 0;
				gc.insets = new Insets(0,0,0,0);
				waitRight.add(cmbDate2,gc);

			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 2;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(0,0,0,0);
			
			leftTopPanel.add(custInfo, gc);
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(5,0,0,5);
			leftTopPanel.add(waitLeft, gc);
			
			gc.gridx = 1;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(5,0,0,5);
			leftTopPanel.add(waitRight, gc);
			
			
			
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(10,5,5,5);
		detailsPanel.add(leftTopPanel, gc);
		
		
		
		JPanel rightTopPanel = new JPanel(new GridBagLayout());
		setPanelSize(rightTopPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()));
		rightTopPanel.setBackground(Color.WHITE);
		
				JPanel resetPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10,12));
				setPanelSize(resetPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getDetailsButtonPanelHeight()));
				resetPanel.setBackground(Color.WHITE);
				resetPanel.add(labels[0]);
			
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.SOUTHWEST;
				gc.insets = new Insets(40,10,0,0);
				rightTopPanel.add(resetPanel,gc);
		
			JPanel materialPanel = new JPanel(new GridBagLayout());
			setPanelSize(materialPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getSmallPanelHeight()-offset));
			materialPanel.setBorder(border);
			materialPanel.setBackground(Color.WHITE);
			
				gc.gridx = 1;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 0.1;
				gc.weighty = 0.1;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,10,0,0);
				materialPanel.add(new JLabel("Upper Level:"),gc);
				
				gc.gridx = 2;
				gc.gridy = 0;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,0,0,20);
				materialPanel.add(cmbUpperLvl,gc);
			
			
			gc.gridx = 0;
			gc.gridy = 1;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.HORIZONTAL;
			gc.anchor = GridBagConstraints.SOUTHWEST;
			gc.insets = new Insets(-8,0,8,0);
			rightTopPanel.add(materialPanel, gc);
		
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.2;
		gc.weighty = 0.2;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.SOUTHWEST;
		gc.insets = new Insets(5,5,5,10);
		detailsPanel.add(rightTopPanel, gc);
		/***********************************************************************************************************************************/
		///////////////Add the comments panel/////////////////
		JPanel commentsPanel = new JPanel(new GridBagLayout());
		setPanelSize(commentsPanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, centerTopHeight*2));
		commentsPanel.setBackground(Color.PINK);
		
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 0.5;
			gc.weighty = 0.5;
			gc.fill = GridBagConstraints.BOTH;
			gc.anchor = GridBagConstraints.NORTHWEST;
			gc.insets = new Insets(5,5,5,5);
			commentsPanel.add(txtAreaComments, gc);
		
			/***********************************************************************************************************************************/
			//Add the password panel
			
			trainingRequestsSavedPanel = new JPanel();
			trainingRequestsSavedPanel.setBackground(UI_Settings.getButtonPanelColor());
			trainingRequestsSavedPanel.setLayout(new BoxLayout(trainingRequestsSavedPanel, BoxLayout.X_AXIS));
			trainingRequestsSavedPanel.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
			trainingRequestsSavedPanel.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));
			trainingRequestsSavedPanel.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()));

			pnlGenLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 10,10));
			pnlGenLeft.setBackground(Color.WHITE);
			pnlGenLeft.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			pnlGenLeft.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			//pnlGenLeft.add(new JLabel("something goes here"));
			
			pnlGenRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10,10));
			pnlGenRight.setBackground(Color.WHITE);
			pnlGenRight.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			pnlGenRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getTableButtonsPanelHeight()));
			//pnlGenRight.add(new JLabel("and here"));
			
			pnlGenLeft.setAlignmentX(Component.LEFT_ALIGNMENT);
			trainingRequestsSavedPanel.add(pnlGenLeft);
			
			pnlGenRight.setAlignmentX(Component.RIGHT_ALIGNMENT);
			trainingRequestsSavedPanel.add(pnlGenRight);
			
			/*******************************************Message panel*************************************************************/
			//Begin Nested Details Panels (lowest panel on screen)
			JPanel pnlInformation = new JPanel();
			pnlInformation.setBackground(Color.WHITE);
			pnlInformation.setLayout(new GridBagLayout());
			
			setPanelSize(pnlInformation, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
			
	
				//Create the far left container for the group details information
				JPanel pnlMessageContainer = new JPanel(new GridBagLayout());
				pnlMessageContainer.setBackground(Color.WHITE);
				
				setPanelSize(pnlMessageContainer, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3*2, UI_Settings.getRegularPanelHeight()-20));
				
				//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.gridheight = 1;
				gc.gridwidth = 1;
				gc.weightx = 1;
				gc.weighty = 1;
				gc.fill = GridBagConstraints.HORIZONTAL;
				gc.anchor = GridBagConstraints.WEST;
				gc.insets = new Insets(0,0,0,0);
				
					//Add the nested panels to the container panel (information panel)
				
					JPanel pnlMessageArea = new JPanel(new GridBagLayout());
					pnlMessageArea.setBackground(Color.WHITE);
					Border informationBorder = BorderFactory.createLineBorder(Color.LIGHT_GRAY);
					//pnlMessageArea.setBorder(informationBorder);
					
					setPanelSize(pnlMessageArea, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getRegularPanelHeight()-20));
					
					gc.gridx = 0;
					gc.gridy = 0;
					gc.weightx = 0.1;
					gc.weighty = 0.1;
					gc.fill = GridBagConstraints.BOTH;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(0,0,0,0);
					
					//pnlMessageArea.add(txtAreaEmail, gc);
					
						int offset2 = 10;
					
						JPanel messageButtons = new JPanel();
						messageButtons.setBackground(UI_Settings.getButtonPanelColor());
						messageButtons.setLayout(new BoxLayout(messageButtons, BoxLayout.X_AXIS));
						
						setPanelSize(messageButtons, new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getDetailsButtonPanelHeight()-offset2));
						
						JPanel messageText = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 10));
						messageText.setBackground(Color.RED);
						messageText.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
						messageText.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
						//messageText.add(new JLabel("Match Alert Requests are automatically saved"));
						
						JPanel editButton = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
						editButton.setBackground(Color.PINK);
						editButton.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
						editButton.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/3, UI_Settings.getTableButtonsPanelHeight()));
						editButton.add(labels[2]);
		
						
						messageText.setAlignmentX(Component.LEFT_ALIGNMENT);
						messageButtons.add(messageText);
						
						editButton.setAlignmentX(Component.RIGHT_ALIGNMENT);
						messageButtons.add(editButton);
						
					gc.gridx = 0;
					gc.gridy = 1;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 0.1;
					gc.weighty = 0.1;
					gc.fill = GridBagConstraints.HORIZONTAL;
					gc.anchor = GridBagConstraints.WEST;
					gc.insets = new Insets(-10,0,0,0);
					
					pnlMessageArea.add(messageButtons, gc);
					
					/////////////////////////////////////////
					gc.gridx = 0;
					gc.gridy = 0;
					gc.gridheight = 1;
					gc.gridwidth = 1;
					gc.weightx = 1;
					gc.weighty = 1;
					gc.anchor = GridBagConstraints.NORTHWEST;
					gc.insets = new Insets(0,5,17,5);
				
					pnlMessageContainer.add(pnlMessageArea, gc);
					
			
			pnlInformation.add(pnlMessageContainer, gc);
			
			/////////////////////////////////////////
			gc.gridx = 0;
			gc.gridy = 0;
			gc.insets = new Insets(0,5,0,5);
		
			pnlMessageContainer.add(pnlMessageArea, gc);
			
		/**********************************Setting the actions for the RESET and GENERATE ID buttons***********************************/
		
		labels[0].addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
				
		       int action = JOptionPane.showConfirmDialog(AddWaiting.this, UI_Settings.getResetPrompt(), UI_Settings.getResetHeader(), JOptionPane.OK_CANCEL_OPTION);
		       
		       if(action == JOptionPane.OK_OPTION){
		   		txtFirstName.setText("");
				txtWaitingID.setText("");
				txtLastName.setText("");
				txtWaitingID.setText("");
				dateTextField.setText("");
				txtAreaComments.setText(""); 
				cmbAge.setSelectedIndex(0);
				cmbPrefDay1.setSelectedIndex(0);
				cmbRecommendLvl.setSelectedIndex(0);
				cmbUpperLvl.setSelectedIndex(0);
				
		       }
			}
		});
	
		/********************************************************Set the Table Objects Sizes**************************************************/
	
		waitingTable.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*11)));
		waitingTable.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getTableHeaderHeight()+(UI_Settings.getTableRowHeight()*11)));
		
		/******************************************************Create the Table Data Panel************************************************/
		centerPanel = new JPanel();
		centerPanel.setBackground(UI_Settings.getButtonPanelColor());
	    centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
    
	    commentsPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(commentsPanel);  
	    
	    waitingTable.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(waitingTable);
	    
/*	    trainingRequestsSavedPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(trainingRequestsSavedPanel);*/
	
/*	    pnlInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(pnlInformation);*/
	    
	    pnlSaveInformation.setAlignmentY(Component.LEFT_ALIGNMENT);
	    centerPanel.add(pnlSaveInformation);
	    
		/////////////////////////////Needed to make sure the scroll bar and GridBagLayout work together perfectly////////////////////////////
		canvas.setMaximumSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 750));
		canvas.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 750));
		
		JScrollPane scroller = new JScrollPane(canvas);

		scroller.getVerticalScrollBar().setPreferredSize(new Dimension(UI_Settings.getScrollbarWidth(), Integer.MAX_VALUE));
		scroller.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, UI_Settings.getScrollbarWidth()));
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setBorder(BorderFactory.createEmptyBorder());		
		canvas.add(headerMessagePanel, BorderLayout.NORTH);
		canvas.add(centerPanel, BorderLayout.CENTER);
	
		scroller.getVerticalScrollBar().setUnitIncrement(UI_Settings.getScrollBarSpeed());
		
		return scroller;
	}
	
	private void addSouthPanel() {
		//Begin Nested Details Panels (lowest panel on screen)
		pnlSaveInformation = new JPanel();
		pnlSaveInformation.setBackground(Color.WHITE);
		pnlSaveInformation.setLayout(new GridBagLayout());
		pnlSaveInformation.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveInformation.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveInformation.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		
		//Begin Nested Details Panels (lowest panel on screen)
		JPanel pnlSaveRow = new JPanel();
		pnlSaveRow.setBackground(Color.WHITE);
		pnlSaveRow.setLayout(new GridBagLayout());
		pnlSaveRow.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));
		pnlSaveRow.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getRegularPanelHeight()-10));

			//Create the far left container for the group details information
			JPanel pnlSaveLeftPane = new JPanel(new GridBagLayout());
			pnlSaveLeftPane.setBackground(Color.WHITE);
			pnlSaveLeftPane.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			pnlSaveLeftPane.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()-20));
			
			//////////////////////////////////////////Main Column 1 ///////////////////////////////////////////
			
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.anchor = GridBagConstraints.WEST;
			gc.insets = new Insets(0,0,0,0);
			
				//Add the nested panels to the container panel (information panel)
			
				JPanel panel3 = new JPanel(new GridBagLayout());
				panel3.setBackground(Color.WHITE);
				panel3.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				panel3.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()));
				
				
				JPanel row1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row1.setBackground(Color.WHITE);
				row1.add(new JLabel("Table updated:"));
				row1.add(lblDate);
				
				JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row2.setBackground(Color.WHITE);
				row2.add(new JLabel("Connected to: " /*+ controller.getDBname()*/));
				
				JPanel row3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
				row3.setBackground(Color.WHITE);
				row3.add(new JLabel("Connection: Secure"));
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.fill = GridBagConstraints.NONE;
				gc.anchor = GridBagConstraints.NORTHWEST;
				gc.insets = new Insets(5,5,0,5);
			
				panel3.add(row1, gc);
				
				gc.gridx = 0;
				gc.gridy = 1;
				gc.insets = new Insets(0,5,0,5);
			
				panel3.add(row2, gc);
				
				gc.gridx = 0;
				gc.gridy = 2;
				gc.insets = new Insets(0,5,45,5);
			
				panel3.add(row3, gc);
				
				gc.gridx = 0;
				gc.gridy = 0;
				gc.insets = new Insets(0,5,20,5);
			
				pnlSaveLeftPane.add(panel3, gc);
		
		pnlSaveRow.add(pnlSaveLeftPane, gc);
			
		//Create the second panel from the left (comments panel)
		JPanel pnlSaveRight = new JPanel(new GridBagLayout());
		pnlSaveRight.setBackground(Color.WHITE);
		pnlSaveRight.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));
		pnlSaveRight.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/2, UI_Settings.getRegularPanelHeight()+10));

			gc.gridx = 1;
			gc.gridy = 0;
			gc.gridheight = 1;
			gc.gridwidth = 1;
			gc.weightx = 1;
			gc.weighty = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.NORTHEAST;
			gc.insets = new Insets(0,0,0,0);
			pnlSaveRight.add(btnAddWaitingCustomer, gc);
			
			pnlSaveRow.add(pnlSaveRight, gc);
		
		pnlSaveInformation.add(pnlSaveRow, gc);
	}

	private void addNorthPanel() {
		JPanel heading = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		JLabel lblHeading = new JLabel("Add a customers to the waiting list");
		heading.setBackground(Color.WHITE);
		lblHeading.setFont(lblHeading.getFont().deriveFont(16.0f));
		heading.add(lblHeading);
		
		JPanel headingMessage = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
		headingMessage.setBackground(Color.WHITE);
		JLabel lblHeadingMessage = new JLabel("Adding customers to the waiting list is a snap. Just fill in all the details below dnd hit enter."
				+ "Customers waiting for more than 29 days will be automatically removed from the system");
		
		headingMessage.add(lblHeadingMessage);

		detailsPanel = new JPanel();
		detailsPanel.setBackground(Color.WHITE);
		detailsPanel.setPreferredSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, UI_Settings.getSmallPanelHeight()-30));
		detailsPanel.setLayout(new GridBagLayout());
		
		headerMessagePanel = new JPanel(new GridBagLayout());
		setPanelSize(headerMessagePanel, new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 100));
		headerMessagePanel.setBackground(Color.WHITE);
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.gridheight = 1;
		gc.gridwidth = 1;
		gc.weightx = 0.5;
		gc.weighty = 0.5;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.NORTHWEST;
		gc.insets = new Insets(0,0,0,0);
		headerMessagePanel.add(heading,gc);
		
		gc.gridy = 1;
		gc.insets = new Insets(-15,0,0,0);
		headerMessagePanel.add(headingMessage, gc);
	
		gc.gridy = 2;
		gc.insets = new Insets(-30,0,0,0);
		headerMessagePanel.add(detailsPanel, gc);
		
		JPanel firstRow = new JPanel();
		firstRow.setBackground(UI_Settings.getButtonPanelColor());
		firstRow.setLayout(new BoxLayout(firstRow, BoxLayout.X_AXIS));
		
		JPanel fieldcontainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
		fieldcontainer.setBackground(Color.WHITE);
		fieldcontainer.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width, 50));
		fieldcontainer.setMaximumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 50));
		fieldcontainer.add(new JLabel("First Name:"));
		fieldcontainer.add(txtFirstName);
		fieldcontainer.add(new JLabel("Last Name:"));
		fieldcontainer.add(txtLastName);
		fieldcontainer.add(new JLabel("Age:"));
		fieldcontainer.add(cmbAge);
		fieldcontainer.add(new JLabel("Recommended Level:"));
		fieldcontainer.add(cmbRecommendLvl);
		
		fieldcontainer.setAlignmentX(Component.LEFT_ALIGNMENT);
		firstRow.add(fieldcontainer);
		
		firstRow.setPreferredSize(new Dimension(UI_Settings.getMinimumScreenSize().width,30));
		firstRow.setMinimumSize(new Dimension(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, 30));

		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 1;
		gc.weightx = 1;
		gc.weighty = 1;
		gc.fill = GridBagConstraints.HORIZONTAL;
		gc.anchor = GridBagConstraints.WEST;
		gc.insets = new Insets(17,0,0,0);
		detailsPanel.add(firstRow, gc);
		
	}
	
	private void setPanelSize(JPanel container, Dimension dimension) {
		
		container.setPreferredSize(dimension);
		container.setMinimumSize(dimension);
		container.setMaximumSize(dimension);
		
	}

}
