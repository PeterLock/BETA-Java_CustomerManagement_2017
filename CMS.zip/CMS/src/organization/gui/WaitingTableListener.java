package organization.gui;

public interface WaitingTableListener {
	public void rowDeleted(int row);
}
