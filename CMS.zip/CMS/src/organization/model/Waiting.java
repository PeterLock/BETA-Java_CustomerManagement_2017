package organization.model;

import java.io.Serializable;

public class Waiting implements Serializable{
	
	private int id;
	private String firstName;
	private String lastName;
	private int age;
	private String recommendedLevel;
	private String comments;
	private String waitingFrom;
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getRecommendedLevel() {
		return recommendedLevel;
	}

	public void setRecommendedLevel(String recommendedLevel) {
		this.recommendedLevel = recommendedLevel;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}


	public String getWaitingFrom() {
		return waitingFrom;
	}

	public void setWaitingFrom(String waitingFrom) {
		this.waitingFrom = waitingFrom;
	}



	public Waiting(int id, String firstName, String lastName, int age, String recommendedLevel, String comments, String waitingFrom) {
		
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.recommendedLevel = recommendedLevel;
		this.comments = comments;
		this.waitingFrom = waitingFrom;
		
	}

}
