package organization.model;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Database {
	
	private List<Waiting> waiting_list = new ArrayList<Waiting>();
	private List<Waiting> loaded_waiting_list = new ArrayList<Waiting>();
	@SuppressWarnings("unused")
	private int flag = 0;

	private List<Waiting> addnew_waiting;
	private List<Waiting> viewall_waiting;

	private int setNumberOfRows = 0;
	private int setViewAllRowNumber = 0;
	
	@SuppressWarnings("unused")
	private int setAddWaitingRowNumber = 4;
	@SuppressWarnings("unused")
	private int setViewAllWaitingRowNumber = 0;
	
	private int count = 0;
	private Connection con;
	
	public Database(){
		waiting_list = new ArrayList<Waiting>();
		loaded_waiting_list = new ArrayList<Waiting>();
	}
	
	public void connect() throws Exception{
		
	    con = null;
	    try {
	      Class.forName("org.sqlite.JDBC");
	      con = DriverManager.getConnection("jdbc:sqlite:CMS_DB.db");
	    } catch ( Exception e ) {
	      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
	      System.exit(0);
	    }
	    System.out.println("Opened waiting database successfully");
	}
	
	public void disconnect(){
		if(con != null){
			try {
				con.close();
				System.out.println("Closed waiting database successfully");
			} catch (SQLException e) {
				System.out.println("Can't close the connection");
			}
		}
	}
	
	public void save() throws SQLException{
		
		String checkSql = "select count(*) as count from WaitingList where id=?";
		PreparedStatement checkStmt = con.prepareStatement(checkSql);
		
		String insertSql = "insert into WaitingList (id, firstName, lastName, age, recommendedLevel, comments, waitingFromDate) values (?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement insertStatement = con.prepareStatement(insertSql);
		

		String updateSql = "update WaitingList set firstName=?, lastName=?, age=?, recommendedLevel=?, comments=?, waitingFromDate=? where id=?";
		PreparedStatement updateStatement = con.prepareStatement(updateSql);
		
		for(Waiting waiting : waiting_list){
			
			int t = waiting.getId();
			if(t > 0){
				
				int id = waiting.getId();
				String firstName = waiting.getFirstName();
				String lastName = waiting.getLastName();
				int age = waiting.getAge();
				String recommendedLevel = waiting.getRecommendedLevel();
				String comments = waiting.getComments();
				String waitingFromDate = waiting.getWaitingFrom();
				
				checkStmt.setInt(1, id);
				
				ResultSet checkResult = checkStmt.executeQuery();
				checkResult.next();
				
				int count = checkResult.getInt(1);
				
				
				if(count == 0){
					System.out.println("Inserting material with ID " + id);
					
					int col = 1;

					insertStatement.setInt(col++, id);
					insertStatement.setString(col++, firstName);
					insertStatement.setString(col++, lastName);
					insertStatement.setInt(col++, age);
					insertStatement.setString(col++, recommendedLevel);
					insertStatement.setString(col++, comments);
					insertStatement.setString(col++, waitingFromDate);

					insertStatement.executeUpdate();

				}
				else{
					System.out.println("Updating customer with ID " + id);
					
					int col = 1;
					
					updateStatement.setString(col++, firstName);
					updateStatement.setString(col++, lastName);
					updateStatement.setInt(col++, age);
					updateStatement.setString(col++, recommendedLevel);
					updateStatement.setString(col++, comments);
					updateStatement.setString(col++, waitingFromDate);
					
					updateStatement.setInt(col++, id);
					
					updateStatement.executeUpdate();
				}
			}
		}
		updateStatement.close();
		insertStatement.close();
		checkStmt.close();
		
	}
	
	public void load(){
		
	}
	
	public void addNewWaiting(Waiting waiting){
		
		if(this.waiting_list.size()==setNumberOfRows){
			this.waiting_list.add(0, waiting);
			this.waiting_list.remove(this.waiting_list.get(this.getEmptyWaiting().size()-1));
		}else{
			if(count >setNumberOfRows){
				this.waiting_list.add(0, waiting);
			}else{
				this.waiting_list.add(0, waiting);
				count++;	
			}
		}
		
		try {
			this.save();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void addEmptyWaiting(Waiting waiting){
		
	}
	
	public void printWaiting(){
		
	}
	
	public void saveToFile(File file) throws IOException{
		FileOutputStream fos = new FileOutputStream(file);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		Waiting[] waiting = this.waiting_list.toArray(new Waiting[this.waiting_list.size()]);
		
		oos.writeObject(waiting);
		
		fos.close();
		oos.close();
		
	}
	
	public void loadFromFile(File file) throws IOException {
		
	}
	
	public void removeWaiting(int index, int i){
		if(index <0){
			return;
		}else{
			if( i == 1){
				int remove_id = viewall_waiting.get(index).getId();
				
				viewall_waiting.remove(index);

				populateRemainingWaitingRows(viewall_waiting, setViewAllRowNumber);
				
				delete(remove_id);
				
				try {
					this.save();
				} catch (SQLException e) {
					System.err.println("Unable to save database");
				}

			}
			if( i == 2){
				addnew_waiting.remove(index);
				populateRemainingWaitingRows(addnew_waiting, setNumberOfRows);			
			}
		}
	}
	
	
	public void populateRemainingWaitingRows(List<Waiting> data, int j) {
       	for(int i = data.size()+1; i <=j; i++){
       		data.add(new Waiting(0,"","",0,"","", ""));
    	}
	}
	
	public void delete(int remove_id){
		
	}
	
	public void setAddNewRowNumber(int i) {
		setNumberOfRows = i;
	}

	public List<Waiting> getWaiting() {
		return loaded_waiting_list;
	}
	
	public List<Waiting> getEmptyWaiting() {
		return waiting_list;
	}
	
	public void populateRemainingRows(List<Waiting> data, int j) {
		
       	for(int i = data.size()+1; i <=j; i++){
       		data.add(new Waiting(0,"","",0,"","", ""));
    	}
	}

	public String getName() {
		return "CIS_DB";
	}
	
	public Waiting searchWaiting(String waitingName){
		return null;
	}
	
	public void addNewWaitingRowNumber(int rows) {
		setAddWaitingRowNumber = rows;
	}
}
