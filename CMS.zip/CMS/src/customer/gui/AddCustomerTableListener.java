package customer.gui;

public interface AddCustomerTableListener {
	public void rowDeleted(int row);
}
