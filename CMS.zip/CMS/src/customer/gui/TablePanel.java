package customer.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JViewport;
import javax.swing.border.MatteBorder;

import customer.model.Customer;
import settings.UI_Settings;

public class TablePanel extends JPanel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4354203278146170774L;
	
	private JTable table;
	private CustomerTableModel tableModel;
	private JScrollPane scroller;
	private JPopupMenu popup;
	private CustomerTableListener customerTableListener;
	private AddCustomerTableListener addCustomerTableListener;
	
	
	public TablePanel(){
		
	tableModel = new CustomerTableModel();
	table = new JTable(tableModel);
	popup = new JPopupMenu();

		JMenuItem removeItem = new JMenuItem("Delete row");
		popup.add(removeItem);
		
		removeItem.addActionListener(new ActionListener(){
			
			public void actionPerformed(ActionEvent e){
				int row = table.getSelectedRow();
				
				if(customerTableListener != null){
					customerTableListener.rowDeleted(row);
					tableModel.fireTableRowsDeleted(row, row);
				}
			}
			
		});
	

		table.addMouseListener(new MouseAdapter(){

			@Override
			public void mousePressed(MouseEvent e) {
				
				if(e.getButton() == MouseEvent.BUTTON3){
					popup.show(table, e.getX(), e.getY());
				}
			}
		});
		
		setUpTable();
		
		scroller = new JScrollPane(table);

		setLayout(new BorderLayout());
		setScrollerCornerComponent();
		scroller.revalidate();

		
		add(scroller, BorderLayout.CENTER);
	}
	
	private void setScrollerCornerComponent() {
		
        JLabel cornerComponent = new JLabel("");
        cornerComponent.setBackground(UI_Settings.getTableHeaderColor());
        cornerComponent.setForeground(Color.WHITE);
    	MatteBorder matte = new MatteBorder(0, 0, 1, 1, Color.WHITE);

        cornerComponent.setBorder(matte);
        cornerComponent.setHorizontalAlignment(0);
        cornerComponent.setOpaque(true);
        scroller.setCorner(JScrollPane.UPPER_TRAILING_CORNER, cornerComponent);
		scroller.setBorder(BorderFactory.createEmptyBorder());
		scroller.setColumnHeader(new JViewport(){
			

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Override public Dimension getPreferredSize(){
			Dimension d = super.getPreferredSize();
			d.height = UI_Settings.getTableHeaderHeight();
			return d;
			}
		});		
		
		
		for (MouseWheelListener mwl : scroller.getMouseWheelListeners()) {
			scroller.removeMouseWheelListener(mwl);
		}
		
	}

	private void setUpTable() {
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		table.setSelectionBackground(UI_Settings.getTableSelectedRowColor());
		table.setFont(UI_Settings.getTableFont());
		table.setFillsViewportHeight(true);
		table.setRowHeight(UI_Settings.getTableRowHeight());
		table.getShowHorizontalLines();
		table.setBackground(Color.WHITE);
		table.setGridColor(UI_Settings.getTableGridLineColor());
		table.setShowGrid(true);	
	}

	public void setData(List<Customer> db){
		tableModel.setData(db);
	}
	
	public void refresh(){
		tableModel.fireTableDataChanged();
		repaint();
	}
	
	public JTable getTable(){
		return table;
	}
	
	public CustomerTableModel getTableModel(){
		return tableModel;
	}
	
	public void setCustomerTableListener(CustomerTableListener listener){
		this.customerTableListener = listener;
	}
	
	public void AddCustomerTableListener(AddCustomerTableListener listener){
		this.addCustomerTableListener = listener;
	}

	public int getSelectedRow() {
		return table.getSelectedRow();
	}

	public void deleteRow(int row) {
		if(customerTableListener != null){
			customerTableListener.rowDeleted(row);
			tableModel.fireTableRowsDeleted(row, row);
		}
	}

	public int getColumnCount() {
		return table.getColumnCount();
	}

	public Object getValueAt(int row, int column) {
		return table.getValueAt(row, column);
	}
}