package group.model;

import java.io.Serializable;

public class Group implements Serializable {
	
	String groupName = "";
	String groupMaterial = "";
	String level = "";
	String day = "";
	String time = "";
	String currentClassSize = "";
	String maxClassSize = "";
	int id = 0;
	
	public Group(String groupName, String groupMaterial, String level, String day, String time, String currentClassSize, String maxClassSize, int id){
		
		this.groupName = groupName;
		this.groupMaterial = groupMaterial;
		this.level = level;
		this.day = day;
		this.time = time;
		this.currentClassSize = currentClassSize;
		this.maxClassSize = maxClassSize;
		this.id = id;
		
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupMaterial() {
		return groupMaterial;
	}

	public void setGroupMaterial(String groupMaterial) {
		this.groupMaterial = groupMaterial;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getCurrentClassSize() {
		return currentClassSize;
	}

	public void setCurrentClassSize(String currentClassSize) {
		this.currentClassSize = currentClassSize;
	}

	public String getMaxClassSize() {
		return maxClassSize;
	}

	public void setMaxClassSize(String maxClassSize) {
		this.maxClassSize = maxClassSize;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
